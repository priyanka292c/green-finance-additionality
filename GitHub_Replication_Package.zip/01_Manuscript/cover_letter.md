# FORMAL JOURNAL SUBMISSION COVER LETTER

**Date:** September 2026  
**From:**  
Dr. Shylaja H N (Corresponding Author, on behalf of all co-authors)  
Manipal Institute of Commerce, Finance and Economics  
Manipal Academy of Higher Education (MAHE), Manipal, Karnataka 576104, India  
Email: shylaja.hn@manipal.edu  

**To:**  
The Editors-in-Chief / Senior Editorial Board  
*Journal of Corporate Finance*  
*Elsevier Editorial System*  

---

**Subject:** Submission of Original Research Manuscript:  
*“Green Finance or Green Refinancing? Evidence on the Environmental Additionality of Corporate Green Bonds”*

Dear Editor-in-Chief and Editorial Board Members,

On behalf of all co-authors, I am pleased to submit our original research manuscript entitled **“Green Finance or Green Refinancing? Evidence on the Environmental Additionality of Corporate Green Bonds”** for consideration for publication as a regular research article in the *Journal of Corporate Finance*.

### Author Consortium and Institutional Affiliations
1. **Dr. Shylaja H N** (*Corresponding Author*), Manipal Institute of Commerce, Finance and Economics, Manipal Academy of Higher Education (MAHE), Manipal, Karnataka 576104, India.  
   Email: `shylaja.hn@manipal.edu`
2. **Hamood Amur Al Wardi**, Mazoon College, Muscat, Sultanate of Oman.  
   Email: `omaniconsul@gmail.com`
3. **Dr. Uvesh Husain**, Mazoon College, Muscat, Sultanate of Oman.  
   Email: `u78.husain@gmail.com`
4. **Dr. Ram Soorat**, School of Business, Woxsen University, Hyderabad, Telangana, India.  
   Email: `rsoorat@gmail.com`
5. **Priyanka**, Department of Commerce / Economics, University of Delhi, New Delhi, India.  
   Email: `priyanka292c@gmail.com`
6. **Afzalur Rahman**, School of Business, Woxsen University, Hyderabad, Telangana, India.  
   Email: `afzalur.rahman@woxsen.edu.in`

---

### Manuscript Profile
- **Article Category:** Original Research Article (Empirical Corporate Finance / Sustainable Finance / Environmental Economics).
- **Structure:** Main Manuscript (37 pages, including 10 tables and 3 figures; provided in both authored and double-blind versions) + Supplementary Appendix (13 pages, including 10 supplementary tables, formal mathematical derivations, and replication protocol; provided in both authored and double-blind versions).
- **Keywords:** Sustainable Finance, Corporate Green Bonds, Environmental Additionality, Debt Refinancing, Staggered Difference-in-Differences, ESG Rating Differentiation, Decarbonization.
- **JEL Classifications:** G12, G14, G31, G32, Q54, Q56, Q58.

---

### Research Motivation & Scientific Contribution
Over the past decade, the global sustainable debt market has expanded rapidly, surpassing USD 5 trillion in cumulative issuance (with corporate green bonds representing the cornerstone asset class). Proponents argue that labeled green debt provides a vital market mechanism to finance climate solutions by lowering capital costs (the “greenium”) and earmarking proceeds for environmental projects. However, a foundational yet contested question in corporate finance and environmental economics is whether corporate green bonds are associated with **environmental additionality**—measurable incremental capital expenditures and physical emissions abatement beyond what issuing firms would have undertaken counterfactually. Under standard corporate finance theory, capital is fungible: issuers can issue labeled green bonds simply to refinance pre-existing, operational renewable assets without committing new capital or accelerating physical decarbonization.

To resolve this empirical debate, our paper introduces three major advances:
1. **Granular Contractual Allocation Decomposition:** Rather than treating green bond issuance as a binary indicator, we hand-collect and verify prospectus filings, SEC Form 10-K/8-K disclosures, and post-issuance allocation reports for 42 green-bond issuers within an observational panel of 84 multinational corporations (42 verified issuers matched 1:1 to 42 propensity-score-matched comparison firms with no identified publicly disclosed labeled sustainable debt across 8 GICS sectors over 2013–2024; 1,008 firm-year observations). We isolate the exact contractual share dedicated to *New Green Capital Projects* versus *Debt Refinancing*.
2. **Modern Staggered DiD Identification:** We implement the non-parametric estimator of Callaway and Sant'Anna (2021) with screened comparison firms treated as never-treated controls in the estimation, avoiding the negative-weighting contamination of traditional two-way fixed effects (TWFE). Dynamic event-time estimates show no statistically detectable differential pre-treatment trend (joint Wald test: $F = 0.285$, $p = 0.887$), while recognizing that pre-trend tests cannot formally prove the parallel-trends assumption.
3. **Discovery of Commercial ESG Rating Decoupling:** We evaluate commercial ESG ratings alongside physical emissions, uncovering a critical market friction: commercial ESG agencies report standardized score increases with no statistically detectable difference between refinancing-dominated and new-project issuers ($+0.91\sigma$ vs. $+0.90\sigma$, $p = 0.428$), revealing similar commercial ESG-score increases despite substantially different observed physical emissions trajectories.

---

### Core Empirical Findings
- **Overall Green Bond Abatement:** Overall issuance is associated with a $-8.91\%$ decline in Scope 1+2 emissions ($\text{ATT} = -0.0934$, $SE = 0.0110$, $p < 0.001$), a $-9.67\%$ reduction in emissions intensity ($p < 0.001$), and a $+7.32$ pp expansion in Green CapEx share ($p < 0.001$).
- **Non-Bond Green CapEx Expansion:** Non-GB Green CapEx share increases by $+6.60$ pp ($p < 0.001$), providing evidence that the green investment response is not an accounting artifact of focal bond earmarking.
- **Use-of-Proceeds Divergence:** While model-implied 100% new-project allocations achieve $-8.77\%$ net physical emissions abatement ($p < 0.001$), refinancing-dominated issuances ($\ge 70\%$ refinancing) exhibit zero additional abatement relative to matched controls and instead show a $+3.88\%$ relative divergence ($p < 0.001$) as they fail to match control decarbonization trajectories.
- **Dynamic Event-Time Progression:** Abatement deepens monotonically from $-4.11\%$ at $t=0$ to $-19.26\%$ at $t+5$, with larger estimated effects among higher-leverage issuers and issuances receiving independent external Second-Party Opinions (SPOs).

---

### Policy Relevance
These empirical findings directly inform current international regulatory deliberations by the SEC, ESMA, and recent OECD work on aligning finance with climate goals (OECD, 2026). Our results demonstrate that voluntary market guidelines (such as ICMA Green Bond Principles) which permit unconstrained refinancing may create scope for labeled refinancing to receive similar market recognition despite weaker observed incremental physical outcomes. We outline actionable policy mechanisms, including mandatory differentiated reporting for new versus refinanced expenditures, standardized look-back duration limits, and caution against uncalibrated prudential banking capital relief (Green Supporting Factors).

---

### Mandatory Author Declarations & Research Integrity
- **Originality & Exclusivity:** This manuscript represents original work and has not been published previously, nor is it currently submitted or under review elsewhere.
- **Consensus:** All authors listed have reviewed the manuscript, agree with its findings and methodology, and have approved its submission to the *Journal of Corporate Finance*.
- **Conflicts of Interest:** The authors declare that they have no competing financial interests, consultancies, or personal relationships that could have influenced the work reported in this paper.
- **Turnkey Scientific Reproducibility:** In accordance with the journal's open science and reproducibility standards, full replication code and the reproducible data-provenance materials will be made available upon publication, subject to commercial data-provider and licensing restrictions. Both clean empirical panel data provenance tracking (`empirical_panel_provenance.csv`) and automated estimation pipelines in Python and MATLAB are archived.
- **Authorship & Blinded Review Support:** Both full-authorship and anonymized versions of the manuscript and supplementary appendix are provided, ensuring immediate compliance with either single-blind or double-blind peer review requirements.

---

### Suggested Referees (Available for portal entry or direct editorial invitation)
1. **Prof. Caroline Flammer**, Columbia University, School of International and Public Affairs (SIPA) and Columbia Business School.  
   *Expertise:* Corporate Green Bonds, ESG, Corporate Governance.  
   *Email:* `cflammer@columbia.edu`
2. **Prof. Malcolm Baker**, Harvard Business School, Harvard University.  
   *Expertise:* Sustainable Investing, Green Bond Pricing, Capital Markets.  
   *Email:* `mbaker@hbs.edu`
3. **Dr. Serena Fatica**, European Commission, Joint Research Centre (JRC).  
   *Expertise:* European Sustainable Finance, Green Bond Additionality, Environmental Economics.  
   *Email:* `serena.fatica@ec.europa.eu`
4. **Prof. Dirk Schoenmaker**, Rotterdam School of Management, Erasmus University Rotterdam, and CEPR.  
   *Expertise:* Sustainable Finance, Climate Risk, Financial Regulation.  
   *Email:* `schoenmaker@rsm.nl`
5. **Prof. Philipp Krueger**, University of Geneva and Swiss Finance Institute.  
   *Expertise:* Institutional Investors and Climate Risk, Corporate Sustainability.  
   *Email:* `philipp.krueger@unige.ch`

---

Thank you very much for your time, consideration, and handling of our manuscript. We look forward to receiving the referees’ evaluations.

Sincerely,

**Dr. Shylaja H N**  
Corresponding Author, on behalf of all co-authors  
Manipal Institute of Commerce, Finance and Economics  
Manipal Academy of Higher Education (MAHE), Manipal, Karnataka 576104, India  
Email: `shylaja.hn@manipal.edu`  
