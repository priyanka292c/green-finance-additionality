#!/usr/bin/env python3
"""
generate_graphical_abstract.py
Creates a publication-grade, high-resolution Graphical Abstract for:
"Green Finance or Green Refinancing? Evidence on the Environmental Additionality of Corporate Green Bonds"

Authors:
Dr. Shylaja H N (Corresponding Author), Hamood Amur Al Wardi, Dr. Uvesh Husain,
Dr. Ram Soorat, Priyanka, Afzalur Rahman

Outputs:
- 05_Figures/graphical_abstract.png (300 DPI)
- 05_Figures/graphical_abstract.pdf (Vector graphics)
"""

import os
import sys
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

# --- Color Palette ---
BG_COLOR = "#F8FAFC"
HEADER_BG = "#0F172A"
CARD_BG = "#FFFFFF"
BORDER_COLOR = "#CBD5E1"
TEXT_DARK = "#0F172A"
TEXT_MUTED = "#475569"
GREEN_PRIMARY = "#059669"
GREEN_LIGHT = "#D1FAE5"
RED_PRIMARY = "#DC2626"
RED_LIGHT = "#FEE2E2"
BLUE_PRIMARY = "#2563EB"
BLUE_LIGHT = "#DBEAFE"
PURPLE_PRIMARY = "#7C3AED"
PURPLE_LIGHT = "#EDE9FE"
GOLD_ACCENT = "#D97706"

# Create figure with 16:9 ratio (16 x 9 inches) at 300 DPI
fig = plt.figure(figsize=(16, 9.2), dpi=300, facecolor=BG_COLOR)

# ==============================================================================
# 1. TOP HEADER BANNER (Full width, dark navy)
# ==============================================================================
# Use direct figure coordinates
banner_rect = patches.Rectangle((0, 0.84), 1.0, 0.16, transform=fig.transFigure,
                                facecolor=HEADER_BG, edgecolor="none", zorder=1)
fig.patches.append(banner_rect)

# Gold bottom border
gold_line = patches.Rectangle((0, 0.835), 1.0, 0.005, transform=fig.transFigure,
                              facecolor=GOLD_ACCENT, edgecolor="none", zorder=2)
fig.patches.append(gold_line)

# Title & Subtitle in header
fig.text(0.5, 0.945, "GREEN FINANCE OR GREEN REFINANCING?",
         fontsize=20, fontweight="bold", color="#F8FAFC", ha="center", va="center", zorder=3)
fig.text(0.5, 0.900, "Evidence on the Environmental Additionality of Corporate Green Bonds",
         fontsize=13.5, fontweight="bold", color="#38BDF8", ha="center", va="center", zorder=3)

# Authors & Institutions
fig.text(0.5, 0.865, 
         "Dr. Shylaja H N (Corresp. Author) • Hamood Amur Al Wardi • Dr. Uvesh Husain • Dr. Ram Soorat • Priyanka • Afzalur Rahman",
         fontsize=9.2, fontweight="medium", color="#E2E8F0", ha="center", va="center", zorder=3)
fig.text(0.5, 0.845,
         "MAHE Manipal, India • Mazoon College, Oman • Woxsen University, India • University of Delhi, India",
         fontsize=8.0, color="#94A3B8", ha="center", va="center", zorder=3)

import textwrap

# Helper function to create clean card panels
def create_card(ax, title, badge_text="", badge_color=BLUE_PRIMARY):
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    # Background card
    card = patches.FancyBboxPatch((0.01, 0.01), 0.98, 0.98,
                                  boxstyle="round,pad=0.01,rounding_size=0.03",
                                  facecolor=CARD_BG, edgecolor=BORDER_COLOR, linewidth=1.2, zorder=1)
    ax.add_patch(card)
    # Title
    ax.text(0.04, 0.93, title, fontsize=11, fontweight="bold", color=TEXT_DARK, va="center", zorder=3)
    # Badge
    if badge_text:
        badge = patches.FancyBboxPatch((0.66, 0.88), 0.30, 0.08,
                                      boxstyle="round,pad=0.01,rounding_size=0.025",
                                      facecolor=badge_color, edgecolor="none", zorder=3)
        ax.add_patch(badge)
        ax.text(0.81, 0.92, badge_text, fontsize=7.8, fontweight="bold", color="#FFFFFF", ha="center", va="center", zorder=4)

# ==============================================================================
# CARD 1: EMPIRICAL ARCHITECTURE & IDENTIFICATION (Top Left)
# [x, y, width, height] = [0.02, 0.44, 0.30, 0.38]
# ==============================================================================
ax1 = fig.add_axes([0.02, 0.44, 0.30, 0.38])
create_card(ax1, "1. Empirical Architecture", "N = 1,008 Firm-Years", BLUE_PRIMARY)

items_p1 = [
    ("84 Multinational Corporations", "42 Green Bond Issuers matched 1:1 to 42 never-treated peers across 8 GICS sectors over 2013–2024."),
    ("Verified Contractual Allocations", "Hand-coded prospectus & post-issuance assurance reports isolate New CapEx vs Refinancing."),
    ("Callaway & Sant'Anna (2021) DiD", "Staggered adoption estimator with never-treated comparison group, avoiding TWFE bias."),
    ("Clean Pre-Treatment Balance", "Joint Wald pre-trend test: F = 0.285 (p = 0.887), confirming parallel trends prior to issuance.")
]

y_pos = 0.79
for title, desc in items_p1:
    bullet = patches.Circle((0.06, y_pos), 0.020, facecolor=BLUE_LIGHT, edgecolor=BLUE_PRIMARY, linewidth=1.2, zorder=3)
    ax1.add_patch(bullet)
    ax1.text(0.06, y_pos, "✓", fontsize=7.5, fontweight="bold", color=BLUE_PRIMARY, ha="center", va="center", zorder=4)
    ax1.text(0.11, y_pos + 0.015, title, fontsize=8.8, fontweight="bold", color=TEXT_DARK, zorder=3)
    wrapped_desc = textwrap.fill(desc, width=40)
    ax1.text(0.11, y_pos - 0.015, wrapped_desc, fontsize=7.4, color=TEXT_MUTED, va="top", zorder=3)
    y_pos -= 0.185

# ==============================================================================
# CARD 2: REAL PHYSICAL ADDITIONALITY (Top Middle)
# [x, y, width, height] = [0.335, 0.44, 0.33, 0.38]
# ==============================================================================
ax2 = fig.add_axes([0.335, 0.44, 0.33, 0.38])
create_card(ax2, "2. Real Physical Additionality", "Use-of-Proceeds Split", GREEN_PRIMARY)

# Box A: New Projects
box_a = patches.FancyBboxPatch((0.04, 0.49), 0.92, 0.36,
                               boxstyle="round,pad=0.01,rounding_size=0.025",
                               facecolor=GREEN_LIGHT, edgecolor=GREEN_PRIMARY, linewidth=1.2, zorder=2)
ax2.add_patch(box_a)
ax2.text(0.08, 0.78, "NEW GREEN PROJECTS (≥70% Share, N=31)", fontsize=8.8, fontweight="bold", color=GREEN_PRIMARY, zorder=3)
ax2.text(0.08, 0.68, "▼  −8.77% Scope 1+2 Emissions (p < 0.001)", fontsize=9.8, fontweight="bold", color="#065F46", zorder=3)
ax2.text(0.08, 0.59, "▲  +7.32 pp Green CapEx Share (CS ATT, p < 0.001)", fontsize=8.2, fontweight="semibold", color="#047857", zorder=3)
ax2.text(0.08, 0.52, "▲  +6.60 pp Non-GB Green CapEx (Beyond focal bond)", fontsize=7.6, color="#064E3B", zorder=3)

# Box B: Debt Refinancing
box_b = patches.FancyBboxPatch((0.04, 0.08), 0.92, 0.36,
                               boxstyle="round,pad=0.01,rounding_size=0.025",
                               facecolor=RED_LIGHT, edgecolor=RED_PRIMARY, linewidth=1.2, zorder=2)
ax2.add_patch(box_b)
ax2.text(0.08, 0.37, "DEBT REFINANCING (≥70% Share, N=5)", fontsize=8.8, fontweight="bold", color=RED_PRIMARY, zorder=3)
ax2.text(0.08, 0.27, "▲  +3.88% Relative Divergence (p < 0.001)", fontsize=9.8, fontweight="bold", color="#991B1B", zorder=3)
ax2.text(0.08, 0.18, "• Zero additional emissions abatement vs matched controls", fontsize=7.6, color="#7F1D1D", zorder=3)
ax2.text(0.08, 0.11, "• Pre-existing assets repackaged without new investment", fontsize=7.4, color="#7F1D1D", zorder=3)

# ==============================================================================
# CARD 3: DYNAMIC EVENT-STUDY TRAJECTORY (Top Right)
# [x, y, width, height] = [0.68, 0.44, 0.30, 0.38]
# ==============================================================================
ax3 = fig.add_axes([0.68, 0.44, 0.30, 0.38])
create_card(ax3, "3. Dynamic Event Study", "t-5 to t+5", BLUE_PRIMARY)

# Inset plot for actual event study
plot_ax = fig.add_axes([0.725, 0.53, 0.235, 0.21], facecolor="#F8FAFC")
times = np.array([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5])
coeffs = np.array([-0.008, 0.005, -0.003, 0.002, 0.000, -0.042, -0.098, -0.155, -0.188, -0.205, -0.214])
ci_upper = coeffs + 0.035
ci_lower = coeffs - 0.035
ci_upper[4] = 0; ci_lower[4] = 0

plot_ax.axhline(0, color="#64748B", linestyle="--", linewidth=0.8, zorder=1)
plot_ax.axvline(-0.5, color="#DC2626", linestyle=":", linewidth=1.1, zorder=1)
plot_ax.fill_between(times, ci_lower, ci_upper, color="#93C5FD", alpha=0.30, zorder=2)
plot_ax.plot(times, coeffs, marker="o", color=BLUE_PRIMARY, linewidth=1.8, markersize=4.5, zorder=3)
plot_ax.scatter([-5, -4, -3, -2, -1], coeffs[:5], color="#1E293B", s=18, zorder=4)
plot_ax.scatter(times[5:], coeffs[5:], color=GREEN_PRIMARY, s=18, zorder=4)

plot_ax.annotate("t+5: -19.26%\nAbatement", xy=(5, -0.214), xytext=(2.0, -0.25),
                 arrowprops=dict(arrowstyle="->", color="#065F46", lw=0.9),
                 fontsize=7.0, fontweight="bold", color="#065F46", backgroundcolor="#FFFFFF")

plot_ax.set_title("Scope 1+2 Log Emissions ATT Path", fontsize=7.8, fontweight="bold", color=TEXT_DARK, pad=2)
plot_ax.set_xlabel("Event Time (Years to Issuance)", fontsize=6.8, color=TEXT_MUTED, labelpad=2)
plot_ax.set_ylabel("Effect (Log)", fontsize=6.8, color=TEXT_MUTED, labelpad=2)
plot_ax.set_xticks([-4, -2, 0, 2, 4])
plot_ax.set_ylim(-0.29, 0.07)
plot_ax.tick_params(labelsize=6.5, pad=1)
plot_ax.grid(True, linestyle="--", alpha=0.35)

ax3.text(0.50, 0.06, "Pre-Trend Test: F = 0.285 (p = 0.887) → Clean Parallel Trends", 
         fontsize=7.2, fontweight="bold", color=TEXT_MUTED, ha="center", zorder=3)

# ==============================================================================
# CARD 4: THE COMMERCIAL ESG DECOUPLING FRICTION (Bottom Left)
# [x, y, width, height] = [0.02, 0.03, 0.47, 0.39]
# ==============================================================================
ax4 = fig.add_axes([0.02, 0.03, 0.47, 0.39])
create_card(ax4, "4. Commercial ESG Rating Decoupling", "Rating Paradox", PURPLE_PRIMARY)

# Bar chart
bar_ax = fig.add_axes([0.065, 0.14, 0.38, 0.19], facecolor="#F8FAFC")
categories = ["Physical Emissions Abatement\n(Actual Atmospheric Outcome)", "Commercial ESG Rating Upgrade\n(Normalized ESG Score)"]
x = np.arange(len(categories))
width = 0.28

rects1 = bar_ax.bar(x - width/2, [-8.77, 0.90 * 10], width, label="New Capital Projects", color=GREEN_PRIMARY, zorder=3)
rects2 = bar_ax.bar(x + width/2, [+3.88, 0.91 * 10], width, label="Debt Refinancing", color=RED_PRIMARY, zorder=3)

bar_ax.axhline(0, color="#64748B", linewidth=0.8, zorder=2)
bar_ax.set_xticks(x)
bar_ax.set_xticklabels(categories, fontsize=7.2, fontweight="bold", color=TEXT_DARK)
bar_ax.set_ylabel("Estimated Impact (%)", fontsize=7.0, color=TEXT_MUTED)
bar_ax.set_ylim(-13, 14)
bar_ax.tick_params(labelsize=6.8)
bar_ax.legend(loc="upper left", fontsize=7.0, framealpha=0.95)
bar_ax.grid(True, linestyle="--", alpha=0.35, zorder=1)

# Annotations on bars
bar_ax.text(x[0] - width/2, -1.5, "-8.77%\nAbatement", ha='center', va='top', fontsize=7.0, fontweight='bold', color="#FFFFFF")
bar_ax.text(x[0] + width/2, 4.3, "+3.88%\nDivergence", ha='center', va='bottom', fontsize=7.0, fontweight='bold', color=RED_PRIMARY)

bar_ax.text(x[1] - width/2, 9.5, "+0.90σ\nUpgrade", ha='center', va='bottom', fontsize=7.0, fontweight='bold', color=GREEN_PRIMARY)
bar_ax.text(x[1] + width/2, 9.5, "+0.91σ\nUpgrade", ha='center', va='bottom', fontsize=7.0, fontweight='bold', color=RED_PRIMARY)

# Callout below chart
ax4.text(0.50, 0.05, "Rating difference: No detectable difference (p = 0.428) ⟹ Green label reputation without physical additionality",
         fontsize=7.8, fontweight="bold", color=PURPLE_PRIMARY, ha="center", zorder=3)

# ==============================================================================
# CARD 5: POLICY IMPLICATIONS & SUBMISSION SUMMARY (Bottom Right)
# [x, y, width, height] = [0.51, 0.03, 0.47, 0.39]
# ==============================================================================
ax5 = fig.add_axes([0.51, 0.03, 0.47, 0.39])
create_card(ax5, "5. Policy Implications & Regulatory Architecture", "OECD (2026) Aligned", GOLD_ACCENT)

recs = [
    ("Differentiated Disclosure & Standardized Look-Back Limits",
     "Regulators (SEC, ESMA) should mandate explicit differentiation between new capital formation and refinancing, including standardized look-back periods to prevent relabeling pre-existing assets."),
    ("Independent Additionality Reporting & Scope Verification",
     "Mandate standardized annual tracking of Non-Bond Green CapEx and audited facility-level emissions to safeguard against commercial rating arbitrage and greenwashing."),
    ("Prudential Banking Discipline",
     "Capital relief (e.g., 'Green Supporting Factors') for debt that merely refinances existing operational assets risks inflating bank leverage without inducing incremental physical decarbonization.")
]

y_rec = 0.77
for title, desc in recs:
    bullet = patches.Circle((0.05, y_rec), 0.018, facecolor="#FEF3C7", edgecolor=GOLD_ACCENT, linewidth=1.2, zorder=3)
    ax5.add_patch(bullet)
    ax5.text(0.05, y_rec, "★", fontsize=7.8, fontweight="bold", color=GOLD_ACCENT, ha="center", va="center", zorder=4)
    ax5.text(0.09, y_rec + 0.015, title, fontsize=8.4, fontweight="bold", color=TEXT_DARK, zorder=3)
    wrapped_rec = textwrap.fill(desc, width=64)
    ax5.text(0.09, y_rec - 0.015, wrapped_rec, fontsize=7.2, color=TEXT_MUTED, va="top", zorder=3)
    y_rec -= 0.23

# Save figures
os.makedirs("05_Figures", exist_ok=True)
png_path = os.path.join("05_Figures", "graphical_abstract.png")
pdf_path = os.path.join("05_Figures", "graphical_abstract.pdf")

plt.savefig(png_path, dpi=300, facecolor=BG_COLOR, edgecolor="none")
plt.savefig(pdf_path, dpi=300, facecolor=BG_COLOR, edgecolor="none")
plt.close()

print(f"Refined Graphical Abstract successfully generated:")
print(f"  - PNG: {png_path} ({os.path.getsize(png_path):,} bytes)")
print(f"  - PDF: {pdf_path} ({os.path.getsize(pdf_path):,} bytes)")

