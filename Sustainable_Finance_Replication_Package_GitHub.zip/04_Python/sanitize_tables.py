import glob, re

tex_files = glob.glob('06_Tables/*.tex')
for tf in tex_files:
    with open(tf, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    new_lines = []
    for line in lines:
        # If line contains label with \_, restore to _
        if r'\label{' in line:
            line = line.replace(r'\_', '_')
        
        # Replace S&P with S\&P
        line = line.replace('S&P', r'S\&P')
        line = line.replace('MSCI / S&P Global', r'MSCI / S\&P Global')
        
        # Replace {0, 1} with \{0, 1\}
        line = line.replace('{0, 1}', r'\{0, 1\}')
        
        # Replace unescaped % not at line start (comments) and not preceded by \
        # e.g. % of total -> \% of total, (%) -> (\%)
        parts = line.split(r'\%')
        # In each part, if there is a raw % that is not a latex comment, let's fix
        # But wait, if line doesn't start with %, any % in table cells is usually percent
        if not line.strip().startswith('%'):
            # replace raw % with \%
            # using regex negative lookbehind
            line = re.sub(r'(?<!\\)%', r'\%', line)
            
        new_lines.append(line)
        
    with open(tf, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)

print("Sanitized all table .tex files")
