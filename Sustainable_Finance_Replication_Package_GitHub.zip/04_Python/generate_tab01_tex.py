import pandas as pd

df_gap = pd.read_csv('06_Tables/tab01_literature_gap_matrix.csv')

latex_tab1 = r'''\begin{table}[H]
\centering
\scriptsize
\caption{Literature Gap Matrix: Benchmarking Core Studies Against the Present Empirical Architecture}
\label{tab:lit_gap_matrix}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccccccc}
\toprule
\textbf{Study} & \textbf{Green Bond} & \textbf{Green Loan} & \textbf{Causal Design} & \textbf{Green CapEx} & \textbf{Scope 1/2 GHG} & \textbf{Refinancing Isolated} & \textbf{Verification} & \textbf{Decoupling} & \textbf{Main Limitation} & \textbf{Incremental Contribution of Present Study} \\
\midrule
'''

# Select representative 20-25 studies to keep table legible and clean
benchmarks = [
    ("Flammer (2021)", "Yes", "No", "Standard DiD", "No", "Proxy", "No", "No", "Indirect", "Pooled treatment; lacks refinancing split", "Isolates new CapEx from refinancing via Callaway-Sant'Anna"),
    ("Tang and Zhang (2020)", "Yes", "No", "Event Study", "No", "No", "No", "No", "No", "Stock market focus; no physical emissions", "Tracks Scope 1+2 physical emissions and clean CapEx"),
    ("Zerbib (2019)", "Yes", "No", "Matching OLS", "No", "No", "No", "Yes", "No", "Pricing greenium only; no real outcomes", "Evaluates physical additionality beyond secondary pricing"),
    ("Baker et al. (2018)", "Yes", "No", "OLS / FE", "No", "No", "No", "No", "No", "Municipal focus; no corporate emissions", "Evaluates multinational corporate issuers and CapEx"),
    ("Larcker and Watts (2020)", "Yes", "No", "Exact Match", "No", "No", "No", "No", "No", "Examines yield parity; no additionality", "Tests physical additionality and real investment"),
    ("Fatica, Panzica and Rancan (2021)", "Yes", "No", "Panel FE", "No", "No", "No", "Yes", "No", "Secondary pricing and yield focus; no physical emissions", "Evaluates physical emissions and investment beyond debt pricing"),
    ("Ehlers et al. (2021)", "Yes", "Yes", "Descriptive", "No", "Carbon Int.", "No", "No", "Indirect", "Cross-sectional; lacks causal identification", "Staggered event study and peer-matched panel"),
    ("Fatica and Panzica (2021)", "Yes", "No", "Panel FE", "No", "Scope 1/2", "Yes", "Yes", "Indirect", "Lacks dynamic event-study and staggered DiD correction", "Applies Callaway-Sant'Anna group-time aggregation and continuous proceeds allocation"),
    ("Teti et al. (2022)", "Yes", "No", "Event Study", "No", "No", "No", "Yes", "No", "Cumulative abnormal returns focus", "Examines physical emissions and investment outcomes"),
    ("MacAskill et al. (2021)", "Yes", "No", "Meta-Analysis", "No", "No", "No", "Yes", "No", "Literature survey; no empirical panel", "Original 12-year empirical corporate panel"),
    ("Gianfrate and Peri (2019)", "Yes", "No", "PSM", "No", "No", "No", "No", "No", "Capital cost focus; no emissions", "Tracks corporate emissions and green CapEx shares"),
    ("Bachelet et al. (2019)", "Yes", "No", "OLS", "No", "No", "No", "Yes", "Indirect", "Issuer verification premium focus", "Interacts SPO verification with physical abatement"),
    ("Dorfleitner et al. (2022)", "Yes", "No", "Panel FE", "No", "ESG Score", "No", "No", "Indirect", "ESG rating focus; no physical emissions", "Documents physical decoupling from commercial ESG"),
    ("Kölbel et al. (2020)", "No", "No", "Conceptual", "No", "No", "No", "No", "Yes", "Theoretical framework on ESG impact", "Empirically formalizes additionality mechanisms")
]

for b in benchmarks:
    latex_tab1 += f"{b[0]} & {b[1]} & {b[2]} & {b[3]} & {b[4]} & {b[5]} & {b[6]} & {b[7]} & {b[8]} & {b[9]} & {b[10]} \\\\\n"

latex_tab1 += r'''\midrule
\textbf{Present Study} & \textbf{Yes} & \textbf{Context} & \textbf{Staggered DiD} & \textbf{Yes (\%)} & \textbf{Scope 1/2} & \textbf{Yes (70\% Rule)} & \textbf{Yes (SPO)} & \textbf{Yes (Formal)} & \textbf{Exploratory refinancing sample} & \textbf{Integrates allocation, physical emissions, investment, verification, and ESG outcomes} \\
\bottomrule
\end{tabular}
}
\begin{tablenotes}
\small
\item \textit{Notes:} This table benchmarks prominent empirical and theoretical studies against the architecture of the present paper. Columns indicate whether each study analyzes green bonds, incorporates green loans, applies robust staggered causal DiD, tracks audited green CapEx, evaluates physical Scope 1/2 GHG emissions, isolates refinancing from new investment, evaluates external Second-Party Opinions, investigates environmental-performance/ESG-rating decoupling, reports main limitations, and summarizes the incremental contribution of this study.
\end{tablenotes}
\end{table}
'''

with open('06_Tables/tab01_literature_gap_matrix.tex', 'w', encoding='utf-8') as f:
    f.write(latex_tab1)

print("Generated tab01_literature_gap_matrix.tex")
