import re

with open('01_Manuscript/main.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Replace **text** with \textbf{text}
text = re.sub(r'\*\*(.+?)\*\*', r'\\textbf{\1}', text)

# 2. Fix specific backtick code references with unescaped underscores
text = text.replace(r'(`monte_carlo_validation_panel.csv`)', r'(\texttt{monte\_carlo\_validation\_panel.csv})')
text = text.replace(r'(`api.crossref.org`)', r'(\texttt{api.crossref.org})')

# 3. Fix input for tab15 nlp performance
text = text.replace(r'\input{../06_Tables/tab15_nlp_classification_performance.csv}', r'\input{../06_Tables/tab15_nlp_classification_performance.tex}')

with open('01_Manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print("Successfully cleaned main.tex")
