#!/usr/bin/env python3
"""
package_deliverables.py
Packages clean submission and GitHub replication bundles:
1. JCF_Submission_Package.zip - Dedicated journal submission archive for Elsevier / Journal of Corporate Finance
2. GitHub_Replication_Package.zip - Complete clean public replication repository
3. Green_Finance_Additionality_Research.zip - Overleaf / typesetting bundle
Also synchronizes all top-level deliverables in the root directory.
"""

import os
import shutil
import zipfile

def package_all():
    print("================================================================================")
    print("                PACKAGING DELIVERABLES FOR SUBMISSION & GITHUB                  ")
    print("================================================================================")

    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    os.chdir(root_dir)

    # 1. Synchronize root-level deliverables
    print("\n--- Step 1: Synchronizing Root-Level Deliverables ---")
    deliverables = [
        ("01_Manuscript/main.pdf", "main.pdf"),
        ("01_Manuscript/main_blinded.pdf", "main_blinded.pdf"),
        ("01_Manuscript/supplementary.pdf", "supplementary.pdf"),
        ("01_Manuscript/supplementary_blinded.pdf", "supplementary_blinded.pdf"),
        ("01_Manuscript/cover_letter.pdf", "cover_letter.pdf"),
        ("07_Reports/Research_Integrity_Report.pdf", "Research_Integrity_Report.pdf"),
        ("07_Reports/literature_database.csv", "literature_database.csv"),
        ("07_Reports/doi_verification_report.csv", "doi_verification_report.csv"),
        ("02_Data/clean/empirical_panel_provenance.csv", "empirical_panel_provenance.csv"),
    ]

    for src, dst in deliverables:
        if os.path.exists(src):
            shutil.copyfile(src, dst)
            size_kb = os.path.getsize(dst) / 1024
            print(f"  [COPIED] {src} -> {dst} ({size_kb:.1f} KB)")
        else:
            print(f"  [WARNING] {src} not found!")

    # 2. Build JCF_Submission_Package.zip
    print("\n--- Step 2: Building JCF_Submission_Package.zip ---")
    jcf_zip = "JCF_Submission_Package.zip"
    with zipfile.ZipFile(jcf_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        # Core submission PDFs
        pdf_items = [
            ("01_Manuscript/main.pdf", "PDFs/01_Main_Manuscript_Authored.pdf"),
            ("01_Manuscript/main_blinded.pdf", "PDFs/02_Main_Manuscript_Blinded.pdf"),
            ("01_Manuscript/supplementary.pdf", "PDFs/03_Supplementary_Appendix_Authored.pdf"),
            ("01_Manuscript/supplementary_blinded.pdf", "PDFs/04_Supplementary_Appendix_Blinded.pdf"),
            ("01_Manuscript/cover_letter.pdf", "PDFs/05_Cover_Letter_JCF_Editors.pdf"),
            ("07_Reports/Research_Integrity_Report.pdf", "PDFs/06_Research_Integrity_Report.pdf"),
        ]
        for src, arc in pdf_items:
            if os.path.exists(src):
                zf.write(src, arcname=arc)
                print(f"  + Added {arc}")

        # LaTeX Source Files
        tex_files = [
            ("01_Manuscript/main.tex", "LaTeX_Source/main.tex"),
            ("01_Manuscript/main_blinded.tex", "LaTeX_Source/main_blinded.tex"),
            ("01_Manuscript/supplementary.tex", "LaTeX_Source/supplementary.tex"),
            ("01_Manuscript/supplementary_blinded.tex", "LaTeX_Source/supplementary_blinded.tex"),
            ("01_Manuscript/cover_letter.tex", "LaTeX_Source/cover_letter.tex"),
            ("01_Manuscript/references.bib", "LaTeX_Source/references.bib"),
        ]
        for src, arc in tex_files:
            if os.path.exists(src):
                zf.write(src, arcname=arc)
                print(f"  + Added {arc}")

        # Figures for typesetting
        for root, _, files in os.walk("05_Figures"):
            for f in files:
                if f.endswith((".pdf", ".png", ".jpg")):
                    p = os.path.join(root, f)
                    zf.write(p, arcname=os.path.join("LaTeX_Source/05_Figures", f))

        # Tables for typesetting
        for root, _, files in os.walk("06_Tables"):
            for f in files:
                if f.endswith((".tex", ".csv")):
                    p = os.path.join(root, f)
                    zf.write(p, arcname=os.path.join("LaTeX_Source/06_Tables", f))

        # Provenance and Data reports
        doc_files = [
            ("02_Data/clean/empirical_panel_provenance.csv", "Data_Provenance/empirical_panel_provenance.csv"),
            ("07_Reports/doi_verification_report.csv", "Reports/doi_verification_report.csv"),
            ("07_Reports/literature_database.csv", "Reports/literature_database.csv"),
            ("README.md", "README.md"),
            ("COVER_LETTER.md", "COVER_LETTER.md"),
        ]
        for src, arc in doc_files:
            if os.path.exists(src):
                zf.write(src, arcname=arc)
                print(f"  + Added {arc}")

    print(f"  [SUCCESS] Created {jcf_zip} ({os.path.getsize(jcf_zip) / (1024*1024):.2f} MB)")

    # 3. Build GitHub_Replication_Package.zip
    print("\n--- Step 3: Building GitHub_Replication_Package.zip ---")
    gh_zip = "GitHub_Replication_Package.zip"
    exclude_extensions = {".aux", ".log", ".out", ".synctex.gz", ".toc", ".bbl", ".blg", ".pyc"}
    exclude_dirs = {".venv", ".git", ".gemini", "__pycache__", ".system_generated"}

    with zipfile.ZipFile(gh_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for folder in ["01_Manuscript", "02_Data", "03_MATLAB", "04_Python", "05_Figures", "06_Tables", "07_Reports"]:
            for root, dirs, files in os.walk(folder):
                dirs[:] = [d for d in dirs if d not in exclude_dirs]
                for f in files:
                    ext = os.path.splitext(f)[1].lower()
                    if ext not in exclude_extensions and not f.startswith("."):
                        file_path = os.path.join(root, f)
                        arc_name = os.path.relpath(file_path, root_dir)
                        zf.write(file_path, arcname=arc_name)

        # Add root markdown and license/readme files
        for f in ["README.md", "COVER_LETTER.md", "main.pdf", "supplementary.pdf", "Research_Integrity_Report.pdf"]:
            if os.path.exists(f):
                zf.write(f, arcname=f)

    print(f"  [SUCCESS] Created {gh_zip} ({os.path.getsize(gh_zip) / (1024*1024):.2f} MB)")

    # 4. Overleaf bundle: Green_Finance_Additionality_Research.zip
    print("\n--- Step 4: Updating Green_Finance_Additionality_Research.zip (Overleaf Package) ---")
    ov_zip = "Green_Finance_Additionality_Research.zip"
    with zipfile.ZipFile(ov_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write("01_Manuscript/main.tex", arcname="main.tex")
        zf.write("01_Manuscript/main_blinded.tex", arcname="main_blinded.tex")
        zf.write("01_Manuscript/references.bib", arcname="references.bib")
        zf.write("01_Manuscript/supplementary.tex", arcname="supplementary.tex")
        zf.write("01_Manuscript/supplementary_blinded.tex", arcname="supplementary_blinded.tex")
        zf.write("01_Manuscript/cover_letter.tex", arcname="cover_letter.tex")

        for root, _, files in os.walk("05_Figures"):
            for file in files:
                file_path = os.path.join(root, file)
                zf.write(file_path, arcname=os.path.join("05_Figures", file))

        for root, _, files in os.walk("06_Tables"):
            for file in files:
                file_path = os.path.join(root, file)
                zf.write(file_path, arcname=os.path.join("06_Tables", file))

    print(f"  [SUCCESS] Created {ov_zip} ({os.path.getsize(ov_zip) / (1024*1024):.2f} MB)")

    print("\n================================================================================")
    print("               ALL SUBMISSION & GITHUB PACKAGES COMPLETE                        ")
    print("================================================================================")

if __name__ == "__main__":
    package_all()
