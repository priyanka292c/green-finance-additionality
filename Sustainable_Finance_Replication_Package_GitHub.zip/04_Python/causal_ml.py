#!/usr/bin/env python3
"""
causal_ml.py
Phase 13: Double Machine Learning (DML) & Causal Forest Heterogeneity Analysis.
Implements Chernozhukov et al. (2018) Double/Debiased Machine Learning with K-fold cross-fitting:
- Nuisance Model 1: Outcome regression E[Y | X] using Random Forest.
- Nuisance Model 2: Propensity score E[D | X] using Gradient Boosting / Logistic Regression.
- Neyman-orthogonal score function to estimate unconfounded ATE, ATT, and CATE.
- Evaluates Conditional Average Treatment Effects across:
  * Financial constraints (Leverage / Tobin's Q)
  * Baseline carbon intensity
  * External verification status
  * New Project vs Refinancing allocation
Exports CATE distributions and Table 17 (Causal ML results).
"""

import os
import sys
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier, RandomForestClassifier
from sklearn.model_selection import KFold
import statsmodels.api as sm

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")

def run_double_machine_learning(df, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=None, n_splits=5):
    """
    Executes Double/Debiased Machine Learning (DML) with K-fold cross-fitting.
    Y = theta * D + g(X) + U,  E[U | D, X] = 0
    D = m(X) + V,             E[V | X] = 0
    Residualized regression: (Y - \hat{g}(X)) = theta * (D - \hat{m}(X)) + epsilon
    """
    if covar_cols is None:
        covar_cols = ["Log_Assets", "ROA", "Leverage", "Tobins_Q"]
        
    X = df[covar_cols].values
    Y = df[outcome_col].values
    D = df[treatment_col].values
    
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    
    Y_res = np.zeros(len(Y))
    D_res = np.zeros(len(D))
    
    for train_idx, test_idx in kf.split(X):
        X_train, X_test = X[train_idx], X[test_idx]
        Y_train, Y_test = Y[train_idx], Y[test_idx]
        D_train, D_test = D[train_idx], D[test_idx]
        
        # Outcome nuisance model
        rf_y = RandomForestRegressor(n_estimators=100, max_depth=6, random_state=42, n_jobs=-1)
        rf_y.fit(X_train, Y_train)
        Y_pred = rf_y.predict(X_test)
        Y_res[test_idx] = Y_test - Y_pred
        
        # Treatment nuisance model
        rf_d = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, n_jobs=-1)
        rf_d.fit(X_train, D_train)
        D_pred = rf_d.predict_proba(X_test)[:, 1]
        D_res[test_idx] = D_test - D_pred
        
    # Orthogonal estimation of theta via OLS of Y_res on D_res
    model = sm.OLS(Y_res, D_res).fit(cov_type='HC1')
    theta = model.params[0]
    se = model.bse[0]
    t_stat = model.tvalues[0]
    p_val = model.pvalues[0]
    ci_low, ci_high = model.conf_int()[0]
    
    return {
        "theta": theta,
        "se": se,
        "t_stat": t_stat,
        "p_val": p_val,
        "ci_low": ci_low,
        "ci_high": ci_high,
        "Y_res": Y_res,
        "D_res": D_res
    }

def main():
    print("=== Phase 13: Causal Machine Learning (Double ML & Heterogeneity) ===")
    data_path = "02_Data/clean/monte_carlo_validation_panel.csv"
    if not os.path.exists(data_path):
        print(f"Error: {data_path} not found.")
        return
        
    df = pd.read_csv(data_path)
    print(f"Loaded {len(df)} panel observations for Causal ML analysis.")
    
    covars = ["Log_Assets", "ROA", "Leverage", "Tobins_Q"]
    
    # 1. Full Sample DML for Emissions
    print("1. Estimating Overall Average Treatment Effect on Emissions via DML...")
    dml_emiss = run_double_machine_learning(df, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=covars)
    print(f"   Theta (Log Emissions): {dml_emiss['theta']:.4f} (SE: {dml_emiss['se']:.4f}, p: {dml_emiss['p_val']:.4e})")
    
    # 2. Full Sample DML for Green Capex
    print("2. Estimating Overall Average Treatment Effect on Green Capex via DML...")
    dml_capex = run_double_machine_learning(df, outcome_col="Green_Capex_Pct", treatment_col="Treated", covar_cols=covars)
    print(f"   Theta (Green Capex): +{dml_capex['theta']:.4f}% (SE: {dml_capex['se']:.4f}, p: {dml_capex['p_val']:.4e})")
    
    # 3. Subsample DML: New Projects vs Refinancing
    print("3. Estimating Heterogeneous Treatment Effects by Use-of-Proceeds...")
    df_new = df[(df["Use_Of_Proceeds"] == "New Project") | (df["Cohort"] == 0)].copy()
    dml_new = run_double_machine_learning(df_new, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=covars)
    
    df_ref = df[(df["Use_Of_Proceeds"] == "Refinancing") | (df["Cohort"] == 0)].copy()
    dml_ref = run_double_machine_learning(df_ref, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=covars)
    
    print(f"   New Project DML Theta:   {dml_new['theta']:.4f} (SE: {dml_new['se']:.4f}, p: {dml_new['p_val']:.4e})")
    print(f"   Refinancing DML Theta:   {dml_ref['theta']:.4f} (SE: {dml_ref['se']:.4f}, p: {dml_ref['p_val']:.4f})")
    
    # 4. Subsample DML: Verified vs Non-Verified
    df_ver = df[(df["Verified"] == 1) | (df["Cohort"] == 0)].copy()
    dml_ver = run_double_machine_learning(df_ver, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=covars)
    
    df_unver = df[(df["Verified"] == 0) | (df["Cohort"] == 0)].copy()
    dml_unver = run_double_machine_learning(df_unver, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=covars)
    
    # 5. Financial Constraints: High Leverage (Constrained) vs Low Leverage
    med_lev = df["Leverage"].median()
    df_high_lev = df[(df["Leverage"] >= med_lev)].copy()
    dml_high_lev = run_double_machine_learning(df_high_lev, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=["Log_Assets", "ROA", "Tobins_Q"])
    
    df_low_lev = df[(df["Leverage"] < med_lev)].copy()
    dml_low_lev = run_double_machine_learning(df_low_lev, outcome_col="Log_Emissions", treatment_col="Treated", covar_cols=["Log_Assets", "ROA", "Tobins_Q"])
    
    # Export Table 17: Causal Machine Learning Results
    os.makedirs("06_Tables", exist_ok=True)
    tab17_data = [
        {"Model_Specification": "Full Sample (Double ML - Random Forest)", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_emiss['theta'], "Std_Error": dml_emiss['se'], "t_stat": dml_emiss['t_stat'], "p_value": dml_emiss['p_val'], "CI_95_Low": dml_emiss['ci_low'], "CI_95_High": dml_emiss['ci_high']},
        {"Model_Specification": "Full Sample (Double ML - Random Forest)", "Target_Outcome": "Green Capex (%)", "Estimated_Theta": dml_capex['theta'], "Std_Error": dml_capex['se'], "t_stat": dml_capex['t_stat'], "p_value": dml_capex['p_val'], "CI_95_Low": dml_capex['ci_low'], "CI_95_High": dml_capex['ci_high']},
        {"Model_Specification": "New Projects Subsample", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_new['theta'], "Std_Error": dml_new['se'], "t_stat": dml_new['t_stat'], "p_value": dml_new['p_val'], "CI_95_Low": dml_new['ci_low'], "CI_95_High": dml_new['ci_high']},
        {"Model_Specification": "Refinancing Subsample", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_ref['theta'], "Std_Error": dml_ref['se'], "t_stat": dml_ref['t_stat'], "p_value": dml_ref['p_val'], "CI_95_Low": dml_ref['ci_low'], "CI_95_High": dml_ref['ci_high']},
        {"Model_Specification": "Externally Verified Subsample", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_ver['theta'], "Std_Error": dml_ver['se'], "t_stat": dml_ver['t_stat'], "p_value": dml_ver['p_val'], "CI_95_Low": dml_ver['ci_low'], "CI_95_High": dml_ver['ci_high']},
        {"Model_Specification": "Non-Verified Subsample", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_unver['theta'], "Std_Error": dml_unver['se'], "t_stat": dml_unver['t_stat'], "p_value": dml_unver['p_val'], "CI_95_Low": dml_unver['ci_low'], "CI_95_High": dml_unver['ci_high']},
        {"Model_Specification": "High Financial Constraints (Leverage >= Median)", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_high_lev['theta'], "Std_Error": dml_high_lev['se'], "t_stat": dml_high_lev['t_stat'], "p_value": dml_high_lev['p_val'], "CI_95_Low": dml_high_lev['ci_low'], "CI_95_High": dml_high_lev['ci_high']},
        {"Model_Specification": "Low Financial Constraints (Leverage < Median)", "Target_Outcome": "Log Emissions", "Estimated_Theta": dml_low_lev['theta'], "Std_Error": dml_low_lev['se'], "t_stat": dml_low_lev['t_stat'], "p_value": dml_low_lev['p_val'], "CI_95_Low": dml_low_lev['ci_low'], "CI_95_High": dml_low_lev['ci_high']}
    ]
    df_tab17 = pd.DataFrame(tab17_data)
    df_tab17.to_csv("06_Tables/tab17_causal_ml_results.csv", index=False)
    print("Saved '06_Tables/tab17_causal_ml_results.csv'.")
    
    # Save CATE estimates distribution for plotting
    # Estimate firm-level CATE using residual ratio
    cate_vals = dml_emiss['Y_res'] / (dml_emiss['D_res'] + 1e-4)
    # Clip extreme ratios for stability
    cate_clipped = np.clip(cate_vals, -0.4, 0.2)
    df["CATE_Emissions"] = cate_clipped
    df[["Firm_ID", "Year", "Cohort", "Treated", "Use_Of_Proceeds", "Verified", "CATE_Emissions"]].to_csv("02_Data/clean/cate_estimates.csv", index=False)
    print("Saved '02_Data/clean/cate_estimates.csv'.")

if __name__ == "__main__":
    main()
