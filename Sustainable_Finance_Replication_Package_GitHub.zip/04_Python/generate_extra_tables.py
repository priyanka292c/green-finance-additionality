import pandas as pd
import re

# 1. NLP Classification Performance Table
df_nlp = pd.read_csv('06_Tables/tab15_nlp_classification_performance.csv')
latex_nlp = r'''\begin{table}[H]
\centering
\small
\caption{Natural Language Processing Classifier Performance on Green Debt Allocation Disclosures}
\label{tab:nlp_perf}
\begin{tabular}{lcccccc}
\toprule
\textbf{Classifier Model} & \textbf{Accuracy} & \textbf{Std} & \textbf{Precision} & \textbf{Recall} & \textbf{Macro F1} & \textbf{Key Discriminative Tokens} \\
\midrule
'''
for _, row in df_nlp.iterrows():
    m = row['Classifier']
    acc = f"{row['Accuracy_Mean']:.3f}"
    std = f"{row['Accuracy_Std']:.3f}"
    p = f"{row['Macro_Precision']:.3f}"
    r = f"{row['Macro_Recall']:.3f}"
    f1 = f"{row['Macro_F1']:.3f}"
    tok = str(row['Top_Discriminative_Features']).replace('_', r'\_')
    latex_nlp += f"{m} & {acc} & {std} & {p} & {r} & {f1} & \\textit{{{tok}}} \\\\\n"

latex_nlp += r'''\bottomrule
\end{tabular}
\begin{tablenotes}
\small
\item \textit{Notes:} Out-of-sample performance metrics based on 5-fold stratified cross-validation across corporate green bond and green loan allocation disclosures.
\end{tablenotes}
\end{table}
'''

with open('06_Tables/tab15_nlp_classification_performance.tex', 'w', encoding='utf-8') as f:
    f.write(latex_nlp)
print('Generated tab15_nlp_classification_performance.tex')

# 2. Causal ML Table
df_dml = pd.read_csv('06_Tables/tab17_causal_ml_results.csv')
latex_dml = r'''\begin{table}[H]
\centering
\small
\caption{Double/Debiased Machine Learning (DML) Causal Treatment Effect Estimates}
\label{tab:causal_ml}
\begin{tabular}{llcccc}
\toprule
\textbf{Sample Specification} & \textbf{Target Outcome} & \textbf{Treatment Effect ($\hat{\theta}$)} & \textbf{Std. Error} & \textbf{t-stat} & \textbf{95\% Conf. Interval} \\
\midrule
'''
for _, row in df_dml.iterrows():
    spec = str(row['Model_Specification']).replace('_', r'\_').replace('&', r'\&')
    out = str(row['Target_Outcome']).replace('_', r'\_').replace('%', r'\%')
    th = f"{row['Estimated_Theta']:.4f}"
    se = f"{row['Std_Error']:.4f}"
    t = f"{row['t_stat']:.2f}"
    ci = f"[{row['CI_95_Low']:.4f}, {row['CI_95_High']:.4f}]"
    pv = row['p_value']
    stars = '***' if pv < 0.01 else ('**' if pv < 0.05 else ('*' if pv < 0.1 else ''))
    latex_dml += f"{spec} & {out} & {th}{stars} & ({se}) & {t} & {ci} \\\\\n"

latex_dml += r'''\bottomrule
\end{tabular}
\begin{tablenotes}
\small
\item \textit{Notes:} Estimates obtained using Double/Debiased Machine Learning with 5-fold cross-fitting and Random Forest nuisance estimators. Significance levels: * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
\end{tablenotes}
\end{table}
'''

with open('06_Tables/tab17_causal_ml_results.tex', 'w', encoding='utf-8') as f:
    f.write(latex_dml)
print('Generated tab17_causal_ml_results.tex')
