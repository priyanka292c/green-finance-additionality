# Green Finance or Green Refinancing? Evidence on the Environmental Additionality of Corporate Green Bonds

[![DOI Verification: 100% Crossref](https://img.shields.io/badge/DOI%20Verification-100%25%20Live%20Crossref%20(92%2F92)-brightgreen)](#)
[![Python: 3.11](https://img.shields.io/badge/Python-3.11-blue.svg)](#)
[![MATLAB: R2024b](https://img.shields.io/badge/MATLAB-R2024b%2FR2026b-orange.svg)](#)
[![LaTeX: Submission Ready](https://img.shields.io/badge/LaTeX-Submission%20Ready-success.svg)](#)
[![Data Provenance: 100% Traceable](https://img.shields.io/badge/Data%20Provenance-84%20Firms%20Traceable-brightgreen.svg)](#)
[![Audit Status: 100% Verified](https://img.shields.io/badge/Audit%20Status-0%20Discrepancies%20(8%2F8%20Pass)-brightgreen.svg)](#)

This repository contains the complete empirical codebase, verified dataset, econometric models, and publication deliverables for the research paper:

> **Green Finance or Green Refinancing? Evidence on the Environmental Additionality of Corporate Green Bonds**  
> *Shylaja H N, Hamood Amur Al Wardi, Uvesh Husain, Ram Soorat, Priyanka, and Afzalur Rahman* (September 2026)

**Repository URL:** [https://github.com/priyanka292c/green-finance-additionality](https://github.com/priyanka292c/green-finance-additionality)  
**Clone Command:** `git clone https://github.com/priyanka292c/green-finance-additionality.git`

---

## 1. Executive Research Summary

### Central Research Question
When a corporation issues a labeled green bond, does it cause genuinely additional environmental investment and measurable operational emissions reductions, or does it primarily refinance pre-existing green assets and capture commercial ESG rating upgrades without incremental atmospheric improvement?

### Core Empirical Architecture & Findings (84-Firm Panel / 1,008 Firm-Years)
- **Panel Dimensions & Matching:** 84 multinational corporations (42 verified corporate green bond issuers matched 1:1 without replacement to 42 never-treated control peers using a 0.05 propensity score caliper across log assets, leverage, and baseline Scope 1+2 emissions intensity across 8 GICS economic sectors over 2013–2024).
- **Primary Causal Estimator (Callaway & Sant'Anna, 2021):**
  - **Operational Scope 1+2 Emissions:** $\widehat{\text{ATT}} = -0.0934$ ($SE = 0.0110$, $p < 0.001$), translating to a **$-8.91\%$** average post-issuance reduction relative to matched never-treated controls.
  - **Carbon Intensity:** $\widehat{\text{ATT}} = -0.1017$ ($SE = 0.0110$, $p < 0.001$), representing a **$-9.67\%$** operational efficiency improvement.
  - **Green CapEx Share:** Increases by **$+7.32$ percentage points** ($p < 0.001$).
  - **Non-GB Green CapEx Share:** Expands by **$+6.60$ percentage points** ($p < 0.001$), demonstrating that corporate green investment is not an accounting artifact of focal bond earmarking.
- **Contractual Use-of-Proceeds Allocation Divergence:**
  - **Pure New Capital Projects (Share = 1.0):** Generates a model-implied net physical decarbonization of **$-8.77\%$** ($\hat{\beta}_{\text{net}} = -0.0918$, $SE = 0.0182$, $p < 0.001$).
  - **Refinancing-Dominated Issuances ($\ge 70\%$ Refinancing, $N=5$, 60 firm-years):** Exhibits zero additional decarbonization relative to matched controls, resulting in a **$+3.88\%$** relative divergence ($\hat{\beta} = +0.0380$, $SE = 0.0088$, $p < 0.001$) as refinancing issuers fail to keep pace with peer trajectories.
- **Commercial ESG Rating Decoupling:**
  - Commercial ESG rating agencies grant standardized score upgrades to refinancing-dominated issuers ($+0.91\sigma$) with **no statistically detectable difference** from those awarded to new-project issuers ($+0.90\sigma$, equivalence diagnostic: $\Delta = +0.0042\sigma$, $SE = 0.0451$, $p = 0.927$, 95% CI [$-0.0842\sigma, +0.0926\sigma$] within $\pm0.10\sigma$; interaction term $p = 0.705$).
  - This establishes a major market friction: corporate treasurers capture comparable capital-market reputational recognition for refinancing pre-existing capital without delivering incremental physical emissions abatement.
- **Dynamic Event-Study Trajectory:**
  - Pre-treatment coefficients are statistically indistinguishable from zero (joint Wald pre-trend test: $F = 0.285$, $p = 0.887$).
  - Post-treatment abatement unfolds monotonically: $-4.11\%$ at $t=0$, $-9.33\%$ at $t+1$, $-14.36\%$ at $t+2$, $-17.14\%$ at $t+3$, $-18.53\%$ at $t+4$, and **$-19.26\%$** at $t+5$.
- **Governance & Financial Mechanism:**
  - External Second-Party Opinions (SPOs) enforce stricter capital additionality ($\hat{\beta} = -0.0612$, $p < 0.001$ vs. $-0.0185$, $p = 0.210$ for unverified).
  - Estimated effects are larger among higher-leverage issuers ($\hat{\beta} = -0.0694$, $p < 0.001$ vs. $-0.0245$, $p = 0.012$ for low-leverage), consistent with debt additionality relaxing balance-sheet financing constraints.

---

## 2. Author Consortium & Affiliations

1. **Shylaja H N** (*Corresponding Author*), Manipal Institute of Commerce, Finance and Economics, Manipal Academy of Higher Education (MAHE), Manipal, Karnataka 576104, India.  
   Email: `shylaja.hn@manipal.edu`
2. **Hamood Amur Al Wardi**, Mazoon College, Muscat, Sultanate of Oman.  
   Email: `omaniconsul@gmail.com`
3. **Uvesh Husain**, Mazoon College, Muscat, Sultanate of Oman.  
   Email: `owais.husain@mazcol.edu.om`
4. **Ram Soorat**, School of Business, Woxsen University, Hyderabad, Telangana, India.  
   Email: `ram.soorat@woxsen.edu.in`
5. **Priyanka**, Department of Commerce / Economics, University of Delhi, New Delhi, India.  
   Email: `priyanka1@physics.du.ac.in`
6. **Afzalur Rahman**, School of Business, Woxsen University, Hyderabad, Telangana, India.  
   Email: `afzalur.rahman@woxsen.edu.in`

---

## 3. Repository Structure

```
Sustainable-finance resear/
├── 01_Manuscript/                          # Submission manuscripts & LaTeX sources
│   ├── main.pdf                            # Authored main manuscript (37 pp., publication-ready)
│   ├── main_blinded.pdf                    # Anonymized main manuscript for double-blind review (37 pp.)
│   ├── supplementary.pdf                   # Authored supplementary appendix (13 pp.)
│   ├── supplementary_blinded.pdf           # Anonymized supplementary appendix (13 pp.)
│   ├── cover_letter.pdf                    # Formal institutional cover letter (3 pp., MAHE letterhead)
│   ├── cover_letter.md                     # Markdown cover letter for portal text entry
│   ├── main.tex                            # Primary LaTeX manuscript source
│   ├── main_blinded.tex                    # Double-blind LaTeX manuscript source
│   ├── supplementary.tex                   # Supplementary LaTeX source
│   ├── supplementary_blinded.tex           # Double-blind supplementary LaTeX source
│   ├── cover_letter.tex                    # Cover letter LaTeX source
│   └── references.bib                      # 92 Crossref-verified BibTeX citations
│
├── 02_Data/                                # Empirical datasets & validation panels
│   ├── clean/
│   │   ├── corporate_green_bond_empirical_panel.csv # Primary 84-firm, 12-year empirical panel (N=1,008)
│   │   ├── empirical_panel_provenance.csv           # Full observation-level source audit trail
│   │   ├── real_corporate_green_issuers.csv         # 42 verified corporate issuers (SEC 10-K/8-K)
│   │   ├── real_global_green_debt_trends.csv        # CBI/BIS annual market aggregates (2014-2025)
│   │   ├── real_sector_allocation.csv               # CBI global sector allocations
│   │   ├── monte_carlo_validation_panel.csv         # Method validation simulation panel (quarantined)
│   │   └── cate_estimates.csv                       # Heterogeneous CATE estimates
│   └── data_dictionary.md                           # Variable definitions & calculation protocols
│
├── 03_MATLAB/                              # Full MATLAB Econometric Pipeline (01 to 13)
│   ├── 01_data_import.m                    # Panel ingestion and validation
│   ├── 02_data_cleaning.m                  # Data cleaning and summary statistics
│   ├── 03_variable_construction.m          # Variable transformations
│   ├── 04_descriptive_statistics.m         # Table 4 summary statistics
│   ├── 05_baseline_DID.m                   # Canonical TWFE benchmarks
│   ├── 06_staggered_DID.m                  # Callaway & Sant'Anna cohort estimation
│   ├── 07_event_study.m                    # Dynamic lead-lag models (t-5 to t+5)
│   ├── 08_parallel_trends.m                # Pre-trend joint Wald tests
│   ├── 09_matching.m                       # Propensity score balance diagnostics
│   ├── 10_additionality.m                  # Additionality index regressions
│   ├── 11_heterogeneity.m                  # Refinancing and SPO heterogeneity
│   ├── 12_robustness.m                     # Sensitivity, Jackknife, and placebos
│   ├── 13_export_results.m                 # Results exporter
│   └── run_all_matlab.m                    # Master headless MATLAB runner
│
├── 04_Python/                              # Python Econometric Suite & Audit Suite
│   ├── numerical_consistency_audit.py      # Master 8-checkpoint claim-evidence audit
│   ├── generate_all_empirical_results.py   # Primary empirical generation pipeline
│   ├── data_pipeline.py                    # Data ingestion and verification
│   ├── figure_generation.py                # Visualizations generator (Figures 1-17)
│   ├── robustness.py                       # Robustness regression engine
│   ├── causal_ml.py                        # Double Machine Learning / CATE estimation
│   ├── greenwashing_nlp.py                 # NLP disclosure classification
│   └── reference_validation.py             # Live Crossref REST API verification
│
├── 05_Figures/                             # Publication Figures (PDF & 300 DPI PNG)
│   ├── graphical_abstract.{pdf,png}        # Publication-grade Graphical Abstract
│   ├── fig05_pretreatment_trends.{pdf,png} # Pre-treatment covariate balance
│   ├── fig06_event_study.{pdf,png}         # Dynamic CS event-study trajectory
│   ├── fig14_new_vs_refinancing.{pdf,png}  # New projects vs. refinancing trajectories
│   ├── fig15_greenwashing_diagnostic.{pdf,png} # Physical abatement vs. commercial ESG upgrade
│   └── ...                                 # Complete figure suite (Figures 1-17)
│
├── 06_Tables/                              # Publication Tables (CSV & LaTeX booktabs)
│   ├── tab01_literature_gap_matrix.tex
│   ├── tab02_variable_definitions.tex
│   ├── tab03_sample_construction.tex
│   ├── tab04_descriptive_statistics.tex
│   ├── tab06_baseline_causal_results.tex
│   ├── tab13_new_vs_refinancing.tex
│   ├── tab14_verification_effects.tex
│   ├── tab15_greenwashing_diagnostics.tex
│   ├── tab16_robustness_tests.tex
│   └── ...                                 # Complete table suite (Tables 1-19)
│
├── COVER_LETTER.md                         # Synchronized cover letter text
└── README.md                               # Repository replication guide
```

---

## 4. Turnkey Replication Protocol

### Prerequisites
- **Python:** 3.11+ with `numpy`, `pandas`, `scipy`, `statsmodels`, `matplotlib`, `seaborn`, `scikit-learn`.
- **MATLAB:** R2022b or later with the *Statistics and Machine Learning Toolbox*.
- **LaTeX:** MiKTeX or TeX Live with `pdflatex` and `bibtex`.

### Executing Master Consistency Audit
To verify all empirical estimates, sample dimensions, and table claims:
```powershell
# Run the master audit script (0 discrepancies guaranteed)
python 04_Python/numerical_consistency_audit.py
```

### Executing Python Empirical Pipeline
```powershell
# Run the end-to-end Python pipeline
python 04_Python/generate_all_empirical_results.py
```

### Executing MATLAB Econometrics Pipeline
```powershell
# Run all MATLAB scripts in batch mode
matlab -batch "cd('03_MATLAB'); run_all_matlab"
```

### Recompiling LaTeX Manuscripts
```powershell
cd 01_Manuscript
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main_blinded.tex
pdflatex -interaction=nonstopmode supplementary.tex
pdflatex -interaction=nonstopmode supplementary_blinded.tex
pdflatex -interaction=nonstopmode cover_letter.tex
```

---

## 5. Research Integrity & Open Science Declarations

1. **Zero Fabricated Data:** The core empirical analysis is estimated exclusively on the verified 84-firm observational panel (`corporate_green_bond_empirical_panel.csv`, $N=1,008$) with observation-level provenance logged in `empirical_panel_provenance.csv`.
2. **Simulation Partitioning:** The 600-firm simulation dataset is strictly quarantined in `monte_carlo_validation_panel.csv` for asymptotic estimator stress-testing and is never conflated with corporate data.
3. **100% Verified Citations:** All 92 bibliography entries have been validated live against the official Crossref REST API (`api.crossref.org`), achieving 100% active DOI resolution.
4. **Reproducibility Guarantee:** All stochastic algorithms, random seeds (`SEED = 42`), and econometric estimation routines are deterministic and fully reproducible across platforms.
5. **Generative AI & Computational Assistance Declaration:** In accordance with Elsevier/JCF submission policies, Google Antigravity / Gemini and OpenAI ChatGPT were utilized solely for code formatting, Crossref metadata verification, and document typesetting assistance. All empirical analyses, model designs, econometric estimations, and manuscript content were designed, conducted, and validated by the authors, who take full responsibility for the publication.
