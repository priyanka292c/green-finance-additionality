#!/usr/bin/env python3
"""
resolve_final_two_corrections.py

Resolves the final 2 mandatory corrections and remaining consistency items:
1. 🔴 Remove "Wiley" completely from 01_JSFI_Title_Page (.html, .md, .tex) and remove the redundant
   "BLIND TITLE PAGE" section, unifying it into a single clean unblinded Title Page for editorial use.
2. 🔴 Standardize Running Title across ALL files to:
   "Green-Bond Allocation & Emissions" (33 characters, strictly <= 40).
3. 🟡 Soften the conclusion sentence across all formats to:
   "Within the observed sample, stronger post-issuance decarbonization associations are concentrated among issuers allocating proceeds toward new capital projects, whereas refinancing-dominated allocations exhibit weaker environmental trajectories."
4. Standardize Data Availability Statement in 01_JSFI_Title_Page to match the manuscript.
5. Standardize Keywords across Title Page and Manuscript to:
   "Green bonds; Sustainable finance; Environmental additionality; Corporate decarbonization; Proceeds allocation; ESG ratings"
6. Recompile all LaTeX documents and re-export all Word DOCX and PDF documents.
"""

import os
import re

JSFI_DIR = os.path.abspath(r"d:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission")
LATEX_DIR = os.path.join(JSFI_DIR, "LaTeX_Source")

RUNNING_TITLE = "Green-Bond Allocation & Emissions"
RUNNING_TITLE_TEX = r"Green-Bond Allocation \& Emissions"
KEYWORDS = "Green bonds; Sustainable finance; Environmental additionality; Corporate decarbonization; Proceeds allocation; ESG ratings"
DATA_AVAIL = (
    "The replication package will be deposited in an appropriate open-access repository and, "
    "where permitted by data-licensing restrictions, archived through Zenodo with a linked GitHub repository "
    "containing the replication code. Proprietary third-party data (CDP Scope 1+2 emissions and Bloomberg financial records) "
    "remain subject to their respective licensing restrictions."
)

# ==============================================================================
# 1. REBUILD 01_JSFI_Title_Page (.md, .html, .tex)
# ==============================================================================
print("\n--- 1. Rebuilding 01_JSFI_Title_Page ---")

# A. Markdown
tp_md_content = f"""# Title Page — *Journal of Sustainable Finance & Investment* (Taylor & Francis)

**Full Manuscript Title:**  
Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing

**Running Title (≤ 40 characters):**  
{RUNNING_TITLE}

**Keywords:**  
{KEYWORDS}

---

### Authors and Affiliations

**Shahrukh Saleem**¹  
**Araby Madbouly**²  
**Uvesh Husain**³  
**Ram Soorat**⁴* *(Corresponding Author)*  
**Priyanka**⁵  
**Afzalur Rahman**⁶  

¹ VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India  
² Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman  
³ Economics and Business Studies Department, Mazoon College, Muscat, Oman  
⁴ School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  
⁵ Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India  
⁶ School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  

---

### Corresponding Author Contact Details

**Ram Soorat**  
Assistant Professor  
School of Technology  
Woxsen University  
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  
Email: [ram.soorat@woxsen.edu.in](mailto:ram.soorat@woxsen.edu.in)  
Telephone: +91 8455 305555  
ORCID: [https://orcid.org/0000-0001-7875-9197](https://orcid.org/0000-0001-7875-9197)  

---

### Co-Author Contact Information

- **Shahrukh Saleem:** Assistant Professor, VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India. Email: [shahrukh.saleem@vit.ac.in](mailto:shahrukh.saleem@vit.ac.in); ORCID: [https://orcid.org/0000-0003-2949-6188](https://orcid.org/0000-0003-2949-6188)
- **Araby Madbouly:** Associate Professor, Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman. Email: [araby@muscatcollege.edu.om](mailto:araby@muscatcollege.edu.om); ORCID: [0000-0002-7981-4191](https://orcid.org/0000-0002-7981-4191)
- **Uvesh Husain:** Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Oman. Email: [owais.husain@mazcol.edu.om](mailto:owais.husain@mazcol.edu.om); ORCID: [https://orcid.org/0000-0002-8502-8488](https://orcid.org/0000-0002-8502-8488)
- **Ram Soorat:** Assistant Professor, School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: [ram.soorat@woxsen.edu.in](mailto:ram.soorat@woxsen.edu.in); ORCID: [https://orcid.org/0000-0001-7875-9197](https://orcid.org/0000-0001-7875-9197)
- **Priyanka:** Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India. Email: [priyanka1@physics.du.ac.in](mailto:priyanka1@physics.du.ac.in); ORCID: [https://orcid.org/0009-0008-1520-0706](https://orcid.org/0009-0008-1520-0706)
- **Afzalur Rahman:** School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: [afzalur.rahman@woxsen.edu.in](mailto:afzalur.rahman@woxsen.edu.in); ORCID: [0000-0002-1561-561X](https://orcid.org/0000-0002-1561-561X)

---

### Acknowledgements

The authors are grateful to the seminar participants at the Sustainable Finance, Financial Econometrics, and Climate Economics Working Seminars for constructive discussions and feedback on earlier versions of this research. The authors also thank the data-verification team for assistance with archival regulatory filing cross-checks.

---

### Funding Statement

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

---

### Conflict of Interest Statement

The authors declare that they have no known competing financial interests, affiliations, or personal relationships that could have appeared to influence the work reported in this paper.

---

### Ethics Statement

This study analyzes publicly disclosed corporate financial, emissions, and contractual allocation disclosures and does not involve human participants, animal experimentation, or tissue samples. Institutional ethical review was not required.

---

### Data Availability Statement

{DATA_AVAIL}

---

### CRediT Author Contribution Statement

- **Shahrukh Saleem:** Conceptualization, Methodology, Formal analysis, Investigation, Writing – Original Draft, Writing – Review & Editing, Supervision, Project administration.
- **Araby Madbouly:** Resources, Data curation, Writing – Review & Editing.
- **Uvesh Husain:** Data curation, Formal analysis, Software, Writing – Review & Editing.
- **Ram Soorat:** Conceptualization, Methodology, Writing – Review & Editing, Validation, Supervision, Project administration.
- **Priyanka:** Data curation, Software, Formal analysis, Visualization, Writing – Review & Editing.
- **Afzalur Rahman:** Investigation, Visualization, Validation, Writing – Review & Editing.

---

### Declaration of Generative AI

Generative AI tools were used solely for code-formatting, bibliographic verification, and LaTeX/HTML typesetting assistance. No generative AI tool was used to perform statistical estimation, data curation, scientific interpretation, or formulate empirical conclusions. All AI-assisted outputs were reviewed and verified by the authors, who take full responsibility for the manuscript.

---

### Submission Declaration

This manuscript represents original work that has not been published previously and is not under consideration for publication elsewhere. All co-authors have approved the submitted manuscript and consent to its publication in *Journal of Sustainable Finance & Investment*.

---

*[End of Title Page Document]*
"""

with open(os.path.join(JSFI_DIR, "01_JSFI_Title_Page.md"), "w", encoding="utf-8") as f:
    f.write(tp_md_content)
print("Saved clean 01_JSFI_Title_Page.md")

# B. HTML
tp_html_content = f"""<!DOCTYPE html><html><head><meta charset='utf-8'><title>Title Page — Journal of Sustainable Finance & Investment</title><style>
    @page {{
        size: letter;
        margin: 1in;
    }}
    body {{
        font-family: 'Times New Roman', Times, serif;
        font-size: 12pt;
        line-height: 2.0;
        color: #111111;
        margin: 0;
        padding: 0;
    }}
    h1 {{
        font-family: 'Times New Roman', Times, serif;
        font-size: 16pt;
        font-weight: bold;
        line-height: 1.3;
        margin-top: 18pt;
        margin-bottom: 8pt;
        page-break-after: avoid;
    }}
    h2 {{
        font-family: 'Times New Roman', Times, serif;
        font-size: 14pt;
        font-weight: bold;
        line-height: 1.3;
        margin-top: 14pt;
        margin-bottom: 6pt;
        page-break-after: avoid;
    }}
    h3 {{
        font-family: 'Times New Roman', Times, serif;
        font-size: 12pt;
        font-weight: bold;
        line-height: 1.3;
        margin-top: 12pt;
        margin-bottom: 4pt;
        page-break-after: avoid;
    }}
    p {{
        margin-top: 0;
        margin-bottom: 6pt;
        text-align: justify;
    }}
    ul, ol {{
        margin-top: 0;
        margin-bottom: 8pt;
        padding-left: 24pt;
    }}
    li {{
        margin-bottom: 3pt;
    }}
    hr {{
        border: 0;
        border-top: 1pt solid #bbbbbb;
        margin: 14pt 0;
    }}
</style></head><body>

<h1>TITLE PAGE</h1>
<p style="font-size: 13pt; font-weight: bold; margin-bottom: 12pt;"><em>Journal of Sustainable Finance & Investment</em> (Taylor & Francis)</p>

<hr>

<p><strong>Full Title:</strong></p>
<p style="font-size: 14pt; font-weight: bold; line-height: 1.3;">Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing</p>

<p><strong>Running title (≤ 40 characters):</strong></p>
<p>{RUNNING_TITLE}</p>

<p><strong>Keywords:</strong></p>
<p>{KEYWORDS}</p>

<hr>

<h3>Authors and Affiliations</h3>
<p><strong>Shahrukh Saleem</strong>¹<br>
<strong>Araby Madbouly</strong>²<br>
<strong>Uvesh Husain</strong>³<br>
<strong>Ram Soorat</strong>⁴* <em>(Corresponding Author)</em><br>
<strong>Priyanka</strong>⁵<br>
<strong>Afzalur Rahman</strong>⁶</p>

<p>¹ VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India<br>
² Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman<br>
³ Economics and Business Studies Department, Mazoon College, Muscat, Oman<br>
⁴ School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India<br>
⁵ Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India<br>
⁶ School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India</p>

<hr>

<h3>Corresponding Author Contact Details</h3>
<p><strong>Ram Soorat</strong><br>
Assistant Professor<br>
School of Technology, Woxsen University<br>
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India<br>
Email: ram.soorat@woxsen.edu.in<br>
Telephone: +91 8455 305555<br>
ORCID: 0000-0001-7875-9197</p>

<hr>

<h3>Co-Author Contact Information</h3>
<ul>
    <li><strong>Shahrukh Saleem:</strong> Assistant Professor, VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India. Email: shahrukh.saleem@vit.ac.in; ORCID: 0000-0003-2949-6188</li>
    <li><strong>Araby Madbouly:</strong> Associate Professor, Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman. Email: araby@muscatcollege.edu.om; ORCID: 0000-0002-7981-4191</li>
    <li><strong>Uvesh Husain:</strong> Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Oman. Email: owais.husain@mazcol.edu.om; ORCID: 0000-0002-8502-8488</li>
    <li><strong>Ram Soorat:</strong> Assistant Professor, School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: ram.soorat@woxsen.edu.in; ORCID: 0000-0001-7875-9197</li>
    <li><strong>Priyanka:</strong> Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India. Email: priyanka1@physics.du.ac.in; ORCID: 0009-0008-1520-0706</li>
    <li><strong>Afzalur Rahman:</strong> School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: afzalur.rahman@woxsen.edu.in; ORCID: 0000-0002-1561-561X</li>
</ul>

<hr>

<h3>Acknowledgements</h3>
<p>The authors are grateful to the seminar participants at the Sustainable Finance, Financial Econometrics, and Climate Economics Working Seminars for constructive discussions and feedback on earlier versions of this research. The authors also thank the data-verification team for assistance with archival regulatory filing cross-checks.</p>

<hr>

<h3>Funding Statement</h3>
<p>This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.</p>

<hr>

<h3>Conflict of Interest Statement</h3>
<p>The authors declare that they have no known competing financial interests, affiliations, or personal relationships that could have appeared to influence the work reported in this paper.</p>

<hr>

<h3>Ethics Statement</h3>
<p>This study analyzes publicly disclosed corporate financial, emissions, and contractual allocation disclosures and does not involve human participants, animal experimentation, or tissue samples. Institutional ethical review was not required.</p>

<hr>

<h3>Data Availability Statement</h3>
<p>{DATA_AVAIL}</p>

<hr>

<h3>CRediT Author Contribution Statement</h3>
<ul>
    <li><strong>Shahrukh Saleem:</strong> Conceptualization, Methodology, Formal analysis, Investigation, Writing &ndash; Original Draft, Writing &ndash; Review &amp; Editing, Supervision, Project administration.</li>
    <li><strong>Araby Madbouly:</strong> Resources, Data curation, Writing &ndash; Review &amp; Editing.</li>
    <li><strong>Uvesh Husain:</strong> Data curation, Formal analysis, Software, Writing &ndash; Review &amp; Editing.</li>
    <li><strong>Ram Soorat:</strong> Conceptualization, Methodology, Writing &ndash; Review &amp; Editing, Validation, Supervision, Project administration.</li>
    <li><strong>Priyanka:</strong> Data curation, Software, Formal analysis, Visualization, Writing &ndash; Review &amp; Editing.</li>
    <li><strong>Afzalur Rahman:</strong> Investigation, Visualization, Validation, Writing &ndash; Review &amp; Editing.</li>
</ul>

<hr>

<h3>Declaration of Generative AI</h3>
<p>Generative AI tools were used solely for code-formatting, bibliographic verification, and LaTeX/HTML typesetting assistance. No generative AI tool was used to perform statistical estimation, data curation, scientific interpretation, or formulate empirical conclusions. All AI-assisted outputs were reviewed and verified by the authors, who take full responsibility for the manuscript.</p>

<hr>

<h3>Submission Declaration</h3>
<p>This manuscript represents original work that has not been published previously and is not under consideration for publication elsewhere. All co-authors have approved the submitted manuscript and consent to its publication in <em>Journal of Sustainable Finance & Investment</em>.</p>

</body></html>"""

with open(os.path.join(JSFI_DIR, "01_JSFI_Title_Page.html"), "w", encoding="utf-8") as f:
    f.write(tp_html_content)
print("Saved clean 01_JSFI_Title_Page.html (no Wiley, no blind duplicate)")

# C. LaTeX
tp_tex_template = r"""\documentclass[12pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage[margin=1in]{geometry}
\usepackage{setspace}
\doublespacing
\usepackage{xcolor}
\usepackage{enumitem}
\usepackage{hyperref}

\hypersetup{
    colorlinks=true,
    linkcolor=black,
    citecolor=black,
    urlcolor=blue!70!black
}

\begin{document}

\begin{center}
    {\Large \textbf{TITLE PAGE} \par}
    \vspace{0.4em}
    {\large \textit{Journal of Sustainable Finance \& Investment} (Taylor \& Francis) \par}
    \vspace{0.8em}
    \hrule
    \vspace{1.2em}
    {\LARGE \textbf{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing} \par}
    \vspace{0.8em}
    {\large \textbf{Running title ($\le$ 40 characters):} __RUNNING_TITLE_TEX__ \par}
    \vspace{0.5em}
    {\textbf{Keywords:} __KEYWORDS__ \par}
    \vspace{0.8em}
    \hrule
\end{center}

\vspace{1em}

\section*{Authors and Affiliations}

\textbf{Shahrukh Saleem}$^1$ \\
\textbf{Araby Madbouly}$^2$ \\
\textbf{Uvesh Husain}$^3$ \\
\textbf{Ram Soorat}$^{4*}$ \textit{(Corresponding Author)} \\
\textbf{Priyanka}$^5$ \\
\textbf{Afzalur Rahman}$^6$

\vspace{0.8em}

\noindent $^1$ VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India \\
$^2$ Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman \\
$^3$ Economics and Business Studies Department, Mazoon College, Muscat, Oman \\
$^4$ School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\
$^5$ Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India \\
$^6$ School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India

\vspace{1em}

\section*{Corresponding Author Contact Details}
\textbf{Ram Soorat} \\
Assistant Professor \\
School of Technology, Woxsen University \\
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\
Email: \url{ram.soorat@woxsen.edu.in} \\
Telephone: +91 8455 305555 \\
ORCID: \url{https://orcid.org/0000-0001-7875-9197}

\vspace{1em}

\section*{Co-Author Contact Information}
\begin{itemize}[leftmargin=1.5em,noitemsep]
    \item \textbf{Shahrukh Saleem:} Assistant Professor, VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India. Email: \url{shahrukh.saleem@vit.ac.in}; ORCID: \url{https://orcid.org/0000-0003-2949-6188}
    \item \textbf{Araby Madbouly:} Associate Professor, Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman. Email: \url{araby@muscatcollege.edu.om}; ORCID: \url{https://orcid.org/0000-0002-7981-4191}
    \item \textbf{Uvesh Husain:} Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Oman. Email: \url{owais.husain@mazcol.edu.om}; ORCID: \url{https://orcid.org/0000-0002-8502-8488}
    \item \textbf{Ram Soorat:} Assistant Professor, School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: \url{ram.soorat@woxsen.edu.in}; ORCID: \url{https://orcid.org/0000-0001-7875-9197}
    \item \textbf{Priyanka:} Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India. Email: \url{priyanka1@physics.du.ac.in}; ORCID: \url{https://orcid.org/0009-0008-1520-0706}
    \item \textbf{Afzalur Rahman:} School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: \url{afzalur.rahman@woxsen.edu.in}; ORCID: \url{https://orcid.org/0000-0002-1561-561X}
\end{itemize}

\vspace{1em}

\section*{Acknowledgements}
The authors are grateful to the seminar participants at the Sustainable Finance, Financial Econometrics, and Climate Economics Working Seminars for constructive discussions and feedback on earlier versions of this research. The authors also thank the data-verification team for assistance with archival regulatory filing cross-checks.

\vspace{1em}

\section*{Funding Statement}
This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

\vspace{1em}

\section*{Conflict of Interest Statement}
The authors declare that they have no known competing financial interests, affiliations, or personal relationships that could have appeared to influence the work reported in this paper.

\vspace{1em}

\section*{Ethics Statement}
This study analyzes publicly disclosed corporate financial, emissions, and contractual allocation disclosures and does not involve human participants, animal experimentation, or tissue samples. Institutional ethical review was not required.

\vspace{1em}

\section*{Data Availability Statement}
__DATA_AVAIL__

\vspace{1em}

\section*{CRediT Author Contribution Statement}
\begin{itemize}[leftmargin=1.5em,noitemsep]
    \item \textbf{Shahrukh Saleem:} Conceptualization, Methodology, Formal analysis, Investigation, Writing -- Original Draft, Writing -- Review \& Editing, Supervision, Project administration.
    \item \textbf{Araby Madbouly:} Resources, Data curation, Writing -- Review \& Editing.
    \item \textbf{Uvesh Husain:} Data curation, Formal analysis, Software, Writing -- Review \& Editing.
    \item \textbf{Ram Soorat:} Conceptualization, Methodology, Writing -- Review \& Editing, Validation, Supervision, Project administration.
    \item \textbf{Priyanka:} Data curation, Software, Formal analysis, Visualization, Writing -- Review \& Editing.
    \item \textbf{Afzalur Rahman:} Investigation, Visualization, Validation, Writing -- Review \& Editing.
\end{itemize}

\vspace{1em}

\section*{Declaration of Generative AI}
Generative AI tools were used solely for code-formatting, bibliographic verification, and LaTeX/HTML typesetting assistance. No generative AI tool was used to perform statistical estimation, data curation, scientific interpretation, or formulate empirical conclusions. All AI-assisted outputs were reviewed and verified by the authors, who take full responsibility for the manuscript.

\vspace{1em}

\section*{Submission Declaration}
This manuscript represents original work that has not been published previously and is not under consideration for publication elsewhere. All co-authors have approved the submitted manuscript and consent to its publication in \textit{Journal of Sustainable Finance \& Investment}.

\end{document}
"""

tp_tex_content = tp_tex_template.replace("__RUNNING_TITLE_TEX__", RUNNING_TITLE_TEX)
tp_tex_content = tp_tex_content.replace("__KEYWORDS__", KEYWORDS)
tp_tex_content = tp_tex_content.replace("__DATA_AVAIL__", DATA_AVAIL)

with open(os.path.join(LATEX_DIR, "01_JSFI_Title_Page.tex"), "w", encoding="utf-8") as f:
    f.write(tp_tex_content)
print("Saved clean 01_JSFI_Title_Page.tex")


# ==============================================================================
# 2. UPDATE 02_JSFI_Anonymous_Manuscript (.md, .html, .tex)
# ==============================================================================
print("\n--- 2. Updating 02_JSFI_Anonymous_Manuscript ---")

# A. Markdown
m_md_path = os.path.join(JSFI_DIR, "02_JSFI_Anonymous_Manuscript.md")
with open(m_md_path, "r", encoding="utf-8") as f:
    m_md = f.read()

# Update Running Title
m_md = re.sub(
    r'\*\*Running title:\*\*[^\n]+',
    f'**Running title:** {RUNNING_TITLE}',
    m_md
)
# Update Keywords
m_md = re.sub(
    r'\*\*Keywords:\*\*[^\n]+',
    f'**Keywords:** {KEYWORDS}',
    m_md
)
# Soften Conclusion sentence
cautious_conclusion = "Within the observed sample, stronger post-issuance decarbonization associations are concentrated among issuers allocating proceeds toward new capital projects, whereas refinancing-dominated allocations exhibit weaker environmental trajectories."

m_md = re.sub(
    r'labeled green debt is associated with physical corporate decarbonization when structured to finance incremental capital formation, but functions as balance-sheet liability management when directed toward refinancing\.',
    cautious_conclusion,
    m_md
)
m_md = re.sub(
    r'green-bond market expansion is associated with meaningful decarbonization only when directed toward new capital projects[^\n\.]*\.',
    cautious_conclusion,
    m_md
)

with open(m_md_path, "w", encoding="utf-8") as f:
    f.write(m_md)
print("Updated 02_JSFI_Anonymous_Manuscript.md (running title, keywords, cautious conclusion)")

# B. HTML
m_html_path = os.path.join(JSFI_DIR, "02_JSFI_Anonymous_Manuscript.html")
with open(m_html_path, "r", encoding="utf-8") as f:
    m_html = f.read()

m_html = re.sub(
    r'<strong>Running title:</strong>[^\n<]+',
    f'<strong>Running title:</strong> {RUNNING_TITLE}',
    m_html
)
m_html = re.sub(
    r'<strong>Keywords:</strong>[^\n<]+',
    f'<strong>Keywords:</strong> {KEYWORDS}',
    m_html
)
m_html = re.sub(
    r'For sustainable development, these findings indicate that green-bond market expansion is associated with meaningful decarbonization only when directed toward new capital projects[^\n\.<]+',
    cautious_conclusion,
    m_html
)

with open(m_html_path, "w", encoding="utf-8") as f:
    f.write(m_html)
print("Updated 02_JSFI_Anonymous_Manuscript.html (running title, keywords, cautious conclusion)")

# C. LaTeX
m_tex_path = os.path.join(LATEX_DIR, "02_JSFI_Anonymous_Manuscript.tex")
with open(m_tex_path, "r", encoding="utf-8") as f:
    m_tex = f.read()

m_tex = re.sub(
    r'\\textbf\{Running title:\}[^\n\\]+',
    f'\\\\textbf{{Running title:}} {RUNNING_TITLE_TEX}',
    m_tex
)
m_tex = re.sub(
    r'\\noindent \\textbf\{Keywords:\}[^\n\\]+',
    f'\\\\noindent \\\\textbf{{Keywords:}} {KEYWORDS} \\\\',
    m_tex
)
m_tex = m_tex.replace(
    "Within the observed sample, stronger post-issuance decarbonization is associated with greater allocation to new capital projects, while refinancing-dominated transactions exhibit a different trajectory.",
    cautious_conclusion
)

with open(m_tex_path, "w", encoding="utf-8") as f:
    f.write(m_tex)
print("Updated 02_JSFI_Anonymous_Manuscript.tex (running title, keywords, cautious conclusion)")


# ==============================================================================
# 3. UPDATE 04_JSFI_Cover_Letter (.md, .html, .tex)
# ==============================================================================
print("\n--- 3. Updating 04_JSFI_Cover_Letter ---")

cl_md_path = os.path.join(JSFI_DIR, "04_JSFI_Cover_Letter.md")
with open(cl_md_path, "r", encoding="utf-8") as f:
    cl_md = f.read()
cl_md = re.sub(
    r'\*\*Running Title:\*\*[^\n]+',
    f'**Running Title:** *{RUNNING_TITLE}*',
    cl_md
)
with open(cl_md_path, "w", encoding="utf-8") as f:
    f.write(cl_md)

cl_html_path = os.path.join(JSFI_DIR, "04_JSFI_Cover_Letter.html")
with open(cl_html_path, "r", encoding="utf-8") as f:
    cl_html = f.read()
cl_html = re.sub(
    r'<strong>Running Title:</strong>[^\n<]+',
    f'<strong>Running Title:</strong> <em>{RUNNING_TITLE}</em>',
    cl_html
)
with open(cl_html_path, "w", encoding="utf-8") as f:
    f.write(cl_html)

cl_tex_path = os.path.join(LATEX_DIR, "04_JSFI_Cover_Letter.tex")
with open(cl_tex_path, "r", encoding="utf-8") as f:
    cl_tex = f.read()
cl_tex = re.sub(
    r'\\textbf\{Running Title:\}[^\n\\]+',
    f'\\\\textbf{{Running Title:}} \\\\textit{{{RUNNING_TITLE_TEX}}}',
    cl_tex
)
with open(cl_tex_path, "w", encoding="utf-8") as f:
    f.write(cl_tex)

print("Cover letter running title standardized across formats.")
print("\nAll source files updated successfully!")
