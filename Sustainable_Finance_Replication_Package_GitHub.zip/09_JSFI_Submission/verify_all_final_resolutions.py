import os
import pypdf
import re

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')

print("=" * 60)
print("COMPREHENSIVE FINAL VERIFICATION OF ALL 5 RESOLUTIONS")
print("=" * 60)

# ----------------------------------------------------
# 1. Check Cover Letter (Word and LaTeX PDFs)
# ----------------------------------------------------
print("\n--- 1. COVER LETTER RUNNING TITLE VERIFICATION ---")
cl_word_pdf = os.path.join(jsfi_dir, "04_JSFI_Cover_Letter.pdf")
cl_latex_pdf = os.path.join(jsfi_dir, "04_JSFI_Cover_Letter_LaTeX.pdf")

def verify_cover_letter(pdf_path, name):
    reader = pypdf.PdfReader(pdf_path)
    text = reader.pages[0].extract_text() or ''
    # Look for Running Title
    rt_match = re.search(r'Running Title:\s*(.*)', text)
    if rt_match:
        rt_text = rt_match.group(1).split('\n')[0].strip()
        print(f"[{name}] Running Title found: '{rt_text}'")
        if "Trajectories" in rt_text or "EmissionsGreen" in rt_text or "Green-Bond Allocation and" in rt_text:
            print(f"  [FAIL] Duplicated running title detected in {name}!")
        elif "Green-Bond Allocation & Emissions" in rt_text or "Green-Bond Allocation \\& Emissions" in rt_text:
            print(f"  [PASS] Clean exact running title confirmed in {name}!")
        else:
            print(f"  [NOTE] {rt_text}")
    else:
        print(f"  [FAIL] Running Title not found in {name}!")

verify_cover_letter(cl_word_pdf, "Word-derived Cover Letter")
verify_cover_letter(cl_latex_pdf, "LaTeX-derived Cover Letter")

# ----------------------------------------------------
# 2. Check Placeholders in Supplementary Material
# ----------------------------------------------------
print("\n--- 2. SUPPLEMENTARY MATERIAL PLACEHOLDER VERIFICATION ---")
supp_word_pdf = os.path.join(jsfi_dir, "03_JSFI_Supplementary_Material.pdf")
supp_latex_pdf = os.path.join(jsfi_dir, "03_JSFI_Supplementary_Material_LaTeX.pdf")

def check_placeholders_and_tables(pdf_path, name):
    reader = pypdf.PdfReader(pdf_path)
    print(f"\nChecking {name} ({len(reader.pages)} pages)...")
    placeholder_found = False
    table_table_found = False
    s12_complete = False
    s14_found = False
    s14b_found = False
    s15_found = False
    
    for i, page in enumerate(reader.pages):
        t = page.extract_text() or ''
        if "[Table" in t or "missing]" in t or "missing ]" in t:
            print(f"  [FAIL] Placeholder found on page {i+1}:")
            for line in t.split('\n'):
                if "[Table" in line or "missing" in line:
                    print(f"    {line.strip()}")
            placeholder_found = True
        
        if "Table Table" in t:
            print(f"  [FAIL] 'Table Table' found on page {i+1}!")
            table_table_found = True
            
        if "Table S12" in t and "Confusion Matrix" in t:
            # Check for numbers in confusion matrix: 44, 32, 23, 120
            if "44" in t and "32" in t and "23" in t and "120" in t:
                s12_complete = True
                print(f"  [PASS] Table S12 Confusion Matrix found on page {i+1} with full numerical cells (44, 32, 23, 120).")
                
        if "Table S14." in t and "Proceeds Allocation" in t:
            s14_found = True
            print(f"  [PASS] Table S14 (Complete 42-Issuer Dataset) found on page {i+1}.")
            
        if "Table S14b" in t:
            s14b_found = True
            print(f"  [PASS] Table S14b (Comprehensive Provenance Map) found on page {i+1}.")
            
        if "Table S15." in t and "Corporate Case Studies" in t:
            s15_found = True
            print(f"  [PASS] Table S15 (Audited Corporate Case Studies) found on page {i+1}.")

    if not placeholder_found:
        print("  [PASS] ZERO missing table placeholders found in entire document!")
    if not table_table_found:
        print("  [PASS] ZERO 'Table Table' duplications found in entire document!")
    if s12_complete:
        print("  [PASS] Table S12 3x3 confusion matrix is fully populated with data!")
    else:
        print("  [FAIL] Table S12 confusion matrix missing or incomplete!")
    if s14_found:
        print("  [PASS] Table S14 is present and populated!")
    else:
        print("  [FAIL] Table S14 not found!")
    if s14b_found:
        print("  [PASS] Table S14b is present and populated!")
    else:
        print("  [FAIL] Table S14b not found!")
    if s15_found:
        print("  [PASS] Table S15 is present and populated!")
    else:
        print("  [FAIL] Table S15 not found!")

check_placeholders_and_tables(supp_word_pdf, "Word-derived Supplementary PDF")
check_placeholders_and_tables(supp_latex_pdf, "LaTeX-derived Supplementary PDF")

# ----------------------------------------------------
# 3. Check Table S14b Landscape Orientation & Repeated Headers
# ----------------------------------------------------
print("\n--- 3. TABLE S14B LANDSCAPE FORMATTING VERIFICATION ---")
def verify_landscape(pdf_path, name):
    reader = pypdf.PdfReader(pdf_path)
    landscape_pages = []
    headers_on_pages = []
    
    for idx, page in enumerate(reader.pages):
        box = page.mediabox
        width = float(box.width)
        height = float(box.height)
        if width > height:
            landscape_pages.append(idx + 1)
            t = page.extract_text() or ''
            has_hdr = ("Issuer Name" in t or "Legal Debt" in t)
            headers_on_pages.append((idx + 1, has_hdr))
            
    print(f"[{name}] Total pages: {len(reader.pages)}")
    print(f"  Landscape pages ({len(landscape_pages)}): {landscape_pages}")
    all_headers_present = all(h[1] for h in headers_on_pages)
    if all_headers_present and len(landscape_pages) > 0:
        print(f"  [PASS] All {len(landscape_pages)} landscape pages have repeated column headers!")
    else:
        print(f"  [WARN] Repeated headers status: {headers_on_pages}")

verify_landscape(supp_word_pdf, "Word-derived Supplementary PDF")
verify_landscape(supp_latex_pdf, "LaTeX-derived Supplementary PDF")

print("\n" + "=" * 60)
print("ALL VERIFICATIONS COMPLETED!")
print("=" * 60)
