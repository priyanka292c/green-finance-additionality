import os
import sys
import re
import shutil
import subprocess

submission_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')
sd_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\08_Wiley_SD_Submission')
latex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'
bibtex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe'

print(f"Submission directory: {submission_dir}")
print(f"LaTeX binary: {latex_bin}")
