import os
import re

sd_manuscript_path = r'08_Wiley_SD_Submission\LaTeX_Source\sd_blinded_manuscript.tex'
sd_supp_path = r'08_Wiley_SD_Submission\LaTeX_Source\sd_supplementary.tex'
out_manuscript_path = r'09_JSFI_Submission\LaTeX_Source\02_JSFI_Anonymous_Manuscript.tex'
out_supp_path = r'09_JSFI_Submission\LaTeX_Source\03_JSFI_Supplementary_Material.tex'

with open(sd_manuscript_path, 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update Title and Front Matter
text = text.replace(
    r"\title{Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development}",
    r"\title{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing}"
)
text = text.replace(
    r"{\Large \textbf{Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development} \par}",
    r"{\Large \textbf{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing} \par}"
)
text = text.replace(
    r"{\normalsize \textbf{Running title:} Green Bond Allocation \& Sustainability \par}",
    r"{\normalsize \textbf{Running title:} Green-Bond Allocation \& Environmental Additionality \par}"
)
text = text.replace(
    r"{\small \textit{Blind Manuscript Submitted to Wiley Journal ``Sustainable Development''} \par}",
    r"{\small \textit{Anonymous Manuscript Submitted to ``Journal of Sustainable Finance \& Investment''} \par}"
)
text = text.replace(
    r"\onehalfspacing",
    r"\doublespacing"
)

# 2. Update Abstract and Keywords
old_abstract_marker = r"\begin{abstract}"
old_abstract_end = r"\end{abstract}"

new_abstract = r"""\begin{abstract}
\noindent
Green bonds are designed to channel financial capital toward environmentally beneficial activities, but their real-economy environmental implications depend critically on whether proceeds finance genuinely new green investment or refinance existing eligible assets. Most empirical green-bond studies treat issuance as a relatively homogeneous financial instrument and pay insufficient attention to contractual proceeds allocation. Using an audited panel of 84 multinational corporations---comprising 42 corporate environmental-use-of-proceeds bond issuers (38 qualifying ICMA Green Bonds and 4 corporate Sustainability Bonds with qualifying environmental allocations) and 42 propensity-score-matched comparison firms---observed annually over 2013--2024 (1,008 firm-years), we implement a Callaway--Sant'Anna staggered difference-in-differences design. Environmental-debt issuance is associated overall with an 8.91\% reduction in Scope 1+2 emissions (CS ATT = $-0.0934, p < 0.001$), a 9.67\% decline in carbon intensity (CS ATT = $-0.1017, p < 0.001$), and a 7.32 percentage-point expansion in green capital expenditure share (net non-bond green CapEx diagnostic: +6.60 pp, $p < 0.001$). However, environmental trajectories vary systematically with contractual proceeds allocation: each 10 percentage-point allocation to new green capital projects is associated with an incremental $-1.59\%$ post-issuance emissions differential. Issuers allocating predominantly to new physical projects ($N = 31$) achieve an average post-issuance emissions reduction of $-6.31\%$ (model-implied differential at 100\% allocation: $-8.77\%$), whereas an exploratory cohort of five refinancing-dominated issuers exhibits a relative post-issuance divergence of +3.88\% from matched controls. In contrast, commercial ESG ratings increase similarly across allocation types (difference = $+0.0042\sigma, p = 0.927$; TOST equivalence $p = 0.0168$), indicating limited differentiation in rating adjustments despite divergent physical outcomes. These findings provide empirical evidence that sustainable-finance instrument design matters for real-economy environmental outcomes, informing green-bond eligibility criteria, allocation reporting, and carbon-accounting verification in sustainable-finance markets.

\vspace{0.8em}
\noindent \textbf{Keywords:} Sustainable finance; Green bonds; Proceeds allocation; Environmental additionality; Corporate decarbonization; ESG disclosure; Climate finance; Carbon accounting \\
\noindent \textbf{JEL Classifications:} G12, G14, G31, G32, Q54, Q56, Q58
\end{abstract}"""

text = re.sub(r'\\begin\{abstract\}.*?\\end\{abstract\}', lambda m: new_abstract, text, flags=re.DOTALL)

# 3. Update Section and Subsection Headings to exact JSFI structure
replacements = [
    # Section 2
    (r'\subsection{Sustainable Finance and Environmental Outcomes}', r'\subsection{Sustainable Finance and Green Financial Instruments}'),
    (r'\subsection{Green Bonds and Environmental Additionality}', r'\subsection{Green Bonds and Sustainable Investment}'),
    (r'\subsection{Green Investment, Corporate Decarbonization, and SDG 13}', r'\subsection{Proceeds Allocation and Environmental Additionality}'),
    (r'\subsection{Refinancing versus New-Project Financing}', r'\subsection{Green Finance and Corporate Environmental Performance}'),
    (r'\subsection{ESG Measurement and Rating Differentiation}', r'\subsection{ESG Ratings, Carbon Accounting and Disclosure}'),
    
    # Section 3
    (r'\subsection{Mechanism: Proceeds Allocation and Environmental Performance}', 
     r'\subsection{Financing Additionality}\n\label{sec:fin_add}\n'
     r'Under capital rationing and financial frictions \citep{myers1977, holmstrom_tirole1997, stiglitz_weiss1981}, corporate issuers face upward-sloping credit supply curves. Financing additionality refers to whether green debt expands the total financial capital envelope available to the firm for pro-environmental investment. Theoretical models suggest that by attracting specialized ESG clienteles and generating a borrowing cost discount (the greenium), green bonds can relax credit constraints, enabling investments that would otherwise fail internal hurdle rates \citep{baker2018, zerbib2019}.\n\n'
     r'\subsection{Investment Additionality}\n\label{sec:inv_add}\n'
     r'Investment additionality requires that debt proceeds be transformed into incremental, new physical capital formation rather than the relabeling or restructuring of existing assets. When proceeds finance greenfield construction or facility retrofits, the firm\'s physical green capital stock expands ($\Delta K_{\text{green}} > 0$). When proceeds refinance debt on pre-existing operational assets, financial liabilities are restructured, but the physical capital stock remains unchanged ($\Delta K_{\text{green}} = 0$).\n\n'
     r'\subsection{Environmental Additionality}\n\label{sec:env_add}\n'
     r'Environmental additionality represents the physical decarbonization outcome: whether post-issuance operational greenhouse gas emissions (Scope 1 and Scope 2) decline relative to the counterfactual trajectory. Environmental additionality is a physical consequence of investment additionality: new low-carbon physical assets displace carbon-intensive operational processes, lowering emissions. Refinancing mature assets, by contrast, produces no incremental displacement, yielding no contemporaneous environmental additionality.'),
    
    # Section 4
    (r'\section{Data and Methods}', r'\section{Data and Methodology}'),
    (r'\subsection{Sample Construction}', r'\subsection{Sample Construction}'),
    (r'\subsection{Matched Comparison Group}', r'\subsection{Propensity-Score Matching}'),
    (r'\subsection{Proceeds Allocation Measurement}', r'\subsection{Green-Bond Proceeds Allocation}'),
    (r'\subsection{Econometric Design}', 
     r'\subsection{Environmental and Investment Measures}\n'
     r'Our primary environmental outcome is the natural logarithm of corporate Scope 1 (direct combustion) and Scope 2 (purchased electricity and heat) operational emissions in metric tCO$_2$e under the GHG Protocol Corporate Standard \citep{ref_ghg_2004}. Carbon intensity is measured as $\ln(\text{Scope 1+2}/\text{Revenue})$. Pro-environmental investment is measured through gross green CapEx share and our novel net non-bond green CapEx share benchmark deducting annualized focal-bond proceeds.\n\n'
     r'\subsection{ESG Measures}\n'
     r'Commercial ESG ratings are constructed as within-provider and within-sector standardized $z$-scores ($\text{ESG\_norm}$) spanning MSCI ESG Research, S\&P Global Trucost, and Refinitiv ESG, neutralizing provider-level methodological scale differences \citep{berg2022, christensen2022}.\n\n'
     r'\subsection{Callaway--Sant\'Anna Estimation}'),
    
    # Section 5
    (r'\subsection{Overall Post-Issuance Decarbonization and Dynamic Trajectories}', 
     r'\subsection{Green-Bond Financing and Environmental Outcomes}'),
    (r'\subsection{Corporate Green Investment Mechanism: Gross vs. Net CapEx}', 
     r'\subsection{Green Investment Response}'),
    (r'\subsection{Cohort-Aligned Pre-Treatment Parallel-Trend Diagnostic}', 
     r'\subsection{Dynamic Effects}'),
    (r'\subsection{Proceeds Allocation and Environmental Heterogeneity}', 
     r'\subsection{New-Project versus Refinancing Allocation}'),
    (r'\subsection{Commercial ESG Rating Differentiation Diagnostic}', 
     r'\subsection{ESG Rating Response}'),
    (r'\subsection{External Verification and Leverage Heterogeneity}', 
     r'\subsection{Verification and Leverage Heterogeneity}'),
    (r'\subsection{NLP Allocation Classification Validation}', 
     r'\subsection{Robustness Analysis}'),
     
    # Section 6
    (r'\section{Discussion and Sustainable Development Implications}', r'\section{Discussion}'),
    (r'\subsection{Proceeds Allocation and Post-Issuance Environmental Trajectories}', 
     r'\subsection{Implications for Sustainable Finance}\n'
     r'Our empirical findings establish that corporate green bonds are neither uniformly transformative nor merely symbolic. Post-issuance decarbonization is governed by contractual proceeds allocation: labeled debt drives real-economy abatement only when structured to fund incremental green capital formation.\n\n'
     r'\subsection{Implications for Green-Bond Design}'),
    (r'\subsection{Implications for Sustainable Development}', 
     r'\subsection{ESG and Carbon-Accounting Implications}\n'
     r'The documented divergence between physical emissions trajectories and commercial ESG rating adjustments underscores a structural measurement challenge in sustainable capital markets. Rating systems reward labeled debt issuance as a governance commitment without verifying whether proceeds fund incremental decarbonization.\n\n'
     r'\subsection{Implications for Investors}\n'
     r'For sustainable investors seeking real-world climate additionality, proceeds allocation is the primary metric distinguishing genuine green capital formation from liability restructuring.'),
    (r'\subsection{Policy Implications}', r'\subsection{Policy Implications}'),
    (r'\section{Limitations}', r'\section{Limitations and Future Research}')
]

for old, new in replacements:
    text = text.replace(old, new)

# Add Declaration of Interest statement before References
if r"\subsection*{Declaration of Interest}" not in text:
    interest_stmt = r"""\subsection*{Declaration of Interest}
The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

"""
    text = text.replace(r"\subsection*{Declaration of Generative AI}", interest_stmt + r"\subsection*{Declaration of Generative AI}")

with open(out_manuscript_path, 'w', encoding='utf-8') as f:
    f.write(text)
print(f"Wrote {out_manuscript_path} ({len(text):,} chars)")

# 4. Update Supplementary Material
with open(sd_supp_path, 'r', encoding='utf-8') as f:
    stext = f.read()

stext = stext.replace(
    r"{\LARGE \textbf{Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development} \par}",
    r"{\LARGE \textbf{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing} \par}"
)
stext = stext.replace(
    r"{\small \textit{Submitted to Wiley Journal ``Sustainable Development''} \par}",
    r"{\small \textit{Supplementary Material Submitted to ``Journal of Sustainable Finance \& Investment''} \par}"
)
stext = stext.replace(r"\onehalfspacing", r"\doublespacing")

with open(out_supp_path, 'w', encoding='utf-8') as f:
    f.write(stext)
print(f"Wrote {out_supp_path} ({len(stext):,} chars)")
