import os
import pypdf
import re

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')

print("=" * 70)
print("FINAL COMPREHENSIVE VERIFICATION: DISCUSSION WORDING & COVER LETTER")
print("=" * 70)

# 1. Manuscript Section 6.1 and 6.2
print("\n--- 1. MANUSCRIPT SECTION 6 DISCUSSION WORDING VERIFICATION ---")
man_word_pdf = os.path.join(jsfi_dir, "02_JSFI_Anonymous_Manuscript.pdf")
man_latex_pdf = os.path.join(jsfi_dir, "02_JSFI_Anonymous_Manuscript_LaTeX.pdf")

bad_s6_1 = "neither uniformly effective nor merely symbolic"
bad_s6_2 = "neither uniformly transformative nor uniformly ineffective"
target_s6_1 = "Our findings indicate that post-issuance environmental trajectories vary with contractual proceeds allocation"
target_s6_2 = "Our empirical findings indicate that post-issuance environmental performance varies systematically with the contractual use of proceeds"

for m_path, m_name in [(man_word_pdf, "Word-derived Manuscript PDF"), (man_latex_pdf, "LaTeX-derived Manuscript PDF")]:
    reader = pypdf.PdfReader(m_path)
    full_text = " ".join((page.extract_text() or "") for page in reader.pages)
    
    # Normalize whitespaces and line breaks
    full_text_clean = " ".join(full_text.split())
    
    # Robust check allowing hyphenations/spaces:
    patt_1 = re.compile(r"Our\s+findings\s+indicate\s+that\s+post[\s\-]*issuance\s+environmental\s+trajectories\s+vary\s+with\s+contractual\s+proceeds\s+allocation", re.IGNORECASE)
    patt_2 = re.compile(r"Our\s+empirical\s+findings\s+indicate\s+that\s+post[\s\-]*issuance\s+environmental\s+performance\s+varies\s+sys[\s\-]*tematically\s+with\s+the\s+contractual\s+use\s+of\s+proceeds", re.IGNORECASE)

    has_bad_1 = bool(re.search(r"neither\s+uniformly\s+effective\s+nor\s+merely\s+symbolic", full_text_clean, re.I))
    has_bad_2 = bool(re.search(r"neither\s+uniformly\s+transformative\s+nor\s+uniformly\s+ineffective", full_text_clean, re.I))
    has_target_1 = bool(patt_1.search(full_text_clean))
    has_target_2 = bool(patt_2.search(full_text_clean))
    
    print(f"[{m_name}]")
    print(f"  Old Section 6.1 causal sentence present: {has_bad_1} (Expected: False)")
    print(f"  Old Section 6.2 causal sentence present: {has_bad_2} (Expected: False)")
    print(f"  New Section 6.1 observational target:   {has_target_1} (Expected: True)")
    print(f"  New Section 6.2 observational target:   {has_target_2} (Expected: True)")

# 2. Cover Letter Heading
print("\n--- 2. COVER LETTER HEADING VERIFICATION ---")
cl_word_pdf = os.path.join(jsfi_dir, "04_JSFI_Cover_Letter.pdf")
cl_latex_pdf = os.path.join(jsfi_dir, "04_JSFI_Cover_Letter_LaTeX.pdf")

bad_cl_heading = "Instrument Design and Proceeds Allocation"
target_cl_heading = "Proceeds Allocation and Treatment Design"

for cl_path, cl_name in [(cl_word_pdf, "Word-derived Cover Letter PDF"), (cl_latex_pdf, "LaTeX-derived Cover Letter PDF")]:
    reader = pypdf.PdfReader(cl_path)
    full_text = " ".join((page.extract_text() or "") for page in reader.pages)
    full_text_clean = " ".join(full_text.split())
    
    has_bad_cl = bad_cl_heading in full_text_clean
    has_target_cl = target_cl_heading in full_text_clean
    
    print(f"[{cl_name}]")
    print(f"  Old heading 'Instrument Design...' present: {has_bad_cl} (Expected: False)")
    print(f"  New heading 'Proceeds Allocation...' present: {has_target_cl} (Expected: True)")

# 3. Running title verification
print("\n--- 3. RUNNING TITLE VERIFICATION ---")
for cl_path, cl_name in [(cl_word_pdf, "Word-derived Cover Letter PDF"), (cl_latex_pdf, "LaTeX-derived Cover Letter PDF")]:
    reader = pypdf.PdfReader(cl_path)
    t = reader.pages[0].extract_text() or ""
    clean_rt = "Green-Bond Allocation & Emissions" in t or "Green-Bond Allocation \\& Emissions" in t
    has_dup = "Trajectories" in t or "EmissionsGreen" in t or "Green-Bond Allocation and" in t
    print(f"[{cl_name}] Clean RT present: {clean_rt} | Duplication present: {has_dup}")

# 4. Supplementary file check
print("\n--- 4. SUPPLEMENTARY MATERIAL FINAL INTEGRITY ---")
supp_word_pdf = os.path.join(jsfi_dir, "03_JSFI_Supplementary_Material.pdf")
supp_latex_pdf = os.path.join(jsfi_dir, "03_JSFI_Supplementary_Material_LaTeX.pdf")

for sp_path, sp_name in [(supp_word_pdf, "Word-derived Supp PDF"), (supp_latex_pdf, "LaTeX-derived Supp PDF")]:
    reader = pypdf.PdfReader(sp_path)
    full_text = " ".join((page.extract_text() or "") for page in reader.pages)
    has_placeholder = "[Table" in full_text or "missing]" in full_text
    has_table_table = "Table Table" in full_text
    has_bad_clause = "that motivate the Callaway" in full_text
    print(f"[{sp_name}] Placeholders: {has_placeholder} | 'Table Table': {has_table_table} | Bad clause: {has_bad_clause}")

print("\n" + "=" * 70)
print("ALL FINAL EDITORIAL CHECKS COMPLETE!")
print("=" * 70)
