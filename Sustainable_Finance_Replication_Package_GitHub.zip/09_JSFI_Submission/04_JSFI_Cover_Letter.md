29 September 2026

**SUBMISSION OF ORIGINAL RESEARCH MANUSCRIPT**

**Manuscript Title:** *Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing*  
**Running Title:** *Green-Bond Allocation & Emissions*

Dear Editor-in-Chief and Editorial Board Members,

We submit our empirical manuscript, entitled **“Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing,”** for consideration for publication in the *Journal of Sustainable Finance & Investment* (JSF&I).

### Research Question and Alignment with JSF&I Scope
The paper investigates a central question in sustainable finance: *Does the contractual allocation of green-bond proceeds between new green capital projects and refinancing of existing eligible assets affect the subsequent environmental and investment trajectories of issuing corporations?*

Existing empirical literature in sustainable finance has focused primarily on secondary-market pricing (the greenium) and aggregate ESG score responses, typically treating green-bond issuance as a binary intervention. In doing so, prior research pays limited attention to internal contractual proceeds deployment: whether proceeds fund new physical green capital expenditures or restructure liabilities on pre-existing operational assets.

### Key Contributions
Using a manually audited panel of 84 corporations (42 corporate environmental-use-of-proceeds bond issuers and 42 propensity-score-matched peers, 1,008 firm-years over 2013–2024), we examine this question using a Callaway and Sant’Anna (2021) staggered difference-in-differences design:

1. **Proceeds Allocation and Treatment Design:** We show that post-issuance emissions trajectories vary with contractual proceeds allocation. In our continuous specification, each 10 percentage-point allocation to new capital projects is associated with an incremental −1.59% post-issuance emissions differential ($p < 0.001$).
2. **New Projects vs. Refinancing:** Issuers allocating predominantly to new physical projects ($N = 31$) are associated with an average post-issuance emissions reduction of −6.31% relative to matched controls. In contrast, an exploratory cohort of five refinancing-dominated issuers exhibits a relative post-issuance divergence of +3.88% from matched controls, though inference for this subgroup is uncertain ($p = 0.7015$ under cluster randomization inference). The refinancing subgroup is interpreted as exploratory heterogeneity evidence rather than a standalone causal estimate.
3. **Capital Formation:** Green-debt issuance is associated with a 7.32 percentage-point expansion in green capital expenditure share, which remains positive at +6.60 percentage points under an accounting-adjusted diagnostic deducting focal-bond proceeds.
4. **Commercial ESG Ratings:** Commercial ESG ratings exhibit similar positive adjustments (+0.90σ vs. +0.91σ; difference = +0.0042σ, $p = 0.927$; TOST equivalence $p = 0.0168$) across allocation types despite differences in physical emissions trajectories, documenting limited differentiation in rating adjustments.

### Methodological Framing
Because treatment adoption is observational, our estimates are interpreted as differential post-issuance trajectories across allocation profiles rather than exogenous causal effects. We acknowledge that matching balances observed financial metrics but cannot eliminate unobserved characteristics such as managerial climate ambition or internal project pipelines.

The manuscript is original, has not been published elsewhere, and is not under consideration by any other journal. All co-authors have approved the submission.

Thank you for your consideration.

Sincerely,

**Ram Soorat**  
(On behalf of all co-authors)  
Assistant Professor, School of Technology, Woxsen University  
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  
Email: [ram.soorat@woxsen.edu.in](mailto:ram.soorat@woxsen.edu.in)  
Telephone: +91 8455 305555  
ORCID: [https://orcid.org/0000-0001-7875-9197](https://orcid.org/0000-0001-7875-9197)
