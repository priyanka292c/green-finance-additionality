# Title Page — *Journal of Sustainable Finance & Investment* (Taylor & Francis)

**Full Manuscript Title:**  
Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing

**Running Title (≤ 40 characters):**  
Green-Bond Allocation & Emissions

**Keywords:**  
Green bonds; Sustainable finance; Environmental additionality; Corporate decarbonization; Proceeds allocation; ESG ratings

---

### Authors and Affiliations

**Shahrukh Saleem**¹  
**Araby Madbouly**²  
**Uvesh Husain**³  
**Ram Soorat**⁴* *(Corresponding Author)*  
**Priyanka**⁵  
**Afzalur Rahman**⁶  

¹ VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India  
² Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman  
³ Economics and Business Studies Department, Mazoon College, Muscat, Oman  
⁴ School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  
⁵ Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India  
⁶ School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  

---

### Corresponding Author Contact Details

**Ram Soorat**  
Assistant Professor  
School of Technology  
Woxsen University  
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India  
Email: [ram.soorat@woxsen.edu.in](mailto:ram.soorat@woxsen.edu.in)  
Telephone: +91 8455 305555  
ORCID: [https://orcid.org/0000-0001-7875-9197](https://orcid.org/0000-0001-7875-9197)  

---

### Co-Author Contact Information

- **Shahrukh Saleem:** Assistant Professor, VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India. Email: [shahrukh.saleem@vit.ac.in](mailto:shahrukh.saleem@vit.ac.in); ORCID: [https://orcid.org/0000-0003-2949-6188](https://orcid.org/0000-0003-2949-6188)
- **Araby Madbouly:** Associate Professor, Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman. Email: [araby@muscatcollege.edu.om](mailto:araby@muscatcollege.edu.om); ORCID: [0000-0002-7981-4191](https://orcid.org/0000-0002-7981-4191)
- **Uvesh Husain:** Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Oman. Email: [owais.husain@mazcol.edu.om](mailto:owais.husain@mazcol.edu.om); ORCID: [https://orcid.org/0000-0002-8502-8488](https://orcid.org/0000-0002-8502-8488)
- **Ram Soorat:** Assistant Professor, School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: [ram.soorat@woxsen.edu.in](mailto:ram.soorat@woxsen.edu.in); ORCID: [https://orcid.org/0000-0001-7875-9197](https://orcid.org/0000-0001-7875-9197)
- **Priyanka:** Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India. Email: [priyanka1@physics.du.ac.in](mailto:priyanka1@physics.du.ac.in); ORCID: [https://orcid.org/0009-0008-1520-0706](https://orcid.org/0009-0008-1520-0706)
- **Afzalur Rahman:** School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India. Email: [afzalur.rahman@woxsen.edu.in](mailto:afzalur.rahman@woxsen.edu.in); ORCID: [0000-0002-1561-561X](https://orcid.org/0000-0002-1561-561X)

---

### Acknowledgements

The authors are grateful to the seminar participants at the Sustainable Finance, Financial Econometrics, and Climate Economics Working Seminars for constructive discussions and feedback on earlier versions of this research. The authors also thank the data-verification team for assistance with archival regulatory filing cross-checks.

---

### Funding Statement

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

---

### Conflict of Interest Statement

The authors declare that they have no known competing financial interests, affiliations, or personal relationships that could have appeared to influence the work reported in this paper.

---

### Ethics Statement

This study analyzes publicly disclosed corporate financial, emissions, and contractual allocation disclosures and does not involve human participants, animal experimentation, or tissue samples. Institutional ethical review was not required.

---

### Data Availability Statement

The replication package will be deposited in an appropriate open-access repository and, where permitted by data-licensing restrictions, archived through Zenodo with a linked GitHub repository containing the replication code. Proprietary third-party data (CDP Scope 1+2 emissions and Bloomberg financial records) remain subject to their respective licensing restrictions.

---

### CRediT Author Contribution Statement

- **Shahrukh Saleem:** Conceptualization, Methodology, Formal analysis, Investigation, Writing – Original Draft, Writing – Review & Editing, Supervision, Project administration.
- **Araby Madbouly:** Resources, Data curation, Writing – Review & Editing.
- **Uvesh Husain:** Data curation, Formal analysis, Software, Writing – Review & Editing.
- **Ram Soorat:** Conceptualization, Methodology, Writing – Review & Editing, Validation, Supervision, Project administration.
- **Priyanka:** Data curation, Software, Formal analysis, Visualization, Writing – Review & Editing.
- **Afzalur Rahman:** Investigation, Visualization, Validation, Writing – Review & Editing.

---

### Declaration of Generative AI

Generative AI tools were used solely for code-formatting, bibliographic verification, and LaTeX/HTML typesetting assistance. No generative AI tool was used to perform statistical estimation, data curation, scientific interpretation, or formulate empirical conclusions. All AI-assisted outputs were reviewed and verified by the authors, who take full responsibility for the manuscript.

---

### Submission Declaration

This manuscript represents original work that has not been published previously and is not under consideration for publication elsewhere. All co-authors have approved the submitted manuscript and consent to its publication in *Journal of Sustainable Finance & Investment*.

---

*[End of Title Page Document]*
