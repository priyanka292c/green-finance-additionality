import os
import pypdf
import re

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')

print("=" * 70)
print("VERIFICATION OF 3 EDITORIAL FIXES (SENSITIVITY 1, CONCLUSION, COVER LETTER)")
print("=" * 70)

# 1. Manuscript Section 5.9: Sensitivity 1 Sample Size
print("\n--- 1. SENSITIVITY 1 SAMPLE SIZE (39 PAIRS, 78 FIRMS, 936 FIRM-YEARS) ---")
man_word_pdf = os.path.join(jsfi_dir, "02_JSFI_Anonymous_Manuscript.pdf")
man_latex_pdf = os.path.join(jsfi_dir, "02_JSFI_Anonymous_Manuscript_LaTeX.pdf")

bad_sens1 = "37 treated pairs"
bad_sens1_fy = "888 firm-years"
good_sens1 = "39 treated pairs"
good_sens1_fy = "936 firm-years"

for m_path, m_name in [(man_word_pdf, "Word Manuscript PDF"), (man_latex_pdf, "LaTeX Manuscript PDF")]:
    reader = pypdf.PdfReader(m_path)
    full_text = " ".join((page.extract_text() or "") for page in reader.pages)
    clean_text = " ".join(full_text.split())
    
    has_bad_sens1 = bad_sens1 in clean_text or bad_sens1_fy in clean_text
    has_good_sens1 = good_sens1 in clean_text and good_sens1_fy in clean_text
    
    print(f"[{m_name}]")
    print(f"  Old '37 treated pairs / 888 firm-years' present: {has_bad_sens1} (Expected: False)")
    print(f"  New '39 treated pairs / 936 firm-years' present: {has_good_sens1} (Expected: True)")

# 2. Conclusion Typo: Double Period
print("\n--- 2. CONCLUSION TYPOGRAPHY (NO DOUBLE PERIOD) ---")
for m_path, m_name in [(man_word_pdf, "Word Manuscript PDF"), (man_latex_pdf, "LaTeX Manuscript PDF")]:
    reader = pypdf.PdfReader(m_path)
    full_text = " ".join((page.extract_text() or "") for page in reader.pages)
    clean_text = " ".join(full_text.split())
    
    has_double_period = "trajectories.. The" in clean_text or "trajectories.." in clean_text
    has_single_period = "trajectories. The" in clean_text
    
    print(f"[{m_name}]")
    print(f"  Double period 'trajectories..' present: {has_double_period} (Expected: False)")
    print(f"  Clean 'trajectories. The' present:      {has_single_period} (Expected: True)")

# 3. Cover Letter: 'achieve' replaced with 'are associated with'
print("\n--- 3. COVER LETTER PHRASING ('ARE ASSOCIATED WITH') ---")
cl_word_pdf = os.path.join(jsfi_dir, "04_JSFI_Cover_Letter.pdf")
cl_latex_pdf = os.path.join(jsfi_dir, "04_JSFI_Cover_Letter_LaTeX.pdf")

bad_cl_verb = "achieve an average"
good_cl_verb = "are associated with an average"

for cl_path, cl_name in [(cl_word_pdf, "Word Cover Letter PDF"), (cl_latex_pdf, "LaTeX Cover Letter PDF")]:
    reader = pypdf.PdfReader(cl_path)
    full_text = " ".join((page.extract_text() or "") for page in reader.pages)
    clean_text = " ".join(full_text.split())
    
    has_bad_verb = bad_cl_verb in clean_text
    has_good_verb = good_cl_verb in clean_text
    
    print(f"[{cl_name}]")
    print(f"  Old verb 'achieve an average' present:          {has_bad_verb} (Expected: False)")
    print(f"  New phrase 'are associated with' present:      {has_good_verb} (Expected: True)")

print("\n" + "=" * 70)
print("ALL 3 EDITORIAL CHECKS COMPLETED!")
print("=" * 70)
