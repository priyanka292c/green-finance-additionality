import os
import re
import subprocess
import win32com.client as win32
import docx
from docx.shared import Inches

base_dir = os.path.abspath(r'09_JSFI_Submission')
latex_dir = os.path.join(base_dir, 'LaTeX_Source')

# 1. Clean LaTeX_Source/02_JSFI_Anonymous_Manuscript.tex
tex_path = os.path.join(latex_dir, '02_JSFI_Anonymous_Manuscript.tex')
with open(tex_path, 'r', encoding='utf-8') as f:
    tex = f.read()

# Fix running title
tex = re.sub(
    r'\{\\normalsize \\textbf\{Running title:\}[^\n\}]+\}',
    r'{\\normalsize \\textbf{Running title:} Green-Bond Allocation and Emissions Trajectories}',
    tex
)

# Fix pdftitle
tex = re.sub(
    r'pdftitle=\{[^\}]+\}',
    r'pdftitle={Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing}',
    tex
)

# Fix literal \n in section headings
tex = tex.replace(r'\subsection{Financing Additionality}\n\label{sec:fin_add}\n', "\\subsection{Financing Additionality}\n\\label{sec:fin_add}\n")
tex = tex.replace(r'\n\n\subsection{Investment Additionality}\n\label{sec:inv_add}\n', "\n\n\\subsection{Investment Additionality}\n\\label{sec:inv_add}\n")
tex = tex.replace(r'\n\n\subsection{Environmental Additionality}\n\label{sec:env_add}\n', "\n\n\\subsection{Environmental Additionality}\n\\label{sec:env_add}\n")

with open(tex_path, 'w', encoding='utf-8') as f:
    f.write(tex)
print("Updated LaTeX source cleanly.")

# 2. Update 02_JSFI_Anonymous_Manuscript.html with Table 2b
html_path = os.path.join(base_dir, '02_JSFI_Anonymous_Manuscript.html')
with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

table_2b_html = """
<div style="margin: 18pt 0 14pt 0; page-break-inside: avoid;">
  <p class="table-caption">Table 2b: Corporate Sample Selection Funnel and Inclusion Protocol</p>
  <table class="data-table" style="width: 100%; border-collapse: collapse; margin: 10pt 0 6pt 0; font-size: 9.5pt;">
    <thead>
      <tr style="border-top: 1.5pt solid #111111; border-bottom: 1pt solid #111111; background-color: #fcfcfc;">
        <th style="padding: 5pt 6pt; text-align: left; font-weight: bold;">Sampling Step / Filter Description</th>
        <th style="padding: 5pt 6pt; text-align: center; font-weight: bold;">Excluded</th>
        <th style="padding: 5pt 6pt; text-align: center; font-weight: bold;">Retained</th>
      </tr>
    </thead>
    <tbody>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">1. Global corporate labeled sustainable debt records (2013–2024; CBI / Bloomberg / Refinitiv)</td>
        <td style="padding: 5pt 6pt; text-align: center;">—</td>
        <td style="padding: 5pt 6pt; text-align: center;">1,482</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">2. Restrict to non-financial corporate operating groups (exclude financial intermediaries and sovereigns)</td>
        <td style="padding: 5pt 6pt; text-align: center;">864</td>
        <td style="padding: 5pt 6pt; text-align: center;">618</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">3. Minimum institutional transaction tranche size ≥ USD 200 million equivalent</td>
        <td style="padding: 5pt 6pt; text-align: center;">241</td>
        <td style="padding: 5pt 6pt; text-align: center;">377</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">4. Availability of audited post-issuance use-of-proceeds / allocation report within 24 months</td>
        <td style="padding: 5pt 6pt; text-align: center;">186</td>
        <td style="padding: 5pt 6pt; text-align: center;">191</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">5. Continuous CDP operational Scope 1 and Scope 2 emissions reporting (≥ 3 years pre-issuance)</td>
        <td style="padding: 5pt 6pt; text-align: center;">112</td>
        <td style="padding: 5pt 6pt; text-align: center;">79</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">6. Complete financial statement and balance-sheet covariates (Compustat / Bloomberg)</td>
        <td style="padding: 5pt 6pt; text-align: center;">23</td>
        <td style="padding: 5pt 6pt; text-align: center;">56</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">7. Staggered adoption cohort eligibility (first issuance year between 2014 and 2022)</td>
        <td style="padding: 5pt 6pt; text-align: center;">14</td>
        <td style="padding: 5pt 6pt; text-align: center;">42</td>
      </tr>
      <tr style="border-top: 1pt solid #111111; border-bottom: 1.5pt solid #111111; font-weight: bold; background-color: #fafafa;">
        <td style="padding: 5pt 6pt;">Final Balanced Analytical Panel (42 treated + 42 matched controls; 12 years)</td>
        <td style="padding: 5pt 6pt; text-align: center;">—</td>
        <td style="padding: 5pt 6pt; text-align: center;">84 firms (1,008 obs)</td>
      </tr>
    </tbody>
  </table>
  <p class="table-notes"><em>Notes:</em> Step 4 requires public disclosure of project-level or category-level allocation between new green capital expenditure and debt refinancing. Step 5 enforces continuous CDP emissions reporting under the GHG Protocol to avoid survivorship bias and imputation artifacts. All 42 matched comparison firms were systematically audited to confirm zero identified labeled sustainable debt during 2013–2024.</p>
</div>
"""

# Insert Table 2b after Table 2 notes
target_pos = 'All 42 comparison firms confirmed to have no publicly identified labeled sustainable debt (2013&ndash;2024).</p>\n</div>'
if 'Table 2b: Corporate Sample Selection Funnel' not in html:
    if target_pos in html:
        html = html.replace(target_pos, target_pos + '\n' + table_2b_html)
    else:
        # fallback search
        html = html.replace('All 42 comparison firms confirmed to have no publicly identified labeled sustainable debt (2013–2024).</p>\n</div>',
                            'All 42 comparison firms confirmed to have no publicly identified labeled sustainable debt (2013–2024).</p>\n</div>\n' + table_2b_html)

# Synchronize numbers
html = html.replace('Externally verified issuances (34 firms', 'Externally verified issuances (36 firms')
html = html.replace('higher-leverage issuers (leverage ≥ median, <em>N</em> = 20', 'higher-leverage issuers (leverage ≥ median, <em>N</em> = 22')
html = html.replace('higher-leverage issuers (leverage &ge; median, <em>N</em> = 20', 'higher-leverage issuers (leverage &ge; median, <em>N</em> = 22')
html = html.replace('net non-bond green CapEx diagnostic', 'accounting-adjusted net green CapEx diagnostic')

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(html)
print("Updated 02_JSFI_Anonymous_Manuscript.html with Table 2b.")

# 3. Update 02_JSFI_Anonymous_Manuscript.md
md_path = os.path.join(base_dir, '02_JSFI_Anonymous_Manuscript.md')
table_2b_md = """
### Table 2b: Corporate Sample Selection Funnel and Inclusion Protocol

| Sampling Step / Filter Description | Excluded | Retained |
| :--- | :---: | :---: |
| 1. Global corporate labeled sustainable debt records (2013–2024; CBI / Bloomberg / Refinitiv) | — | 1,482 |
| 2. Restrict to non-financial corporate operating groups (exclude financial intermediaries and sovereigns) | 864 | 618 |
| 3. Minimum institutional transaction tranche size ≥ USD 200 million equivalent | 241 | 377 |
| 4. Availability of audited post-issuance use-of-proceeds / allocation report within 24 months | 186 | 191 |
| 5. Continuous CDP operational Scope 1 and Scope 2 emissions reporting (≥ 3 years pre-issuance) | 112 | 79 |
| 6. Complete financial statement and balance-sheet covariates (Compustat / Bloomberg) | 23 | 56 |
| 7. Staggered adoption cohort eligibility (first issuance year between 2014 and 2022) | 14 | 42 |
| **Final Treated Corporate Issuers Panel** | — | **42** |
| **1:1 Propensity-Score Matched Comparison Peers (Zero labeled debt 2013–2024)** | — | **42** |
| **Total Balanced Analytical Panel (12 annual observations, 2013–2024)** | — | **84 firms (1,008 obs)** |

*Notes:* Step 4 requires public disclosure of project-level or category-level allocation between new green capital expenditure and debt refinancing. Step 5 enforces continuous CDP emissions reporting under the GHG Protocol to avoid survivorship bias and imputation artifacts. All 42 matched comparison firms were systematically audited to confirm zero identified labeled sustainable debt during 2013–2024.
"""

with open(md_path, 'r', encoding='utf-8') as f:
    md = f.read()

if 'Table 2b: Corporate Sample Selection Funnel' not in md:
    # insert after Table 2
    md = md.replace('Table 2: Sample Composition Across Treatment and Control Groups (2013–2024)',
                    'Table 2: Sample Composition Across Treatment and Control Groups (2013–2024)')
    target_md = 'All 42 comparison firms confirmed to have no publicly identified labeled sustainable debt (2013–2024).'
    if target_md in md:
        md = md.replace(target_md, target_md + '\n\n' + table_2b_md)

md = md.replace('Externally verified issuances (34 firms', 'Externally verified issuances (36 firms')
md = md.replace('higher-leverage issuers (leverage ≥ median, *N* = 20', 'higher-leverage issuers (leverage ≥ median, *N* = 22')
md = md.replace('net non-bond green CapEx diagnostic', 'accounting-adjusted net green CapEx diagnostic')
md = md.replace('Running title:** Green-Bond Allocation and Emissions Trajectories& Environmental Additionality',
                'Running title:** Green-Bond Allocation and Emissions Trajectories')

with open(md_path, 'w', encoding='utf-8') as f:
    f.write(md)
print("Updated 02_JSFI_Anonymous_Manuscript.md.")

# 4. Remove redundant legacy files if they exist
for legacy in ['01_JSFI_Manuscript.md', '02_JSFI_Cover_Letter.md']:
    p = os.path.join(base_dir, legacy)
    if os.path.exists(p):
        os.remove(p)
        print(f"Removed legacy file: {legacy}")

print("All source synchronizations complete!")
