import os
import re

sd_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\08_Wiley_SD_Submission')
jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')

# 1. Build 01_JSFI_Title_Page.html
with open(os.path.join(sd_dir, '02_Sustainable_Development_Title_Page.html'), 'r', encoding='utf-8') as f:
    tp_html = f.read()

tp_html = tp_html.replace('Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development',
                          'Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing')
tp_html = tp_html.replace('Green Bond Allocation & Sustainability',
                          'Green-Bond Allocation & Environmental Additionality')
tp_html = tp_html.replace('Sustainable Development',
                          'Journal of Sustainable Finance & Investment')
tp_html = tp_html.replace('line-height: 1.5;', 'line-height: 2.0;')

with open(os.path.join(jsfi_dir, '01_JSFI_Title_Page.html'), 'w', encoding='utf-8') as f:
    f.write(tp_html)
print("Wrote 01_JSFI_Title_Page.html")

# 2. Build 02_JSFI_Anonymous_Manuscript.html
with open(os.path.join(sd_dir, '01_Sustainable_Development_Blind_Manuscript.html'), 'r', encoding='utf-8') as f:
    m_html = f.read()

m_html = m_html.replace('Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development',
                        'Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing')
m_html = m_html.replace('Green Bond Allocation & Sustainability',
                        'Green-Bond Allocation & Environmental Additionality')
m_html = m_html.replace('Blind Manuscript Submitted to Wiley Journal "Sustainable Development"',
                        'Anonymous Manuscript Submitted to Journal of Sustainable Finance & Investment (Taylor & Francis)')
m_html = m_html.replace('line-height: 1.5;', 'line-height: 2.0;')

# Update section headers in manuscript HTML to match JSFI structure
header_replacements = [
    ('<h3>2.1 Sustainable Finance and Environmental Outcomes</h3>', '<h3>2.1 Sustainable Finance and Green Financial Instruments</h3>'),
    ('<h3>2.2 Green Bonds and Environmental Additionality</h3>', '<h3>2.2 Green Bonds and Sustainable Investment</h3>'),
    ('<h3>2.3 Green Investment, Corporate Decarbonization, and SDG 13</h3>', '<h3>2.3 Proceeds Allocation and Environmental Additionality</h3>'),
    ('<h3>2.4 Refinancing versus New-Project Financing</h3>', '<h3>2.4 Green Finance and Corporate Environmental Performance</h3>'),
    ('<h3>2.5 ESG Measurement and Rating Differentiation</h3>', '<h3>2.5 ESG Ratings, Carbon Accounting and Disclosure</h3>'),
    ('<h3>2.6 Research Gap</h3>', '<h3>2.6 Research Gap</h3>'),
    ('<h2>4. Data and Methods</h2>', '<h2>4. Data and Methodology</h2>'),
    ('<h3>4.2 Matched Comparison Group</h3>', '<h3>4.5 Propensity-Score Matching</h3>'),
    ('<h3>4.3 Proceeds Allocation Measurement</h3>', '<h3>4.2 Green-Bond Proceeds Allocation</h3>'),
    ('<h3>4.4 Econometric Design</h3>', '<h3>4.6 Callaway–Sant’Anna Estimation</h3>'),
    ('<h3>5.2 Overall Post-Issuance Environmental Differentials</h3>', '<h3>5.2 Green-Bond Financing and Environmental Outcomes</h3>'),
    ('<h3>5.3 Green Investment Response</h3>', '<h3>5.3 Green Investment Response</h3>'),
    ('<h3>5.4 Dynamic Event-Study Trajectories</h3>', '<h3>5.4 Dynamic Effects</h3>'),
    ('<h3>5.5 Proceeds Allocation and Environmental Heterogeneity</h3>', '<h3>5.5 New-Project versus Refinancing Allocation</h3>'),
    ('<h3>5.6 Commercial ESG Rating Differentiation</h3>', '<h3>5.6 ESG Rating Response</h3>'),
    ('<h3>5.7 External Verification and Leverage Heterogeneity</h3>', '<h3>5.7 Verification and Leverage Heterogeneity</h3>'),
    ('<h3>5.8 NLP Allocation Classification Validation</h3>', '<h3>5.8 Robustness Analysis</h3>'),
    ('<h2>6. Discussion</h2>', '<h2>6. Discussion</h2>'),
    ('<h3>6.1 Proceeds Allocation and Post-Issuance Environmental Trajectories</h3>', '<h3>6.1 Implications for Sustainable Finance</h3>\n<p>Our findings establish that green bonds are neither uniformly effective nor merely symbolic; their real-economy impact is governed by contractual proceeds allocation.</p>\n<h3>6.2 Implications for Green-Bond Design</h3>'),
    ('<h3>6.2 Implications for Sustainable Development</h3>', '<h3>6.3 ESG and Carbon-Accounting Implications</h3>\n<p>The documented divergence between physical emissions trajectories and commercial ESG scores indicates that composite ratings decouple from verified carbon accounting.</p>\n<h3>6.4 Implications for Investors</h3>'),
    ('<h3>6.3 Policy Implications</h3>', '<h3>6.5 Policy Implications</h3>'),
    ('<h2>7. Limitations</h2>', '<h2>7. Limitations and Future Research</h2>')
]

for old_h, new_h in header_replacements:
    m_html = m_html.replace(old_h, new_h)

# Add Declaration of Interest before References
interest_html = """
<h2>Declaration of Interest</h2>
<p>The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.</p>
"""
if '<h2>Declaration of Interest</h2>' not in m_html:
    m_html = m_html.replace('<h2>References</h2>', interest_html + '\n<h2>References</h2>')

with open(os.path.join(jsfi_dir, '02_JSFI_Anonymous_Manuscript.html'), 'w', encoding='utf-8') as f:
    f.write(m_html)
print("Wrote 02_JSFI_Anonymous_Manuscript.html")

# 3. Build 03_JSFI_Supplementary_Material.html
with open(os.path.join(sd_dir, '03_Sustainable_Development_Supplementary_Information.html'), 'r', encoding='utf-8') as f:
    s_html = f.read()

s_html = s_html.replace('Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development',
                        'Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing')
s_html = s_html.replace('Submitted to Wiley Sustainable Development',
                        'Supplementary Material Submitted to Journal of Sustainable Finance & Investment (Taylor & Francis)')
s_html = s_html.replace('line-height: 1.5;', 'line-height: 2.0;')

with open(os.path.join(jsfi_dir, '03_JSFI_Supplementary_Material.html'), 'w', encoding='utf-8') as f:
    f.write(s_html)
print("Wrote 03_JSFI_Supplementary_Material.html")

# 4. Build 04_JSFI_Cover_Letter.html
with open(os.path.join(sd_dir, '05_Sustainable_Development_Cover_Letter.html'), 'r', encoding='utf-8') as f:
    cl_html = f.read()

cl_html = cl_html.replace('Sustainable Development', 'Journal of Sustainable Finance & Investment')
cl_html = cl_html.replace('Green Finance or Green Refinancing? Proceeds Allocation, Environmental Outcomes, and Corporate Sustainable Development',
                          'Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing')

with open(os.path.join(jsfi_dir, '04_JSFI_Cover_Letter.html'), 'w', encoding='utf-8') as f:
    f.write(cl_html)
print("Wrote 04_JSFI_Cover_Letter.html")
