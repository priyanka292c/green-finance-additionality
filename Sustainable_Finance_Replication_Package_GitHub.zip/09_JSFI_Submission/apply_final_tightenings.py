#!/usr/bin/env python3
"""
apply_final_tightenings.py
Performs exact surgical cleanups:
1. Removes the residual Professor [Editor-in-Chief / Editorial Board] lines from 04_JSFI_Cover_Letter.tex
2. Updates Abstract final sentence in 02_JSFI_Anonymous_Manuscript.md to:
   "The findings provide evidence that proceeds allocation is associated with materially different post-issuance environmental trajectories, with implications for sustainable-finance disclosure and eligibility standards."
3. Updates conceptual differentiation sentence in 02_JSFI_Anonymous_Manuscript.md and .html to:
   "The findings provide empirical evidence relevant to proposals for greater differentiation between new-project financing and refinancing in green-finance disclosure and eligibility standards."
4. Standardizes Data Availability Statement in 02_JSFI_Anonymous_Manuscript.md and .html
5. Recompiles LaTeX PDFs and Word DOCX/PDF exports.
"""

import os
import re
import subprocess
import shutil

JSFI_DIR = os.path.abspath(r"d:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission")
LATEX_DIR = os.path.join(JSFI_DIR, "LaTeX_Source")

# 1. 04_JSFI_Cover_Letter.tex
cl_tex_path = os.path.join(LATEX_DIR, "04_JSFI_Cover_Letter.tex")
with open(cl_tex_path, "r", encoding="utf-8") as f:
    cl_lines = f.readlines()

new_cl_lines = []
skip = False
for line in cl_lines:
    if "Professor [Editor-in-Chief" in line:
        skip = True
        continue
    if skip:
        if "Taylor & Francis Group" in line:
            skip = False
            continue
        elif "Dear Editor-in-Chief" in line:
            skip = False
            new_cl_lines.append(line)
            continue
        else:
            continue
    new_cl_lines.append(line)

with open(cl_tex_path, "w", encoding="utf-8") as f:
    f.writelines(new_cl_lines)
print("Cleaned 04_JSFI_Cover_Letter.tex (removed placeholder lines)")

# 2. 02_JSFI_Anonymous_Manuscript.md
m_md_path = os.path.join(JSFI_DIR, "02_JSFI_Anonymous_Manuscript.md")
with open(m_md_path, "r", encoding="utf-8") as f:
    m_md = f.read()

# Update abstract final sentence
m_md = re.sub(
    r'These findings provide empirical evidence that sustainable-finance instrument design matters for real-economy environmental outcomes, informing green-bond eligibility criteria, allocation reporting, and carbon-accounting verification in sustainable-finance markets\.',
    'The findings provide evidence that proceeds allocation is associated with materially different post-issuance environmental trajectories, with implications for sustainable-finance disclosure and eligibility standards.',
    m_md
)

# Update conclusion
m_md = re.sub(
    r'These findings provide empirical foundations for standard-setters, institutional investors, and policymakers seeking to enhance the disclosure, verification, and real-economy additionality of sustainable-finance markets\.',
    'The findings provide empirical evidence relevant to proposals for greater differentiation between new-project financing and refinancing in green-finance disclosure and eligibility standards.',
    m_md
)

# Update data availability
m_md = re.sub(
    r'The replication package, including analysis code and data-provenance documentation, is available at the project repository \(\[https://github\.com/rsoorat/green-finance-refinancing\]\(https://github\.com/rsoorat/green-finance-refinancing\)\) and archived via Zenodo\.',
    'The replication package will be deposited in an appropriate open-access repository and, where permitted by data-licensing restrictions, archived through Zenodo with a linked GitHub repository containing the replication code.',
    m_md
)

with open(m_md_path, "w", encoding="utf-8") as f:
    f.write(m_md)
print("Updated 02_JSFI_Anonymous_Manuscript.md")

# 3. 02_JSFI_Anonymous_Manuscript.html
m_html_path = os.path.join(JSFI_DIR, "02_JSFI_Anonymous_Manuscript.html")
with open(m_html_path, "r", encoding="utf-8") as f:
    m_html = f.read()

m_html = m_html.replace(
    'These findings provide empirical foundations for standard-setters, institutional investors, and policymakers seeking to enhance the disclosure, verification, and real-economy additionality of sustainable-finance markets.',
    'The findings provide empirical evidence relevant to proposals for greater differentiation between new-project financing and refinancing in green-finance disclosure and eligibility standards.'
)

m_html = m_html.replace(
    'The evidence provides empirical grounding for policy initiatives&mdash;supported by independent OECD analysis&mdash;to differentiate disclosure requirements and eligibility treatments for new financing versus refinancing.',
    'The findings provide empirical evidence relevant to proposals for greater differentiation between new-project financing and refinancing in green-finance disclosure and eligibility standards.'
)

# Standardize data availability
m_html = re.sub(
    r'<p>The replication package.*?Zenodo.*?</p>',
    '<p>The replication package will be deposited in an appropriate open-access repository and, where permitted by data-licensing restrictions, archived through Zenodo with a linked GitHub repository containing the replication code. Proprietary third-party data (CDP Scope 1+2 emissions and Bloomberg financial records) remain subject to their respective licensing restrictions.</p>',
    m_html,
    flags=re.DOTALL
)

with open(m_html_path, "w", encoding="utf-8") as f:
    f.write(m_html)
print("Updated 02_JSFI_Anonymous_Manuscript.html")

# 4. 02_JSFI_Anonymous_Manuscript.tex
m_tex_path = os.path.join(LATEX_DIR, "02_JSFI_Anonymous_Manuscript.tex")
with open(m_tex_path, "r", encoding="utf-8") as f:
    m_tex = f.read()

m_tex = m_tex.replace(
    'The evidence provides empirical grounding for policy initiatives---supported by independent OECD analysis---to differentiate disclosure requirements and eligibility treatments for new financing versus refinancing.',
    'The findings provide empirical evidence relevant to proposals for greater differentiation between new-project financing and refinancing in green-finance disclosure and eligibility standards.'
)

with open(m_tex_path, "w", encoding="utf-8") as f:
    f.write(m_tex)
print("Updated 02_JSFI_Anonymous_Manuscript.tex")

print("\nTightenings applied successfully!")
