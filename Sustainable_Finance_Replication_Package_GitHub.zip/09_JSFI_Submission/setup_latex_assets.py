import os
import sys
import subprocess
import shutil

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')
latex_dir = os.path.join(jsfi_dir, "LaTeX_Source")
os.makedirs(latex_dir, exist_ok=True)

# Copy figures to LaTeX_Source/Figures
fig_src = os.path.join(jsfi_dir, "Figures")
fig_dst = os.path.join(latex_dir, "Figures")
if not os.path.exists(fig_dst):
    shutil.copytree(fig_src, fig_dst)
    print("Copied Figures to LaTeX_Source")

# Copy references.bib
bib_src = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\08_Wiley_SD_Submission\LaTeX_Source\sd_references.bib')
bib_dst = os.path.join(latex_dir, "references.bib")
shutil.copy2(bib_src, bib_dst)
print(f"Copied references.bib ({os.path.getsize(bib_dst):,} bytes)")
