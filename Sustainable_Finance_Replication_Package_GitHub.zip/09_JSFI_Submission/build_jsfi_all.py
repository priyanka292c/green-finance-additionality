import os
import sys
import re
import shutil
import subprocess
import win32com.client
import docx

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')
latex_dir = os.path.join(jsfi_dir, "LaTeX_Source")
sd_latex_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\08_Wiley_SD_Submission\LaTeX_Source')
pdflatex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'
bibtex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe'

os.makedirs(latex_dir, exist_ok=True)
os.makedirs(os.path.join(latex_dir, "Figures"), exist_ok=True)

# 1. Copy Figures and references.bib if needed
for f in os.listdir(os.path.join(jsfi_dir, "Figures")):
    src_f = os.path.join(jsfi_dir, "Figures", f)
    dst_f = os.path.join(latex_dir, "Figures", f)
    if not os.path.exists(dst_f):
        shutil.copy2(src_f, dst_f)

shutil.copy2(os.path.join(sd_latex_dir, "sd_references.bib"), os.path.join(latex_dir, "references.bib"))
print("Assets prepared successfully.")
