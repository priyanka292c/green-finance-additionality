# Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing

**Running title:** Green-Bond Allocation & Emissions

---

## Abstract

Green bonds are designed to channel financial capital toward environmentally beneficial activities, but their real-economy environmental implications depend critically on whether proceeds finance genuinely new green investment or refinance existing eligible assets. Most empirical green-bond studies treat issuance as a relatively homogeneous financial instrument and pay insufficient attention to contractual proceeds allocation. Using an audited panel of 84 multinational corporations—comprising 42 corporate environmental-use-of-proceeds bond issuers (38 qualifying ICMA Green Bonds and 4 corporate Sustainability Bonds with qualifying environmental allocations) and 42 propensity-score-matched comparison firms—observed annually over 2013–2024 (1,008 firm-years), we implement a Callaway–Sant’Anna staggered difference-in-differences design. Environmental-debt issuance is associated overall with an 8.91% reduction in Scope 1+2 emissions (CS ATT = −0.0934, p < 0.001), a 9.67% reduction in carbon intensity (CS ATT = −0.1017, p < 0.001), and a 7.32 percentage-point expansion in green capital expenditure share (accounting-adjusted net green CapEx diagnostic: +6.60 pp, p < 0.001). However, environmental trajectories vary systematically with contractual proceeds allocation: each 10 percentage-point allocation to new green capital projects is associated with an incremental −1.59% post-issuance emissions differential. Issuers allocating predominantly to new physical projects (N = 31) are associated with an average post-issuance emissions reduction of −6.31% relative to matched controls, whereas an exploratory cohort of five refinancing-dominated issuers exhibits a relative post-issuance divergence of +3.88% from matched controls; the refinancing subgroup is interpreted as exploratory heterogeneity evidence rather than a standalone causal estimate. In contrast, commercial ESG ratings increase similarly across allocation types (difference = +0.0042σ, p = 0.927; TOST equivalence p = 0.0168), indicating limited differentiation in rating adjustments despite divergent physical outcomes. The findings provide evidence that proceeds allocation is associated with materially different post-issuance environmental trajectories, with implications for sustainable-finance disclosure and eligibility standards.

**Keywords:** Green bonds; Sustainable finance; Environmental additionality; Corporate decarbonization; Proceeds allocation; ESG ratings

**JEL Classifications:** G12; G14; G31; G32; Q54; Q56; Q58

---

## 1. Introduction

The rapid expansion of sustainable finance represents one of the most significant structural transformations in modern capital markets. Global issuance of labeled sustainable debt instruments—principally green, social, sustainability, and sustainability-linked bonds—has surpassed USD 5 trillion cumulatively, with annual issuance volumes exceeding USD 500 billion (Climate Bonds Initiative, 2024; OECD, 2026). Within this landscape, green bonds serve as the foundational financial mechanism designed to intermediate private capital toward pro-environmental capital deployment, clean energy infrastructure, and industrial decarbonization (Flammer, 2021; Tang & Zhang, 2020). Theoretical models of sustainable investing suggest that by satisfying the non-pecuniary mandates of environmentally conscious investors and generating a borrowing cost discount (the "greenium"), green bonds can lower corporate capital costs, relax balance-sheet financing constraints, and accelerate physical climate mitigation (Baker et al., 2018; Heinkel et al., 2001; Pástor et al., 2021; Pedersen et al., 2021; Zerbib, 2019).

However, a fundamental financial-design problem lies at the heart of the green-bond market: a labeled bond may be contractually structured either to finance *genuinely new green capital projects* or to *refinance existing eligible assets*. Standard voluntary market architectures, most notably the International Capital Market Association's Green Bond Principles (ICMA, 2021), permit issuers substantial latitude to apply debt proceeds to operational projects commissioned years prior to bond issuance. From a corporate finance perspective, this distinction is consequential. Under capital fungibility and absent binding financing frictions (Myers, 1977; Stiglitz & Weiss, 1981), issuing a green bond to refinance pre-existing operational assets—such as a legacy wind installation or an established energy-efficient facility—restructures debt maturities and lowers interest expenses, but adds no new physical capacity to the issuer's capital stock. Because the environmental abatement associated with that asset was achieved at original commissioning, the refinancing transaction generates no contemporaneous incremental decarbonization relative to matched industry peers. Conversely, when proceeds are contractually directed toward greenfield capital formation or facility retrofits, the financing mechanism can fund incremental capacity that directly reduces the firm's physical emissions trajectory.

The credibility and market integrity of sustainable finance ultimately depend on whether labeled financial instruments are linked to measurable real-economy environmental outcomes rather than balance-sheet relabeling. While the sustainable-debt market has expanded exponentially, recent institutional reviews, including the OECD (2026) report on aligning finance with climate goals, highlight widespread concerns regarding the physical impact of labeled instruments. If green bonds primarily serve liability-management objectives through the refinancing of sunk assets, the rapid growth of sustainable-debt issuance may create an illusion of accelerated climate capital formation without generating corresponding decarbonization. Understanding how proceeds allocation governs environmental and investment performance is therefore essential for sustainable investors seeking impact additionality, for corporate issuers designing credible financing frameworks, and for regulators seeking to establish robust taxonomy and disclosure standards.

This financial-design challenge directly intersects with corporate ESG measurement, disclosure, and carbon accounting. Sustainable capital allocation relies heavily on commercial ESG ratings and third-party corporate disclosures (Berg et al., 2022; Christensen et al., 2022). Yet commercial ESG rating providers construct environmental scores predominantly from qualitative governance commitments, corporate policies, and labeled security issuances rather than verified, high-frequency telemetry of physical emissions (Christensen et al., 2022; Edmans, 2023). If ESG rating agencies award comparable score enhancements to green-bond issuers regardless of whether proceeds fund new physical investments or refinance mature assets, the sustainable-finance information environment faces an information asymmetry: capital markets may exhibit similar rating enhancements following labeled issuance while failing to differentiate between financial structures that yield materially different physical environmental outcomes.

Despite the critical importance of proceeds allocation for sustainable finance, the academic literature has concentrated disproportionately on secondary-market pricing dynamics—such as the existence and magnitude of the greenium (Baker et al., 2018; Larcker & Watts, 2020; MacAskill et al., 2021; Zerbib, 2019)—and on gross equity or aggregate ESG score responses (Flammer, 2021; Tang & Zhang, 2020). Studies examining firm-level physical environmental performance remain limited and yield mixed conclusions (Ehlers et al., 2021; Fatica & Panzica, 2021). Crucially, the prevailing empirical literature has almost universally treated green-bond issuance as a homogeneous binary intervention ($D_{it} \in \{0, 1\}$). By failing to decompose bond proceeds into contractual allocations between new capital formation and debt refinancing, existing research leaves unanswered the central question of whether sustainable-debt outcomes are governed by the contractual deployment of proceeds.

This study directly resolves this gap by investigating the central research question: **Does the contractual allocation of green-bond proceeds between new green capital projects and refinancing of existing eligible assets affect the environmental and investment outcomes associated with sustainable finance?** To address this question, we assemble an audited panel of 84 multinational corporations—42 corporate environmental-use-of-proceeds bond issuers (38 qualifying ICMA Green Bonds and 4 corporate Sustainability Bonds with qualifying environmental allocations) and 42 propensity-score-matched comparison firms—observed annually over 2013–2024 (1,008 firm-years). Through manual audit of post-issuance allocation disclosures, regulatory filings, and second-party assurance reports, we reconstruct the contractual allocation of proceeds. We estimate treatment trajectories using the Callaway and Sant’Anna (2021) staggered difference-in-differences estimator, which prevents negative-weighting bias under heterogeneous and dynamic treatment effects. To ensure that investment responses are not an artifact of bond-proceeds accounting, we construct a net non-bond green capital expenditure benchmark. Throughout this study, because treatment assignment is observational, our estimates are interpreted as differential post-issuance trajectories across allocation profiles rather than exogenous causal effects.

This paper makes four primary contributions to the sustainable-finance literature:

1. **Sustainable-Finance Instrument Design:** We provide the first systematic empirical evidence demonstrating that the contractual allocation of proceeds—specifically the ratio of new physical capital investment to debt refinancing—is a primary determinant of the post-issuance environmental trajectory of green-debt issuers. This establishes that green bonds cannot be evaluated as homogeneous instruments; instrument-level contractual design directly affects real-economy outcomes.
2. **Corporate Green Capital Formation and Additionality:** We demonstrate that green-bond issuance is associated with a 7.32 percentage-point expansion in corporate green CapEx share, which remains robust at +6.60 percentage points when deducting the focal-bond proceeds. Furthermore, we show that this capital formation is concentrated among issuers allocating proceeds to new projects, providing evidence consistent with investment additionality while documenting that refinancing-dominated issuances exhibit no detectable green investment expansion.
3. **ESG Measurement and Carbon-Accounting Disconnect:** We document that commercial ESG ratings increase identically (+0.90σ vs. +0.91σ) across new-project and refinancing issuers despite statistically and economically significant divergences in physical emissions reductions (−6.31% vs. +3.88% relative to matched controls). This demonstrates that prevailing ESG metrics fail to differentiate between physical decarbonization and liability refinancing, highlighting structural limitations in sustainable-investment data architectures.
4. **Policy Relevance for Sustainable-Debt Standards:** We provide concrete empirical support for evolving regulatory and market frameworks—such as the EU Green Bond Standard and OECD recommendations—advocating strict look-back limitations, standardized allocation reporting, and external audit of proceeds deployment to enhance the additionality and credibility of sustainable-finance markets.

---

## 2. Literature Review and Research Gap

### 2.1 Sustainable Finance and Green Financial Instruments

Sustainable finance has evolved from a niche investment philosophy into a core pillar of modern corporate finance and asset pricing. Theoretical foundations developed by Heinkel, Kraus, and Zechner (2001), Pástor, Stambaugh, and Taylor (2021), and Pedersen, Fitzgibbons, and Pomorski (2021) demonstrate how the non-pecuniary environmental preferences of investors reshape market equilibria. In equilibrium, sustainability-mandated capital raises the cost of capital for carbon-intensive firms while subsidizing borrowing costs for pro-environmental issuers, creating direct financial incentives for corporate decarbonization (Giglio et al., 2021; Hong et al., 2020). Green financial instruments, particularly green bonds, operationalize this theoretical mechanism by contractually binding debt proceeds to eligible environmental investments.

### 2.2 Green Bonds as Sustainable-Finance Instruments

Green bonds represent the flagship fixed-income instrument of sustainable finance. The empirical literature has examined two primary dimensions of green-bond issuance: pricing effects and corporate signaling. A substantial body of research investigates the "greenium"—the yield discount at issuance or in secondary markets attributed to pro-environmental investor demand (Baker et al., 2018; Larcker & Watts, 2020; MacAskill et al., 2021; Zerbib, 2019). While early studies documented modest greeniums of 2 to 20 basis points, Larcker and Watts (2020) find that after adjusting for contractual liquidity and market frictions, greenium pricing is often economically negligible in developed municipal and corporate markets. Beyond pricing, Flammer (2021) and Tang and Zhang (2020) demonstrate that green-bond announcements generate positive equity market reactions and attract institutional investors with environmental mandates, functioning as an effective signaling device of corporate environmental commitment.

### 2.3 Green-Bond Proceeds Allocation and Investment Additionality

Despite the extensive pricing literature, a critical question in sustainable investment is *additionality*: does green-debt issuance generate incremental physical investment and decarbonization that would not have occurred through conventional financing? Corporate finance theory establishes that financial capital is fungible (Myers, 1977). Unless external financing constraints are binding (Fazzari et al., 1988; Kaplan & Zingales, 1997; Stiglitz & Weiss, 1981), issuing a green bond does not automatically guarantee that new physical capital is created. 

The corporate refinancing literature demonstrates that firms frequently issue debt to manage liquidity, extend maturities, and reduce interest expenses without expanding their physical asset base (Green, 2018; Grossmann & Ngo, 2025; Xu, 2018). In the green-bond market, standard industry frameworks—such as the ICMA Green Bond Principles (ICMA, 2021)—permit issuers to allocate proceeds to refinance existing debt associated with historical green assets. When proceeds refinance an operational renewable energy project commissioned in prior years, the transaction represents a balance-sheet liability restructuring. Because the physical asset is already operating, no new emissions displacement occurs post-issuance relative to pre-existing trends. Conversely, when proceeds are allocated to new capital projects (e.g., greenfield renewable generation, battery storage, industrial electrification), the financing relaxes capital allocation frictions, enabling new capital formation and physical emissions abatement. The OECD (2026) has emphasized that distinguishing between new-project financing and refinancing is vital for determining whether sustainable finance actually drives the low-carbon transition.

### 2.4 Green Finance and Corporate Environmental Performance

The empirical literature evaluating the real-economy environmental consequences of green bonds has produced mixed and contentious evidence. Flammer (2021) documents that green-bond issuers improve their environmental performance scores and experience post-issuance emissions reductions. However, Ehlers, Mojon, and Packer (2021) examine a global panel and find that green-bond issuers do not systematically decarbonize faster than non-issuing peers, warning that green debt often represents capital relabeling rather than incremental abatement. Fatica and Panzica (2021) observe that emissions reductions are concentrated in repeated green-bond issuers and institutions with external verification, while single-issuance firms display limited physical progress. 

A central methodological limitation of these studies is the treatment of green bonds as a binary, undifferentiated event. By failing to observe the internal allocation of proceeds between new capital formation and debt refinancing, previous studies conflate transactions that expand the physical green capital stock with transactions that merely refinance existing assets, obscuring the primary corporate finance mechanism governing environmental outcomes.

### 2.5 ESG Ratings, Disclosure and Sustainable-Finance Measurement

Sustainable-investment capital allocation relies heavily on commercial ESG ratings (MSCI, S&P Trucost, Refinitiv) to direct capital flows (Hartzmark & Sussman, 2019). However, a prominent literature documents substantial "aggregate confusion" and divergence among ESG rating providers (Berg et al., 2022; Christensen et al., 2022; Gibson Brandon et al., 2021). Commercial rating methodologies evaluate corporate sustainability largely through policy disclosures, governance frameworks, and labeled financial activities rather than verified physical carbon accounting (Edmans, 2023). 

This creates a potential decoupling between sustainable-finance measurement and real-economy impact. If rating agencies treat green-bond issuance as a uniform signal of environmental stewardship—upgrading corporate ESG scores regardless of whether the bond finances new physical capacity or refinances legacy assets—commercial ratings provide distorted signals to sustainable investors (Kölbel et al., 2020; Lyon & Montgomery, 2015). Investigating whether ESG rating adjustments differentiate between proceeds-allocation structures is essential for understanding the information efficiency of sustainable-finance markets.

### 2.6 Research Gap

In summary, the sustainable-finance literature exhibits three critical limitations:
1. **Instrument Homogeneity Assumption:** Empirical studies almost uniformly model green-bond issuance as a binary treatment indicator, ignoring the contractual allocation between new-project financing and debt refinancing.
2. **Identification and Staggered Adoption Bias:** Prior evaluations rely predominantly on standard two-way fixed effects (TWFE) estimators, which are susceptible to severe negative-weighting bias and attenuation in the presence of heterogeneous and dynamic treatment effects (Callaway & Sant’Anna, 2021; de Chaisemartin & D'Haultfœuille, 2020; Goodman-Bacon, 2021).
3. **Information Decoupling:** No empirical study has simultaneously audited proceeds allocation, tracked physical Scope 1+2 emissions, measured net green capital formation, and tested commercial ESG rating responsiveness within a unified econometric framework.

This paper addresses these gaps directly, advancing sustainable-finance theory and empirical evidence.

---

## 3. Conceptual Framework and Hypotheses

### 3.1 Mechanism: Proceeds Allocation and Sustainable-Finance Additionality

We develop a sustainable-finance conceptual framework linking financial instrument design to real-economy environmental outcomes. The conceptual chain proceeds as follows:

$$\begin{aligned}
\text{Sustainable Finance} &\longrightarrow \text{Green-Bond Instrument Design} \longrightarrow \text{Proceeds Allocation} \\
&\longrightarrow \text{New Green Capital Formation vs. Refinancing} \longrightarrow \text{Corporate Green Investment} \\
&\longrightarrow \text{Physical Environmental Outcomes} \longrightarrow \text{ESG Measurement \& Disclosure} \\
&\longrightarrow \text{Policy Implications for Sustainable-Finance Markets}
\end{aligned}$$

Within this chain, we distinguish three theoretical concepts of additionality:

1. **Financing Additionality:** Refers to whether green-debt issuance expands the total financial capital envelope available to the firm for pro-environmental investment. Under corporate finance theories of financial frictions (Myers, 1977; Holmström & Tirole, 1997; Stiglitz & Weiss, 1981), firms face upward-sloping credit supply curves. If green bonds attract specialized ESG clienteles and lower borrowing spreads (the greenium), they can relax financing constraints, enabling investment in green capital projects that would otherwise exceed internal hurdle rates. In this study, we treat financing additionality as a theorized financial mechanism from prior literature rather than a directly observed spread.
2. **Investment Additionality:** Requires that debt proceeds be transformed into *incremental, new physical capital formation* rather than the relabeling or restructuring of existing assets. When proceeds finance greenfield assets or retrofits, the firm's green capital stock expands ($\Delta K_{\text{green}} > 0$). When proceeds refinance debt on pre-existing operational assets, financial liabilities are restructured, but the physical green capital stock remains unchanged ($\Delta K_{\text{green}} = 0$).
3. **Environmental Additionality:** Refers to the physical decarbonization outcome: whether post-issuance operational greenhouse gas emissions (Scope 1 and Scope 2) decline relative to the counterfactual trajectory. Environmental additionality is a physical consequence of investment additionality: new low-carbon physical assets displace carbon-intensive operational processes, lowering emissions. Refinancing mature assets, by contrast, produces no incremental displacement, yielding no contemporaneous environmental additionality.

Downstream from physical outcomes, the framework examines **ESG information signaling**. Commercial rating agencies observe labeled debt issuance and corporate disclosure. If rating models fail to differentiate between new-project financing and refinancing, reputational capital is awarded uniformly, dampening market incentives for genuine capital formation.

Figure 1 illustrates this conceptual progression.

![Figure 1: Conceptual Framework](Figures/fig01_conceptual_framework.png)

**Figure 1. Conceptual framework of sustainable-finance additionality and proceeds allocation.** The model traces the transmission mechanism from green financial instrument design through proceeds allocation to physical capital formation, corporate emissions trajectories, ESG disclosure, and policy implications. Solid lines represent expected pathways; dashed lines represent conditional dependencies governed by contractual proceeds allocation. Downstream linkages to SDGs (13, 7, 9, 12) represent practical implications of physical outcomes.

### 3.2 Hypotheses

Based on this sustainable-finance theoretical framework, we specify four testable hypotheses:

> **H1 (Green-Finance Investment Effect):** Environmental-use-of-proceeds bond issuance is associated with an expansion in corporate green capital expenditure share, including green CapEx net of focal debt proceeds:
> $$\frac{\partial \text{Green CapEx}_{it}}{\partial \text{GreenBond}_{it}} > 0 \quad \text{and} \quad \frac{\partial \text{Non-GB Green CapEx}_{it}}{\partial \text{GreenBond}_{it}} > 0$$

*Rationale:* If green debt facilitates sustainable capital allocation, issuing firms should exhibit higher pro-environmental capital deployment. To verify that this is not an accounting tautology mechanically reflecting the spent bond proceeds, green investment net of focal-bond capital must also expand.

> **H2 (Environmental Outcome Trajectory):** Environmental-use-of-proceeds bond issuance is associated with an increasingly negative post-issuance operational emissions trajectory over subsequent event horizons relative to matched peers:
> $$\text{ATT}_t^{\text{Emissions}} \le 0 \quad \text{for } t \ge 0, \quad \text{with } \frac{\partial |\text{ATT}_t^{\text{Emissions}}|}{\partial t} > 0 \quad \text{for } t \in \{+1, \dots, +5\}$$

*Rationale:* Physical green capital projects (e.g., renewable generation, heat-recovery systems) require multi-year engineering, construction, and operational commissioning. Consequently, post-issuance decarbonization should intensify dynamically over post-issuance event time.

> **H3 (Proceeds-Allocation Heterogeneity):** A greater contractual allocation of green-bond proceeds to new green capital projects is associated with stronger corporate green investment and physical emissions reductions, whereas allocations primarily directed to debt refinancing of pre-existing operational assets are associated with weaker incremental capital formation and environmental improvement:
> $$\frac{\partial |\text{ATT}^{\text{Emissions}}|}{\partial \text{AllocationNew}_i} > 0 \quad \text{and} \quad \frac{\partial \text{Green CapEx}}{\partial \text{AllocationNew}_i} > 0$$

*Rationale:* Under corporate finance principles of capital fungibility, new greenfield projects expand the physical abatement asset base, whereas refinancing operational assets merely restructures past capital expenditures without generating incremental physical abatement.

> **H4 (ESG Measurement Differentiation):** Commercial ESG ratings increase following green-bond issuance without statistically differentiating between contractual proceeds-allocation types, exhibiting limited differentiation despite divergent physical environmental trajectories:
> $$\Delta \text{ESG}_{\text{New}} \approx \Delta \text{ESG}_{\text{Refinancing}} \quad \text{and} \quad \frac{\partial \text{ESG}}{\partial \text{AllocationNew}_i} \approx 0$$

*Rationale:* Commercial rating agencies rely primarily on disclosed governance policies, security labels, and environmental commitments rather than verified, high-frequency physical emissions telemetry, leading to uniform score adjustments across divergent allocation profiles.

---

## 4. Data and Econometric Methods

### 4.1 Empirical Sample and Matching Architecture

Our empirical sample comprises 42 corporate environmental-use-of-proceeds bond issuers and 42 propensity-score-matched comparison firms (84 analytical entities) tracked annually over the 12-year window 2013–2024, yielding a balanced panel of 1,008 firm-year observations. 

**Instrument Qualification and Construct Validity:** In sustainable debt markets, instruments are defined by their contractual use of proceeds. Of the 42 treated issuers, 38 issued securities designated as Green Bonds under ICMA Green Bond Principles. Four issuers—Alphabet Inc. (2020), Amazon.com Inc. (2021), Salesforce Inc. (2021), and General Motors (2022)—issued debt under Sustainability Bond or Sustainable Financing Frameworks whose contractual proceeds allocations specifically fund qualifying environmental capital projects (clean energy PPAs, data center energy efficiency, EV charging infrastructure, and zero-emission delivery fleets). To test whether including these four instruments influences our conclusions, we execute two construct-validity sensitivity tests (Supporting Information Table S11b). Excluding the two dual-framework issuers that commingle social and environmental categories (Amazon and Salesforce) leaves $N = 40$ pairs (960 firm-years) and yields an essentially identical treatment effect ($\widehat{\text{ATT}} = -0.0942$, SE = 0.0113, $p < 0.001$, implied −8.99%). Enforcing a strict ICMA Green Bond-only threshold by further excluding Alphabet and General Motors leaves $N = 38$ pairs (912 firm-years) and yields $\widehat{\text{ATT}} = -0.0937$ (SE = 0.0116, $p < 0.001$, implied −8.94%). These tests establish that our results are not sensitive to the inclusion of qualifying sustainability-bond frameworks.

**Captive Financing Entities:** Within the Consumer Discretionary sector, two treated entities represent wholly owned captive vehicle-financing subsidiaries: Toyota Motor Credit Corporation (TMCC) and Ford Motor Credit Company LLC (FMCC). Contractually, green bonds issued by these captive entities finance retail leasing, consumer loans, and dealer inventory for zero-emission electric and hybrid vehicles. Because operational emissions (Scope 1+2), total CapEx, and balance-sheet assets are consolidated at the ultimate parent group level under IFRS/US-GAAP and CDP corporate disclosures, we evaluate outcomes at the consolidated operating parent level. Excluding TMCC and FMCC in Sensitivity 2 ($N = 40$ pairs, 960 firm-years) confirms that captive auto-financing structures do not drive our findings ($\widehat{\text{ATT}} = -0.0988$, SE = 0.0109, $p < 0.001$, implied −9.40%).

**Geographic and Sector Distribution:** The sample represents large multinational corporate issuers across North America (United States: 18 issuers, 42.9%), Western Europe (21 issuers, 50.0% across Germany, UK, France, Spain, Italy, Denmark, Portugal, Finland), Japan (2 issuers, 4.8%), and Brazil (1 issuer, 2.4%: Suzano S.A., an investment-grade USD-debt issuer). In total, 92.9% of treated issuers are domiciled in North America and Western Europe. Excluding Japan and Brazil in Sensitivity 1 ($N = 39$ pairs) yields $\widehat{\text{ATT}} = -0.0982$ (SE = 0.0108, $p < 0.001$, implied −9.36%). Sector coverage spans eight GICS sectors: Utilities ($N = 14$), Consumer Discretionary ($N = 7$), Real Estate ($N = 7$), Information Technology ($N = 4$), Telecommunications ($N = 4$), Consumer Staples ($N = 2$), Industrials ($N = 2$), and Materials ($N = 2$). Issuance cohorts span eight staggered adoption years: 2014, 2016, 2017, 2018, 2019, 2020, 2021, and 2022.

Table 1 provides variable definitions. Table 2 presents the sample composition.

### 4.2 Propensity-Score Matched Comparison Group

Because green-bond issuance is an observational corporate decision, non-random selection represents a primary identification challenge (Bolton & Kacperczyk, 2021). To achieve pre-treatment comparability on observed characteristics, each treated issuer is paired 1:1 with a never-treated sector peer using propensity-score matching (Rosenbaum & Rubin, 1983; Caliendo & Kopeinig, 2008). 

Matching is estimated using a logit model at the year immediately preceding first issuance ($t = g-1$), using a tight 0.05 caliper without replacement. The propensity score is estimated using three baseline financial and environmental covariates: firm size ($\ln[\text{Assets}]$), financial leverage ($\text{Long-Term Debt} / \text{Assets}$), and baseline Scope 1+2 emissions intensity ($\ln[\text{Scope 1+2} / \text{Revenue}]$). Sector matching was strictly satisfied within two-digit GICS sectors for 38 of 42 pairs (90.5%); the remaining 4 pairs were drawn from adjacent capital-intensive infrastructure peers to avoid caliper violations (excluding these 4 fallback pairs in Sensitivity 9 confirms robustness: $\widehat{\text{ATT}} = -0.0928$, SE = 0.0117, $p < 0.001$). 

Post-match balance diagnostics (Table 3 and Table S2) confirm balance across the matching covariates as well as four unmodeled diagnostic variables: return on assets (ROA), Tobin's q, baseline green CapEx share, and pre-issuance commercial ESG scores. Standardized mean differences (SMDs) are below 2.0% across all evaluated covariates, well below the standard 10% threshold (Austin, 2011). All 42 matched comparison firms were audited to confirm zero labeled sustainable-debt issuance throughout 2013–2024. While matching achieves balance on observable financial metrics, it cannot eliminate unobserved characteristics such as internal carbon prices, board-level climate governance, or pre-existing project pipelines.

### 4.3 Measuring Proceeds Allocation and Green Capital Formation

For each green bond, contractual proceeds deployment was manually audited from four primary corporate reporting sources:
1. Annual post-issuance Green Bond Allocation Reports and Use-of-Proceeds statements;
2. SEC Form 10-K/8-K filings and statutory annual financial reports;
3. Verified corporate responses to the CDP Climate Change Questionnaire;
4. Independent Second-Party Opinion (SPO) and post-issuance assurance reports (e.g., Sustainalytics, CICERO, DNV, ISS ESG).

Projects were classified as **new green capital formation** if proceeds funded greenfield development, technological expansion, or equipment acquired within 12 months prior to bond pricing (following ICMA GBP look-back conventions). Projects were classified as **refinancing** if proceeds retired existing debt or funded operational assets commissioned more than 12 months prior to issuance. Independent double-coding achieved 94.2% concordance, with discrepancies resolved via primary auditor assurance statements. Based on audited allocations, the treated sample comprises 31 new-project issuers ($\ge 70\%$ new CapEx), 6 mixed-allocation issuers, and 5 refinancing-dominated issuers ($\ge 70\%$ refinancing).

**Green Capital Expenditure Share:** Corporate green CapEx share ($\text{GreenCapExShare}_{it}$) is measured as pro-environmental capital expenditures as a percentage of total corporate CapEx. When green CapEx was not broken out as a discrete financial statement line item, eligible investments were mapped using audited allocation reporting.

**Non-Bond Green CapEx Benchmark:** A critical empirical concern in green finance research is mechanical accounting attribution: if a firm issues a $1 billion green bond and expends the proceeds on green projects, observed green CapEx expands purely as a direct expenditure of the debt. To test whether issuance stimulates capital formation beyond focal-bond proceeds, we construct a net green CapEx diagnostic deducting annualized bond proceeds over an assumed four-year deployment cycle:

$$\text{Non-GB\_CapEx}_{it} = \text{GreenCapExShare}_{it} - \left(\frac{\text{GBProceeds}_i \times \text{AllocationNew}_i / 4}{\text{TotalCapEx}_{it}}\right) \times 100\%$$

If $\text{Non-GB\_CapEx}$ increases post-issuance, it demonstrates that green investment expanded by more than the capital raised through the focal bond.

**Physical Carbon Accounting:** The primary environmental outcome is the natural logarithm of corporate Scope 1 (direct combustion) and Scope 2 (purchased electricity and steam) operational greenhouse gas emissions, measured in metric tons of carbon dioxide equivalent ($\text{tCO}_2\text{e}$) under the GHG Protocol Corporate Standard (WRI & WBCSD, 2004). We focus on Scope 1+2 emissions because they represent standardized, audited operational metrics. Scope 3 supply-chain emissions are excluded due to widespread reporting inconsistencies and disclosure gaps across the historical panel.

### 4.4 Econometric Identification

**Staggered Difference-in-Differences:** Our sample features eight adoption cohorts between 2014 and 2022. Econometric literature demonstrates that canonical two-way fixed effects (TWFE) regressions can assign negative weights to certain group-time treatment effects when adoption is staggered and treatment effects are dynamic or heterogeneous across cohorts (Callaway & Sant’Anna, 2021; de Chaisemartin & D'Haultfœuille, 2020; Goodman-Bacon, 2021; Sun & Abraham, 2021). Because green capital investments require multi-year engineering and deployment, treatment effects naturally intensify over post-issuance event time, making TWFE attenuation a tangible empirical problem.

We therefore implement the Callaway and Sant’Anna (2021) non-parametric staggered difference-in-differences estimator as our primary specification. The estimator calculates cohort-time average treatment effects:

$$\text{ATT}(g, t) = \mathbb{E}\left[Y_{it} - Y_{i,g-1} \mid G_g = 1\right] - \mathbb{E}\left[Y_{it} - Y_{i,g-1} \mid G_\infty = 1\right]$$

where $G_g$ denotes the cohort first issuing in year $g$, and $G_\infty$ denotes the pool of never-treated comparison firms. Overall and event-time ATTs are aggregated using cohort sample weights:

$$\text{ATT}(e) = \sum_{g} w_g(e) \cdot \text{ATT}(g, g+e)$$

guaranteeing positive weighting. Standard errors are clustered at the corporate entity level ($N = 84$).

**Continuous Proceeds Allocation Specification:** To evaluate the marginal role of proceeds allocation across the full spectrum of new-project financing, we estimate a fixed-effects interaction specification:

$$Y_{it} = \alpha_i + \lambda_t + \beta_1 \text{GreenBond}_{it} + \beta_2 (\text{GreenBond}_{it} \times \text{AllocationNew}_i) + \mathbf{X}'_{it}\boldsymbol{\gamma} + \varepsilon_{it}$$

where $\text{GreenBond}_{it}$ indicates post-issuance years, $\text{AllocationNew}_i \in [0, 1]$ is the continuous proportion allocated to new capital projects, and $\mathbf{X}_{it}$ controls for time-varying firm size ($\ln[\text{Assets}]$), profitability (ROA), financial leverage, and growth opportunities (Tobin's q). In this formulation, $\beta_1$ estimates the baseline post-issuance trajectory at zero new-project allocation (pure refinancing), while $\beta_2$ isolates the marginal post-issuance differential per percentage point of new-project allocation.

**Dynamic Event Study:** Pre-treatment parallel trends are formally evaluated across event horizons $\tau \in [-5, +5]$ relative to first issuance ($\tau = -1$ as reference). A joint Wald test evaluates pre-treatment lead coefficients.

---

## 5. Empirical Results

### 5.1 Descriptive Statistics and Baseline Covariate Balance

Table 3 presents baseline summary statistics and standardized mean differences. Prior to issuance ($t = g-1$), treated corporate issuers and matched comparison peers exhibit close balance across all dimensions: firm size ($\ln[\text{Assets}] = 8.38$ vs. 8.35, $\text{SMD} = 1.4\%$), financial leverage (0.341 vs. 0.339, $\text{SMD} = 1.1\%$), return on assets (0.068 vs. 0.067, $\text{SMD} = 1.6\%$), Tobin's q (1.83 vs. 1.82, $\text{SMD} = 1.3\%$), baseline emissions intensity (4.77 vs. 4.75 $\ln[\text{tCO}_2\text{e}/\$M]$, $\text{SMD} = 1.2\%$), and baseline green CapEx share (5.10% vs. 5.08%, $\text{SMD} = 0.5\%$). Pre-issuance commercial ESG scores average 54.1 for treated firms and 53.9 for controls ($\text{SMD} = 1.3\%$). This confirm that treated and comparison firms were balanced on observed financial and environmental metrics prior to entering the sustainable-debt market.

### 5.2 Overall Post-Issuance Environmental Differentials

Table 4 reports the baseline difference-in-differences estimates. Under the primary Callaway and Sant’Anna (2021) estimator, green-bond issuance is associated with a statistically significant reduction in operational Scope 1+2 emissions: $\widehat{\text{ATT}} = -0.0934$ (SE = 0.0110, $t = -8.49$, $p < 0.001$, 95% CI: [−0.1149, −0.0718]), corresponding to an implied 8.91% physical reduction in operational emissions relative to matched controls. 

In contrast, the canonical TWFE estimator yields an attenuated coefficient of $\hat{\beta}^{\text{TWFE}} = -0.0470$ (SE = 0.0068, $p < 0.001$, implied −4.59%). This 48% attenuation in the TWFE coefficient is consistent with negative-weighting bias when treatment effects grow dynamically over time, confirming the methodological importance of using heterogeneous-treatment-robust estimators in sustainable-finance evaluations.

Carbon intensity ($\ln[\text{Scope 1+2} / \text{Revenue}]$) demonstrates an analogous reduction: $\widehat{\text{ATT}} = -0.1017$ (SE = 0.0110, $t = -9.24$, $p < 0.001$), implying a 9.67% decline in emission intensity (95% CI: [−11.60%, −7.70%]). The TWFE estimate for carbon intensity is $\hat{\beta}^{\text{TWFE}} = -0.0470$ (SE = 0.0068, $p < 0.001$, implied −4.60%). As noted in the Table 4 footnote, the unrounded TWFE coefficients for emissions ($\beta = -0.047008$) and intensity ($\beta = -0.047047$) are distinct but round identically at four decimal places. Because absolute emissions and carbon intensity decline symmetrically, observed decarbonization reflects real operational efficiency improvements and clean energy deployment rather than business contraction.

Figure 4 reports the cohort-aligned pre-treatment event-time diagnostic. Pre-treatment lead coefficients ($\tau \in [-5, -1]$) are individually and jointly indistinguishable from zero (Wald $F = 0.285$, $p = 0.887$). While failure to reject parallel pre-trends does not prove the absence of unobserved confounding (Roth, 2022; Rambachan & Roth, 2023), it provides empirical reassurance that issuers and controls followed parallel decarbonization trajectories prior to debt issuance.

![Figure 4: Pre-Treatment Trends](Figures/fig05_pretreatment_trends.png)

**Figure 4. Cohort-aligned pre-treatment parallel-trend diagnostic.** Event-time coefficients for $\tau < 0$ relative to first issuance ($F = 0.285$, $p = 0.887$). Error bars denote 95% confidence intervals. Pre-issuance trajectories between green-debt issuers and matched controls are statistically parallel.

### 5.3 Corporate Green Capital Formation

Table 4 (Columns 3–5) presents the corporate investment response. Following green-bond issuance, the green capital expenditure share expands by +7.32 percentage points under Callaway–Sant’Anna ($\widehat{\text{ATT}} = +7.3211$, SE = 0.6373, $t = +11.49$, $p < 0.001$, 95% CI: [+6.07, +8.57] pp) and +5.15 pp under TWFE. 

Crucially, the net non-bond green CapEx metric ($\text{Non-GB\_CapEx}$)—which deducts the annualized focal-bond proceeds—expands by +6.60 percentage points ($\widehat{\text{ATT}} = +6.6002$, SE = 0.6120, $t = +10.78$, $p < 0.001$). Total corporate capital expenditure also expands by +4.15% ($\widehat{\text{ATT}} = +0.0407$, SE = 0.0050, $p < 0.001$). The fact that total CapEx expands confirms that green CapEx share growth was not driven by a contraction in total corporate investment. Furthermore, the +6.60 percentage-point expansion in non-bond green CapEx demonstrates that observed green capital formation is not an artifact of bond-proceeds accounting, consistent with Hypothesis H1.

![Figure 5: Green CapEx Response](Figures/fig07_green_capex.png)

**Figure 5. Corporate green investment response to green-bond financing.** Expansion in total green CapEx share (+7.32 pp CS ATT) and net Non-Green-Bond green CapEx share (+6.60 pp CS ATT; deducting focal-bond proceeds) relative to matched controls. Total corporate capital expenditure expands by +4.15%, confirming that green investment increases were not an artifact of denominator contraction.

### 5.4 Dynamic Event-Study Trajectories

Figure 2 illustrates the dynamic event-study trajectory for log Scope 1+2 emissions across event horizons $\tau \in [-5, +5]$:
- Year $\tau = 0$: $\hat{\beta}_0 = -0.0420$, implied −4.11% (SE = 0.0241, $p = 0.082$)
- Year $\tau = +1$: $\hat{\beta}_1 = -0.0980$, implied −9.33% (SE = 0.0275, $p < 0.001$)
- Year $\tau = +2$: $\hat{\beta}_2 = -0.1550$, implied −14.36% (SE = 0.0298, $p < 0.001$)
- Year $\tau = +3$: $\hat{\beta}_3 = -0.1880$, implied −17.14% (SE = 0.0315, $p < 0.001$)
- Year $\tau = +4$: $\hat{\beta}_4 = -0.2050$, implied −18.53% (SE = 0.0332, $p < 0.001$)
- Year $\tau = +5$: $\hat{\beta}_5 = -0.2140$, implied −19.26% (SE = 0.0351, $p < 0.001$)

**Cohort Composition across Event Time:** As detailed in Supporting Information Table S3b, the full 42-firm treated cohort contributes observations through $\tau = +2$. At $\tau = +3$, the 2022 adoption cohort drops out ($N_{\text{tr}} = 40$); at $\tau = +4$, the 2021 cohort drops out ($N_{\text{tr}} = 33$); and at $\tau = +5$, observations are contributed by 24 treated issuers from cohorts 2014–2019 matched to 42 comparison firms. At $\tau = 0$, during initial equipment procurement and facility engineering, the estimated differential is −4.11% and marginally significant ($p = 0.082$). Decarbonization deepens systematically over subsequent years, reaching −14.36% at $\tau = +2$ and −19.26% at $\tau = +5$ among observable early cohorts. This progressive multi-year deepening corresponds to physical capital deployment and commissioning cycles, consistent with Hypothesis H2.

![Figure 2: Dynamic Event Study](Figures/fig06_event_study.png)

**Figure 2. Dynamic event-study post-issuance trajectories for corporate Scope 1+2 emissions.** Callaway–Sant’Anna (2021) estimates relative to $\tau = -1$. Pre-issuance coefficients are statistically insignificant ($F = 0.285$, $p = 0.887$). Post-issuance emissions reductions grow from −4.11% at $\tau = 0$ to −19.26% at $\tau = +5$ (contributed by 24 early-cohort treated firms and 42 controls).

### 5.5 Proceeds Allocation and Environmental Heterogeneity

Table 5 presents the central empirical test of this study: whether post-issuance trajectories vary with contractual proceeds allocation (Hypothesis H3).

**Continuous Proceeds Allocation Model (Panel A):** In the continuous interaction specification, the baseline post-issuance parameter at zero new-project allocation is positive ($\hat{\beta}_1 = +0.0673$, SE = 0.0160, $p < 0.001$), whereas the interaction with new-project share is negative and statistically significant ($\hat{\beta}_2 = -0.1590$, SE = 0.0182, $p < 0.001$). This demonstrates that each 10 percentage-point increase in proceeds allocated to new physical green capital is associated with an incremental −1.59% post-issuance emissions differential ($p < 0.001$). 

At a model-implied 100% new-project allocation, the net estimated differential is:

$$\hat{\beta}_{\text{net}} = +0.0659 - 0.1554 = -0.0894 \quad (\text{SE} = 0.0091, t = -9.82, p < 0.001)$$

corresponding to an implied −8.77% emissions trajectory (evaluated via the delta method, parameter covariance $\text{Cov}(\beta_1, \beta_2) = -0.00028$). We emphasize that this −8.77% is a model-implied linear extrapolation at 100% allocation; the observed maximum allocation in the sample is 95.2%. Green CapEx share expands by a corresponding +9.57 percentage points at model-implied 100% new-project allocation ($p < 0.001$).

**Categorical Allocation Breakdown (Panel B):** When issuers are disaggregated into discrete allocation profiles:
- **New-Project Issuers ($\ge 70\%$ new CapEx, $N = 31$, 372 firm-years):** Post-issuance emissions decline by an average of −6.31% ($\hat{\beta} = -0.0651$, SE = 0.0076, $t = -8.57$, $p < 0.001$). Green CapEx share expands by +7.25 percentage points ($p < 0.001$).
- **Refinancing-Dominated Issuers ($\ge 70\%$ refinancing, $N = 5$, 60 firm-years):** In contrast, refinancing-dominated issuers exhibit a positive relative post-issuance divergence of +3.88% ($\hat{\beta} = +0.0380$, SE = 0.0088, $p < 0.001$) relative to matched controls, while their green CapEx share shows no expansion ($\hat{\beta} = -0.42$ pp, SE = 0.5121, $p = 0.412$). The point-estimate difference between new-project and refinancing cohorts is −0.1032 ($p < 0.001$).

**Inference Diagnostics for the Refinancing Subgroup:** Because the refinancing cohort contains only five corporate issuers, asymptotic cluster-robust standard errors may overstate statistical precision. We therefore perform comprehensive small-sample inference:
- Wild cluster bootstrap estimation confirms significance for the isolated refinancing parameter ($p = 0.0005$).
- Cluster-level randomization inference (2,000 Monte Carlo permutations at the firm cluster level) yields $p = 0.7015$ for the isolated refinancing parameter, reflecting the limited permutation power of assigning only five clusters across a heterogeneous treated sample.
- However, for the *contrast* between new-project and refinancing issuers ($\hat{\beta}_{\text{new}} - \hat{\beta}_{\text{ref}} = -0.1032$), cluster randomization inference confirms statistical significance at $p < 0.0001$, as does the wild cluster bootstrap ($p < 0.0001$).
- Leave-one-firm-out Jackknife across the refinancing issuers confirms stability, with estimates ranging between +3.73% and +4.57% (median +0.0399; Supporting Information Table S11).

Accordingly, we interpret the +3.88% refinancing estimate not as a standalone causal parameter, but as **exploratory evidence of trajectory heterogeneity** consistent with Hypothesis H3. The +3.88% relative divergence reflects the fact that, without adding new physical capacity, refinancing issuers do not keep pace with the ongoing secular decarbonization of matched comparison peers who continue their standard efficiency cycles.

![Figure 3: New vs Refinancing](Figures/fig14_new_vs_refinancing.png)

**Figure 3. Environmental outcomes of green-bond proceeds allocation.** Issuers allocating predominantly to new physical capital projects (≥70% new CapEx, $N = 31$) are associated with an average post-issuance emissions reduction of −6.31% ($\hat{\beta} = -0.0651$, $p < 0.001$). Refinancing-dominated issuers ($N = 5$, 60 firm-years) exhibit an exploratory +3.88% relative divergence ($\hat{\beta} = +0.0380$, $p < 0.001$). In contrast, commercial ESG ratings (right axis) exhibit identical upgrades (+0.90σ vs. +0.91σ), demonstrating limited rating differentiation despite divergent physical trajectories.

### 5.6 Commercial ESG Rating Differentiation Diagnostic

Table 6 evaluates commercial ESG rating responsiveness (Hypothesis H4). Standardized within rating provider and sector ($z$-scores), commercial ESG ratings increase significantly following issuance for both cohorts. Issuers allocating to new capital projects receive an average score enhancement of +0.9011σ ≈ +0.90σ (SE = 0.0184, $p < 0.001$). Issuers allocating predominantly to refinancing receive an essentially identical upgrade of +0.9053σ ≈ +0.91σ (SE = 0.0467, $p < 0.001$).

The estimated difference in ESG upgrades between refinancing and new-project issuers is:

$$\Delta = +0.0042\sigma \quad (\text{SE} = 0.0451\sigma, t = 0.092, p = 0.927)$$

The 95% confidence interval for this difference ([−0.0842σ, +0.0926σ]) falls entirely within an ex-ante practical equivalence bound of $\pm 0.10\sigma$. A formal two one-sided test (TOST) procedure confirms statistical equivalence within this bound ($t_1 = 2.31, t_2 = 2.12, p_{\text{TOST}} = 0.0168 < 0.05$; Supporting Information Table S16). In the continuous specification, the interaction between issuance and new-project allocation share is statistically zero ($\hat{\beta}_2 = -0.0339$, SE = 0.0897, $p = 0.705$). 

These findings provide empirical support for Hypothesis H4: commercial ESG rating adjustments do not meaningfully differentiate between sustainable-debt issues that fund new physical decarbonization and those that refinance existing assets. We characterize this pattern as **limited commercial ESG rating differentiation relative to physical environmental performance**. We avoid the term "greenwashing" because commercial ratings incorporate multi-dimensional governance metrics; nevertheless, the results demonstrate that commercial ESG scores treat labeled debt issuance as a uniform governance signal, obscuring material differences in physical decarbonization.

### 5.7 External Verification and Leverage Heterogeneity

Table 7 reports descriptive heterogeneity across external assurance and financial structure:

**External Verification:** Issuances supported by independent Second-Party Opinions (SPOs) from accredited providers (Sustainalytics, CICERO, DNV, ISS ESG; $N = 36$ firms) exhibit substantially stronger post-issuance emissions reductions ($\hat{\beta} = -0.0612$, SE = 0.0078, $p < 0.001$) than self-certified issuances ($N = 6$ firms, $\hat{\beta} = -0.0185$, SE = 0.0142, $p = 0.193$). The difference between verified and self-certified cohorts is statistically significant ($p = 0.009$). We treat this as informative heterogeneity rather than causal proof of certification efficacy, as firms soliciting external review may possess superior unobserved climate governance.

**Balance-Sheet Leverage:** Decarbonization is more pronounced among issuers with above-median financial leverage ($N = 22$, $\hat{\beta} = -0.0685$, $p < 0.001$) compared to below-median leverage issuers ($N = 20$, $\hat{\beta} = -0.0382$, $p < 0.001$; difference $p = 0.024$). This pattern is consistent with—though not definitive proof of—a financing-friction mechanism: more levered firms, which face tighter external borrowing constraints, experience greater investment relaxation when accessing dedicated sustainable-debt clienteles.

### 5.8 NLP Allocation Classification Validation

To evaluate whether contractual proceeds allocation can be identified systematically from unstructured corporate disclosures, an automated natural language processing (NLP) pipeline was applied to a corpus of 120 corporate allocation reports and prospectuses from 68 green-bond issuers. On a double-blind gold-standard subset of 30 documents, two independent sustainable-finance specialists achieved high inter-rater reliability (Cohen's $\kappa = 0.88$, observed agreement 93.3%). 

Across five issuer-stratified validation folds, the classification model achieved an overall out-of-fold accuracy of **82.5%** (99/120 documents correctly categorized), a Cohen's kappa of $\kappa = \mathbf{0.730}$, a macro-averaged F1 score of **0.813**, and a weighted F1 score of **0.824** (Supporting Information Table S12). These results indicate that contractual allocation profiles can be audited scalably from corporate reporting, providing a practical tool for sustainable-finance market surveillance.

### 5.9 Econometric Robustness and Sensitivity Checks

Table 8 reports an extensive battery of robustness tests confirming the stability of the Scope 1+2 emissions results, including formal re-estimated sensitivity models addressing geographic scope and captive vehicle financing:

- **Geographic scope sensitivity (Sensitivity 1):** When excluding the three issuers domiciled outside North America and Western Europe (Toyota Motor Credit Corporation, Honda Motor Co., and Suzano S.A.) and re-running the complete matching and econometric pipeline, the resulting matched sample comprises 39 treated pairs (78 firms, 936 firm-years). The Callaway–Sant’Anna average treatment effect on Scope 1+2 emissions is $\text{ATT} = -0.0982$ (SE = 0.0108, $t = -9.13, p < 0.001$), corresponding to an implied physical reduction of −9.36% (Supporting Information Table S11). The benchmark TWFE estimate is $\hat{\beta} = -0.0436$ (SE = 0.0068, $p < 0.001$, implied −4.27%). When candidate controls include all 40 never-treated comparison firms (81 firms, 972 firm-years), the estimated $\text{ATT}$ is −0.0984 (SE = 0.0109, $p < 0.001$, implied −9.37%). This confirms that multi-jurisdictional geographic composition does not drive the baseline findings.
- **Captive auto-finance sensitivity (Sensitivity 2):** When excluding the two captive vehicle-financing entities (Toyota Motor Credit Corporation and Ford Motor Credit Company LLC) and re-running the complete matching procedure, the resulting matched panel comprises 40 treated pairs (80 firms, 960 firm-years). The Callaway–Sant’Anna estimate is $\text{ATT} = -0.0988$ (SE = 0.0109, $t = -9.04, p < 0.001$), corresponding to an implied physical reduction of −9.40%. The benchmark TWFE estimate is $\hat{\beta} = -0.0456$ (SE = 0.0065, $p < 0.001$, implied −4.45%). Under the full-control candidate pool (82 firms, 984 firm-years), the $\text{ATT}$ is −0.0986 (SE = 0.0109, $p < 0.001$, implied −9.39%). These sensitivity analyses confirm that financing-vehicle corporate structures do not distort the empirical conclusions.

Additional robustness specifications include:
1. **Leave-Utilities-Out (Spec 4):** Excluding the 14 utility issuers ($N = 56$ firms, 672 firm-years) yields $\hat{\beta} = -0.0582$ ($p < 0.001$), confirming that findings are not driven by regulated electric utilities.
2. **Excluding COVID-19 (Spec 5):** Omitting pandemic shock years 2020–2021 ($N = 84$ firms, 840 firm-years) yields $\hat{\beta} = -0.0550$ ($p < 0.001$).
3. **Sector $\times$ Year Fixed Effects (Spec 6):** Controlling flexibly for sector-specific technological and macroeconomic shocks yields $\hat{\beta} = -0.0473$ ($p < 0.001$).
4. **Pre-2020 Issuance Cohorts (Spec 7):** Restricting estimation to mature cohorts first issuing before 2020 ($N = 66$ firms, 792 firm-years) yields $\hat{\beta} = -0.0350$ ($p = 0.002$).
5. **Temporal Placebo Test (Spec 8):** Assigning artificial treatment dates three years prior to actual issuance yields a precisely estimated zero effect ($\hat{\beta} = -0.0012$, SE = 0.0026, $p = 0.636$).
6. **Excluding Adjacent-Sector Matches (Spec 9):** Enforcing strict two-digit GICS sector matching by dropping the four fallback pairs ($N = 76$ firms, 912 firm-years) confirms robustness ($\text{CS ATT} = -0.0928$, SE = 0.0117, $p < 0.001$, implied −8.86%; $\hat{\beta}^{\text{TWFE}} = -0.0459$, $p < 0.001$).
7. **Leave-One-Firm-Out Jackknife:** Iteratively dropping each of the 84 firms confirms parameter stability (mean $\hat{\beta} = -0.0470$, range [−0.0495, −0.0444]). Winsorizing emissions at 1st/99th percentiles yields $\hat{\beta} = -0.0858$ ($p < 0.001$).

---

## 6. Discussion

Our empirical results provide comprehensive evidence on the transmission mechanism of sustainable finance. We structure our discussion around three core questions central to sustainable investment.

### 6.1 What Does This Tell Us About the Effectiveness of Green Finance?

Our findings indicate that post-issuance environmental trajectories vary with contractual proceeds allocation. Overall, green-debt issuance is associated with an 8.91% reduction in operational Scope 1+2 emissions, a 9.67% decline in carbon intensity, and a 7.32 percentage-point expansion in green capital expenditure share. Crucially, the net non-bond green CapEx expansion (+6.60 pp) confirms that pro-environmental investment expands beyond the capital directly supplied by the bond. 

Our empirical findings indicate that post-issuance environmental performance varies systematically with the contractual use of proceeds. The observed environmental benefits are concentrated among issuers that contractually direct proceeds toward new physical capital projects. In contrast, when green debt is applied to refinance pre-existing eligible assets, the transaction functions primarily as balance-sheet liability management. Because green-bond adoption is observational, these estimates capture differential post-issuance trajectories rather than exogenous causal effects of green debt per se.

### 6.2 Why Does Proceeds Allocation Matter for Sustainable Investment?

Proceeds allocation is the critical corporate finance mechanism governing investment and environmental additionality. Under capital fungibility (Myers, 1977), issuing debt against pre-existing operational assets allows a corporation to capture the pricing benefits and reputational goodwill of sustainable finance without modifying its physical capital stock. Because an operational asset is already generating environmental benefits, refinancing that asset creates zero contemporaneous incremental emissions displacement relative to matched industry peers.

Conversely, allocating proceeds to new capital projects expands the physical stock of clean technology, displacing fossil-fuel-intensive operational processes. Our continuous interaction results demonstrate that this relationship is linear and economically meaningful: each 10 percentage-point reallocation toward new projects corresponds to an incremental −1.59% emissions reduction. For sustainable investors seeking real-world climate impact—such as impact funds, pension funds with net-zero mandates, and Article 9 funds under the EU SFDR—proceeds allocation is the primary metric distinguishing genuine green capital formation from financial restructuring.

### 6.3 What Does the Divergence Between Physical Outcomes and ESG Ratings Imply for Sustainable-Finance Measurement?

The finding that commercial ESG ratings award indistinguishable score upgrades (+0.90σ vs. +0.91σ; difference = +0.0042σ, $p = 0.927$) across new-project and refinancing issuers highlights a structural vulnerability in sustainable-finance measurement. Commercial ESG rating methodologies evaluate corporate environmental performance largely through disclosed sustainability frameworks, governance policies, and labeled security issuances (Berg et al., 2022; Christensen et al., 2022; Edmans, 2023). 

This creates an information failure: market participants relying on headline ESG ratings cannot detect whether a green-bond issuer is actively expanding its clean capital stock or simply refinancing pre-existing assets. While we do not characterize this as intentional greenwashing—since rating agencies evaluate multifaceted corporate policies—it demonstrates that composite ESG scores decouple from verified carbon accounting. For sustainable capital markets to function efficiently, evaluation architectures must integrate verified physical carbon accounting alongside instrument-level allocation disclosures.

### 6.4 Downstream Implications for Sustainable Development Goals (SDGs)

While this paper is fundamentally an empirical study of sustainable finance, our findings have direct downstream implications for the United Nations Sustainable Development Goals:
- **SDG 13 (Climate Action):** Achieving corporate emissions reductions consistent with the 1.5°C Paris Agreement pathway requires that sustainable finance direct capital toward incremental physical decarbonization. Our evidence demonstrates that green-bond issuance is associated with meaningful decarbonization trajectories (−8.91% overall, with larger long-horizon reductions observed among mature cohorts) when proceeds fund new capital projects.
- **SDG 7 (Affordable and Clean Energy) and SDG 9 (Industry, Innovation, and Infrastructure):** The documented expansion in green CapEx share (+7.32 pp) and total corporate CapEx (+4.15%) indicates that green bonds facilitate clean energy deployment and low-carbon industrial infrastructure.
- **SDG 12 (Responsible Consumption and Production):** Our finding of limited ESG rating differentiation underscores the necessity of transparent, auditable sustainability disclosure standards to prevent information distortion in capital markets.

### 6.5 Policy Implications for Sustainable-Finance Markets

Our findings provide direct empirical support for policy and regulatory reforms aimed at strengthening sustainable-debt markets, aligning closely with recent recommendations by the OECD (2026):

1. **Differentiated Disclosure and Look-Back Standards:** The evidence is consistent with recent international recommendations (e.g., OECD, 2026) to consider differentiated eligibility treatment for new financing versus refinancing, including standardized look-back periods whose appropriate duration should be determined through regulatory and market consultation. Treating refinancing of pre-existing eligible assets as automatically equivalent to new green capital formation may overstate the sustainable-development impact of labeled instruments.
2. **Additionality Reporting Requirements:** The findings support consideration of standardized post-issuance disclosures specifying the precise dollar allocation between new capital expenditures and debt refinancing, alongside post-issuance asset-level emissions metrics verifiable by third parties. The NLP evidence demonstrates that such classification is feasible from existing textual disclosures, suggesting that contractual allocation categories may be amenable to scalable automated screening of corporate disclosure documents.
3. **Green-Bond Standards and Verification:** The verification heterogeneity result—stronger environmental outcomes among externally verified issuances ($\hat{\beta} = -0.0612$ vs. $-0.0185$, $p = 0.009$)—is consistent with enhanced external review strengthening the link between labeled instruments and physical outcomes. The findings suggest that regulators and standard-setters may consider differentiated disclosure of new-project financing and refinancing, alongside standardized reporting of post-issuance allocation and environmental outcomes.
4. **ESG Rating Standards:** Policymakers and market authorities may wish to consider whether commercial ESG rating methodologies should separately evaluate physical environmental performance from governance signaling, rather than conflating them in composite scores that may inadequately differentiate proceeds-allocation types.
5. **Auditing and Textual Screening Tools:** As demonstrated by our NLP classification pipeline (82.5% accuracy, $\kappa = 0.730$), regulatory authorities and institutional investors can deploy automated textual screening to monitor post-issuance allocation fidelity across global debt markets scalably.

---

## 7. Limitations

The empirical conclusions of this study are subject to several methodological and data constraints:

1. **Observational Design and Non-Random Selection:** Green-bond issuance is an endogenous corporate choice. While propensity-score matching achieves balance on observable financial characteristics, it cannot eliminate unobserved confounders such as managerial climate ambition, internal shadow carbon pricing, board-level sustainability expertise, or institutional shareholder pressure. Our estimates capture differential post-issuance trajectories rather than exogenous causal effects.
2. **Residual Selection and Parallel-Trends Diagnostics:** Although pre-treatment lead coefficients are statistically insignificant ($F = 0.285$, $p = 0.887$), statistical failure to reject null pre-trends does not prove the parallel-trends assumption, particularly in a sample of 42 treated entities (Rambachan & Roth, 2023; Roth, 2022).
3. **Scope 1 and 2 Focus:** Analysis is restricted to operational Scope 1 and Scope 2 emissions. Scope 3 value-chain emissions are excluded due to data unavailability and reporting inconsistencies. We cannot exclude the possibility of supply-chain carbon leakage or outsourcing.
4. **Small Refinancing Cohort:** The refinancing-dominated subgroup consists of only five corporate issuers (60 firm-years). While the +3.88% relative divergence is robust to leave-one-out Jackknife and bootstrap testing, cluster randomization inference yields $p = 0.7015$ for the isolated parameter due to limited permutation power. Consequently, we explicitly treat the refinancing finding as **exploratory evidence of trajectory heterogeneity** rather than a definitive population estimate.
5. **Geographic Concentration:** Over 92% of issuers are domiciled in North America and Western Europe. Generalizability to emerging sustainable-debt markets (e.g., China, India, Latin America) remains an open empirical question.
6. **Multi-Dimensional Nature of ESG Ratings:** Commercial ESG scores incorporate diverse social and governance indicators. Our finding of limited differentiation documents that rating adjustments do not differentiate allocation profiles; it does not imply intentional misrepresentation by rating agencies.

---

## 8. Conclusion

This study has investigated whether the contractual allocation of green-bond proceeds between new green capital projects and refinancing of pre-existing eligible assets affects the environmental and investment outcomes associated with sustainable finance. Using a Callaway and Sant’Anna (2021) staggered difference-in-differences design applied to an audited panel of 84 corporations (42 treated issuers and 42 matched comparison firms) over 2013–2024 (1,008 firm-years), we establish that corporate green bonds are associated overall with an 8.91% reduction in operational Scope 1+2 emissions, a 9.67% decline in carbon intensity, and a 7.32 percentage-point expansion in green capital expenditure share (net non-bond green CapEx: +6.60 pp).

Critically, these environmental trajectories are governed by contractual proceeds allocation. Each 10 percentage-point allocation to new green capital projects corresponds to an incremental −1.59% post-issuance emissions differential. Issuers allocating primarily to new capital projects achieve an average decarbonization of −6.31% (model-implied −8.77% at 100% allocation), whereas an exploratory cohort of five refinancing-dominated issuers exhibits a relative divergence of +3.88% from matched controls; the refinancing subgroup is interpreted as exploratory heterogeneity evidence rather than a standalone causal estimate. In contrast, commercial ESG ratings report statistically indistinguishable upgrades (+0.90σ vs. +0.91σ) across allocation profiles, illustrating limited differentiation between financial signaling and real-economy environmental outcomes.

Because treatment assignment is observational, our findings represent differential post-issuance trajectories rather than exogenous causal effects. Nonetheless, the evidence demonstrates that green-bond instrument design is central to the efficacy of sustainable finance: Within the observed sample, stronger post-issuance decarbonization associations are concentrated among issuers allocating proceeds toward new capital projects, whereas refinancing-dominated allocations exhibit weaker environmental trajectories. The findings provide empirical evidence relevant to proposals for greater differentiation between new-project financing and refinancing in green-finance disclosure and eligibility standards.

---

## Data Availability Statement

The replication package will be deposited in an appropriate open-access repository and, where permitted by data-licensing restrictions, archived through Zenodo with a linked GitHub repository containing the replication code.

## Declaration of Generative AI

Generative AI tools were utilized solely for code formatting, bibliographic auditing, and typesetting assistance. No AI tools were used for statistical estimation, data curation, or scientific interpretation. All content was verified by the authors.

---

## References

Baker, M., Bergstresser, D., Serafeim, G., & Wurgler, J. (2018). *Financing the response to climate change: The pricing and ownership of U.S. green bonds* (NBER Working Paper No. 25194). National Bureau of Economic Research. https://doi.org/10.3386/w25194

Berg, F., Kölbel, J. F., & Rigobon, R. (2022). Aggregate confusion: The divergence of ESG ratings. *Review of Finance*, *26*(6), 1315–1344. https://doi.org/10.1093/rof/rfac033

Bolton, P., & Kacperczyk, M. (2021). Do investors care about carbon risk? *Journal of Financial Economics*, *142*(2), 517–549. https://doi.org/10.1016/j.jfineco.2021.05.008

Caliendo, M., & Kopeinig, S. (2008). Some practical guidance for the implementation of propensity score matching. *Journal of Economic Surveys*, *22*(1), 31–72. https://doi.org/10.1111/j.1467-6419.2007.00527.x

Callaway, B., & Sant’Anna, P. H. C. (2021). Difference-in-differences with multiple time periods. *Journal of Econometrics*, *225*(2), 200–230. https://doi.org/10.1016/j.jeconom.2020.12.001

Christensen, D. M., Serafeim, G., & Sikochi, A. (2022). Why is corporate virtue in the eye of the beholder? The case of ESG ratings. *The Accounting Review*, *97*(1), 147–175. https://doi.org/10.2308/TAR-2019-0506

Climate Bonds Initiative. (2024). *Sustainable debt global state of the market 2024*. Climate Bonds Initiative. https://www.climatebonds.net/resources/reports/sustainable-debt-global-state-market-2024

de Chaisemartin, C., & D'Haultfœuille, X. (2020). Two-way fixed effects estimators with heterogeneous treatment effects. *American Economic Review*, *110*(9), 2964–2996. https://doi.org/10.1257/aer.20181169

Dorfleitner, G., Utz, S., & Zhang, R. (2022). The pricing of green bonds: External reviews and the shades of green. *Review of Managerial Science*, *16*(3), 797–834. https://doi.org/10.1007/s11846-021-00458-9

Edmans, A. (2023). The end of ESG. *Financial Management*, *52*(1), 3–17. https://doi.org/10.1111/fima.12413

Ehlers, T., Mojon, B., & Packer, F. (2021). Deconstructing green bonds, green loans, and ESG ratings. *BIS Quarterly Review*, September, 67–81. https://www.bis.org/publ/qtrpdf/r_qt2109b.htm

Ehlers, T., & Packer, F. (2017). Green bond finance: Build on a firm foundation. *BIS Quarterly Review*, September, 65–77. https://www.bis.org/publ/qtrpdf/r_qt1709f.htm

Fatica, S., & Panzica, R. (2021). Green bonds as a tool against climate change? *Business Strategy and the Environment*, *30*(5), 2688–2701. https://doi.org/10.1002/bse.2771

Fatica, S., Panzica, R., & Rancan, M. (2021). The pricing of green bonds: Are financial institutions special? *Journal of Financial Stability*, *54*, 100873. https://doi.org/10.1016/j.jfs.2021.100873

Fazzari, S. M., Hubbard, R. G., & Petersen, B. C. (1988). Financing constraints and corporate investment. *Brookings Papers on Economic Activity*, *1988*(1), 141–206. https://doi.org/10.2307/2534426

Flammer, C. (2021). Corporate green bonds. *Journal of Financial Economics*, *142*(2), 499–516. https://doi.org/10.1016/j.jfineco.2021.01.010

Gibson Brandon, R., Krueger, P., & Schmidt, P. (2021). ESG rating disagreement and stock returns. *Financial Analysts Journal*, *77*(4), 104–127. https://doi.org/10.1080/0015198X.2021.1963186

Giglio, S., Kelly, B., & Stroebel, J. (2021). Climate finance. *Annual Review of Financial Economics*, *13*, 15–36. https://doi.org/10.1146/annurev-financial-102620-103311

Goodman-Bacon, A. (2021). Difference-in-differences with variation in treatment timing. *Journal of Econometrics*, *225*(2), 254–277. https://doi.org/10.1016/j.jeconom.2021.03.014

Green, D. (2018). *Corporate refinancing, covenants, and the agency cost of debt* (Working Paper). Harvard Business School. https://doi.org/10.2139/ssrn.3424053

Grossmann, A., & Ngo, T. (2025). The stock market reaction to bond refinancing issues with and without senior debt. *Journal of Corporate Finance*, *91*, 102746. https://doi.org/10.1016/j.jcorpfin.2025.102746

Hartzmark, S. M., & Sussman, A. B. (2019). Do investors value sustainability? A natural experiment examining ranking and fund flows. *The Journal of Finance*, *74*(6), 2789–2837. https://doi.org/10.1111/jofi.12841

Heinkel, R., Kraus, A., & Zechner, J. (2001). The effect of green investment on corporate behavior. *Journal of Financial and Quantitative Analysis*, *36*(4), 431–449. https://doi.org/10.2307/2676219

Holmström, B., & Tirole, J. (1997). Financial intermediation, loanable funds, and the real sector. *The Quarterly Journal of Economics*, *112*(3), 663–691. https://doi.org/10.1162/003355397555316

Hong, H., Karolyi, G. A., & Scheinkman, J. A. (2020). Climate finance. *The Review of Financial Studies*, *33*(3), 1011–1023. https://doi.org/10.1093/rfs/hhz146

International Capital Market Association. (2021). *Green Bond Principles: Voluntary process guidelines for issuing green bonds*. ICMA. https://www.icmagroup.org/sustainable-finance/the-principles-guidelines-and-handbooks/green-bond-principles-gbp/

Kaplan, S. N., & Zingales, L. (1997). Do investment-cash flow sensitivities provide useful measures of financing constraints? *The Quarterly Journal of Economics*, *112*(1), 169–215. https://doi.org/10.1162/003355397555163

Kölbel, J. F., Heeb, F., Paetzold, F., & Busch, T. (2020). Can sustainable investing save the world? Reviewing the mechanisms of investor impact. *Organization & Environment*, *33*(4), 555–581. https://doi.org/10.1177/1086026620919202

Krueger, P., Sautner, Z., & Starks, L. T. (2020). The importance of climate risks for institutional investors. *The Review of Financial Studies*, *33*(3), 1067–1111. https://doi.org/10.1093/rfs/hhz137

Larcker, D. F., & Watts, E. M. (2020). Where's the greenium? *Journal of Accounting and Economics*, *69*(2-3), 101312. https://doi.org/10.1016/j.jacceco.2020.101312

Lyon, T. P., & Montgomery, A. W. (2015). The means and ends of greenwash. *Organization & Environment*, *28*(2), 223–249. https://doi.org/10.1177/1086026615575332

MacAskill, S., Roca, E., Liu, B., Stewart, R. A., & Sahin, O. (2021). Is there a green premium in the green bond market? Systematic literature review revealing premium determinants. *Journal of Cleaner Production*, *280*, 124491. https://doi.org/10.1016/j.jclepro.2020.124491

Myers, S. C. (1977). Determinants of corporate borrowing. *Journal of Financial Economics*, *5*(2), 147–175. https://doi.org/10.1016/0304-405X(77)90015-0

OECD. (2026). *OECD review on aligning finance with climate goals 2026: Different policy playbooks, untapped investment opportunities*. Organisation for Economic Co-operation and Development. https://doi.org/10.1787/79415c38-en

Pástor, Ľ., Stambaugh, R. F., & Taylor, L. A. (2021). Sustainable investing in equilibrium. *Journal of Financial Economics*, *142*(2), 550–571. https://doi.org/10.1016/j.jfineco.2020.12.011

Pedersen, L. H., Fitzgibbons, S., & Pomorski, L. (2021). Responsible investing: The ESG-efficient frontier. *Journal of Financial Economics*, *142*(2), 572–597. https://doi.org/10.1016/j.jfineco.2020.11.001

Rambachan, A., & Roth, J. (2023). A more credible approach to parallel trends. *The Review of Economic Studies*, *90*(5), 2555–2591. https://doi.org/10.1093/restud/rdad018

Rosenbaum, P. R., & Rubin, D. B. (1983). The central role of the propensity score in observational studies for causal effects. *Biometrika*, *70*(1), 41–55. https://doi.org/10.1093/biomet/70.1.41

Roth, J. (2022). Pretest with caution: Event-study estimates after testing for parallel trends. *American Economic Review: Insights*, *4*(3), 305–322. https://doi.org/10.1257/aeri.20210236

Stiglitz, J. E., & Weiss, A. (1981). Credit rationing in markets with imperfect information. *The American Economic Review*, *71*(3), 393–410. https://www.jstor.org/stable/1805953

Sun, L., & Abraham, S. (2021). Estimating dynamic treatment effects in event studies with heterogeneous treatment effects. *Journal of Econometrics*, *225*(2), 175–199. https://doi.org/10.1016/j.jeconom.2020.09.006

Tang, D. Y., & Zhang, Y. (2020). Do shareholders benefit from green bonds? *Journal of Corporate Finance*, *61*, 101427. https://doi.org/10.1016/j.jcorpfin.2018.12.001

World Resources Institute & World Business Council for Sustainable Development. (2004). *The greenhouse gas protocol: A corporate accounting and reporting standard* (Rev. ed.). WRI & WBCSD. https://ghgprotocol.org/corporate-standard

Xu, Q. (2018). Kicking maturity down the road: Early refinancing and maturity management in the corporate bond market. *The Review of Financial Studies*, *31*(8), 3061–3097. https://doi.org/10.1093/rfs/hhx116

Zerbib, O. D. (2019). The effect of pro-environmental preferences on bond prices: Evidence from green bonds. *Journal of Banking & Finance*, *98*, 39–60. https://doi.org/10.1016/j.jbankfin.2018.10.012

---

## Tables

### Table 1. Variable Definitions

| Variable | Definition | Source | JSF&I Scope Domain |
|---|---|---|---|
| Log_Emissions | Natural log of Scope 1+2 GHG emissions (tCO₂e) | CDP; verified corporate sustainability reports | Carbon accounting |
| Carbon_Intensity | ln(Scope 1+2 / Revenue, tCO₂e/$M) | CDP; audited financial reports | Environmental economics |
| Green_CapEx (%) | Green capital expenditure as % of total CapEx | Green Bond Allocation Reports; 10-K disclosures | Sustainable investment |
| Non-GB_CapEx (%) | Green CapEx net of focal-bond annualized proceeds | Constructed (Equation 1) | Investment additionality |
| Total_CapEx | ln(total corporate capital expenditure, $M) | Audited cash flow statements | Corporate investment |
| ESG_norm | Within-provider standardized ESG z-score | MSCI; S&P Global Trucost; Refinitiv | ESG measurement |
| GreenBond | Binary indicator: 1 for post-issuance years | Issuer prospectuses; CBI database | Green finance |
| AllocationNew | % of proceeds allocated to new capital projects | Audited post-issuance allocation reports | Financial instrument design |
| Leverage | Long-term debt / total assets | Audited balance sheets | Corporate finance |
| ln(Assets) | Natural log of total balance-sheet assets ($M) | Audited balance sheets | Corporate scale |
| ROA | Net income / total assets | Consolidated income statements | Operating profitability |
| Tobin's Q | (Market capitalization + book debt) / book assets | Bloomberg; Refinitiv | Investment opportunities |
| SPO_Verified | 1 = verified by accredited SPO provider | CBI records; SPO verification filings | Sustainable-finance credibility |

*Notes:* Scope 1 and Scope 2 operational emissions are measured in metric tCO₂e under the GHG Protocol Corporate Standard (WRI & WBCSD, 2004). Commercial ESG scores are normalized into within-provider and within-sector standardized scores: $\text{ESG\_norm} = (\text{ESG} - \mu_{\text{provider,sector}}) / \sigma_{\text{provider,sector}}$. AllocationNew is constructed from manual audit of post-issuance allocation reports and statutory filings (94.2% inter-coder concordance). Balanced panel covers 2013–2024 (1,008 firm-years).

---

### Table 2. Sample Structure and Sustainable-Debt Classification

| Classification / Sector | *N* Firms | *N* Firm-Years | Issuance Cohorts | Geographic Distribution |
|---|---|---|---|---|
| **Total Panel** | **84** | **1,008** | — | North America, Europe, Japan, Brazil |
| Environmental-use-of-proceeds bond issuers (treated) | 42 | 504 | 2014–2022 | 92.9% North America & Western Europe |
| — New-project issuers ($\ge 70\%$ new CapEx) | 31 | 372 | 2014–2022 | US (13), Europe (16), Japan (1), Brazil (1) |
| — Mixed-allocation issuers (30–70% new CapEx) | 6 | 72 | 2015–2021 | US (3), Europe (2), Japan (1) |
| — Refinancing-dominated issuers ($\ge 70\%$ refinancing) | 5 | 60 | 2016–2020 | US (2), Europe (3) |
| Matched comparison firms (never-treated controls) | 42 | 504 | — | 1:1 sector-matched peers |
| **GICS Sector Breakdown (Treated Issuers)** | | | | |
| Utilities | 14 | 168 | 2014–2022 | Electric & multi-utilities |
| Consumer Discretionary | 7 | 84 | 2014–2021 | Automotive (including 2 captive finance) |
| Real Estate | 7 | 84 | 2016–2021 | REITs & commercial property |
| Information Technology | 4 | 48 | 2020–2021 | Technology & cloud infrastructure |
| Telecommunications | 4 | 48 | 2019–2022 | Telecom infrastructure |
| Consumer Staples | 2 | 24 | 2016–2020 | Food & household products |
| Industrials | 2 | 24 | 2018–2021 | Transportation & engineering |
| Materials | 2 | 24 | 2016–2021 | Forestry & specialty chemicals |

*Notes:* Eight adoption cohorts: 2014, 2016, 2017, 2018, 2019, 2020, 2021, and 2022. No first issuances in 2015 in the analytical sample. 39 of 42 treated issuers (92.9%) are domiciled in North America and Western Europe (see Table S14b for detailed entity provenance). All 42 matched comparison firms are confirmed to have issued no publicly identified labeled sustainable debt during 2013–2024.

---

### Table 3. Descriptive Statistics and Pre-Treatment Covariate Balance

| Covariate | Treated Mean ($t=g-1$) | Control Mean ($t=g-1$) | Matched SMD (%) | Balance Status |
|---|---|---|---|---|
| $\ln(\text{Assets}, \$M)$ | 8.38 | 8.35 | 1.4% | Balanced |
| Return on Assets (ROA) | 0.068 | 0.067 | 1.6% | Balanced |
| Leverage Ratio | 0.341 | 0.339 | 1.1% | Balanced |
| Tobin's Q | 1.83 | 1.82 | 1.3% | Balanced |
| Baseline Emissions Intensity $[\ln(\text{tCO}_2\text{e}/\$M)]$ | 4.77 | 4.75 | 1.2% | Balanced |
| Baseline Green CapEx Share (%) | 5.10% | 5.08% | 0.5% | Balanced |
| Pre-Issuance Commercial ESG Score (raw) | 54.1 | 53.9 | 1.3% | Balanced |

*Notes:* Pre-treatment covariates are evaluated at the fiscal year immediately preceding first issuance ($t = g-1$) for treated issuers and at the corresponding matched year for comparison firms. Standardized mean difference (SMD) = $100 \times (\text{Mean}_{\text{Treated}} - \text{Mean}_{\text{Control}}) / \sqrt{(\text{SD}^2_{\text{Treated}} + \text{SD}^2_{\text{Control}})/2}$. SMD < 10% indicates excellent balance (Austin, 2011). Pre-treatment ESG, ROA, Tobin's Q, and Green CapEx serve as unmodeled balance diagnostics.

---

### Table 4. Baseline Staggered Difference-in-Differences Estimates: Environmental and Investment Outcomes

| | (1) Log Scope 1+2 | (2) Carbon Intensity | (3) Green CapEx (%) | (4) Non-GB CapEx (%) | (5) $\ln(\text{Total CapEx})$ |
|---|---|---|---|---|---|
| **Panel A: Callaway–Sant’Anna ATT** | | | | | |
| Average Treatment Effect ($\widehat{\text{ATT}}$) | −0.0934*** | −0.1017*** | +7.3211*** | +6.6002*** | +0.0407*** |
| Standard Error | (0.0110) | (0.0110) | (0.6373) | (0.6120) | (0.0050) |
| Implied Percentage Change | −8.91% | −9.67% | — | — | +4.15% |
| 95% Confidence Interval | [−10.86%, −6.93%] | [−11.60%, −7.70%] | [+6.07, +8.57 pp] | [+5.40, +7.80 pp] | [+3.14%, +5.17%] |
| **Panel B: Two-Way Fixed Effects Benchmark** | | | | | |
| TWFE Coefficient ($\hat{\beta}^{\text{TWFE}}$) | −0.0470*** | −0.0470*** | +5.1537*** | +2.9620*** | +0.0454*** |
| Standard Error | (0.0068) | (0.0068) | (0.4493) | (0.5011) | (0.0050) |
| Implied Percentage Change | −4.59% | −4.60% | — | — | +4.64% |
| Within $R^2$ | 0.396 | 0.461 | 0.491 | 0.320 | 0.526 |
| Firm Fixed Effects | Yes | Yes | Yes | Yes | Yes |
| Year Fixed Effects | Yes | Yes | Yes | Yes | Yes |
| Time-Varying Financial Controls | Yes | Yes | Yes | Yes | Yes |
| Number of Clusters (Firms) | 84 | 84 | 84 | 84 | 84 |
| Total Observations (Firm-Years) | 1,008 | 1,008 | 1,008 | 1,008 | 1,008 |

*Notes:* *** $p < 0.001$. Standard errors clustered at the corporate entity level ($N = 84$ clusters). Panel A reports the Callaway and Sant’Anna (2021) aggregated ATT across all eight cohorts relative to never-treated comparison firms. Panel B reports the conventional TWFE estimator with firm and year fixed effects and time-varying controls ($\ln[\text{Assets}]$, ROA, leverage, Tobin's q). Attenuation in TWFE estimates relative to Callaway–Sant’Anna ATTs is consistent with negative-weighting bias under staggered adoption. **Numerical Precision Note:** The reported TWFE coefficients for Log Scope 1+2 and Carbon Intensity appear identical at four decimal places (−0.0470 with SE 0.0068); their exact unrounded regression values are $\beta = -0.04700820$ (SE = 0.00684560, $p = 6.56 \times 10^{-12}$) for Log Scope 1+2 and $\beta = -0.04704746$ (SE = 0.00684811, $p = 6.45 \times 10^{-12}$) for Carbon Intensity. Non-GB CapEx deducts focal-bond annualized proceeds from green CapEx (Equation 1).

---

### Table 5. Corporate Environmental and Investment Trajectories by Proceeds Allocation

| | (1) Log Scope 1+2 Emissions | (2) Green CapEx Share (%) | (3) Commercial ESG ($z$-score) |
|---|---|---|---|
| **Panel A: Continuous Allocation Model** | | | |
| $\beta_1$ (GreenBond baseline, 0% new project allocation) | +0.0673*** | +2.1462*** | +0.9214*** |
| Standard Error | (0.0160) | (0.2543) | (0.0693) |
| $\beta_2$ (GreenBond $\times$ AllocationNew interaction) | −0.1590*** | +7.4232*** | −0.0339 |
| Standard Error | (0.0182) | (0.3110) | (0.0897) |
| Net Estimated Effect at 100% New Allocation ($\hat{\beta}_{\text{net}}$) | −0.0894*** | +9.5694*** | +0.8875*** |
| Standard Error (Delta Method) | (0.0091) | (0.3758) | (0.0285) |
| Model-Implied Differential at 100% Allocation | −8.77% | +9.57 pp | +0.89σ |
| **Panel B: Categorical Allocation Breakdown** | | | |
| New-Project Issuers ($\ge 70\%$ new; $N = 31$, 372 firm-years) | −0.0651*** | +7.25*** | +0.9011*** |
| Standard Error | (0.0076) | (0.3842) | (0.0184) |
| Implied Percentage Change | −6.31% | — | — |
| Refinancing Issuers ($\ge 70\%$ refinancing; $N = 5$, 60 firm-years) | +0.0380*** | −0.42 | +0.9053*** |
| Standard Error | (0.0088) | (0.5121) | (0.0467) |
| Implied Percentage Change | +3.88% | — | — |
| Difference Test: New-Project vs. Refinancing ($p$-value) | <0.001 | <0.001 | 0.927 |
| Firm and Year Fixed Effects | Yes | Yes | Yes |
| Time-Varying Financial Controls | Yes | Yes | Yes |
| Total Observations (Firm-Years) | 1,008 | 1,008 | 1,008 |

*Notes:* *** $p < 0.001$. Standard errors clustered at the firm level. Panel A reports the continuous interaction model where $\beta_1$ represents the baseline post-issuance trajectory at zero new-project allocation and $\beta_2$ isolates the marginal post-issuance differential per percentage point of new-project allocation. Net effect at 100% new-project allocation estimated via delta method using parameter covariance $\text{Cov}(\beta_1, \beta_2) = -0.00028$. Panel B reports categorical regressions. **Refinancing Cohort Caveat:** The refinancing-dominated subgroup consists of only 5 issuers (60 firm-years); its +3.88% relative divergence is treated as exploratory evidence of trajectory heterogeneity rather than a standalone causal parameter. Cluster randomization inference yields $p = 0.7015$ for the isolated refinancing parameter, but $p < 0.0001$ for the new-project versus refinancing contrast.

---

### Table 6. Commercial ESG Rating Differentiation Diagnostic

| ESG Rating Metric | Estimate | Inference & Diagnostics |
|---|---|---|
| New-Project Issuers Upgrade ($\ge 70\%$ new CapEx) | +0.9011***σ | SE = 0.0184, $p < 0.001$ |
| Refinancing-Dominated Issuers Upgrade ($\ge 70\%$ refinancing) | +0.9053***σ | SE = 0.0467, $p < 0.001$ |
| Upgrade Difference (Refinancing − New Project) | +0.0042σ | SE = 0.0451, $t = 0.092, p = 0.9265$ |
| 95% Confidence Interval of Difference | [−0.0842σ, +0.0926σ] | Fully within $\pm 0.10\sigma$ practical equivalence bound |
| Two One-Sided Test (TOST) Equivalence Test | Equivalence Confirmed | $t_1 = 2.31, t_2 = 2.12, p_{\text{TOST}} = 0.0168 < 0.05$ |
| Continuous Allocation Interaction Slope ($\beta_2$) | −0.0339 | SE = 0.0897, $t = -0.378, p = 0.705$ |

*Notes:* *** $p < 0.001$. Dependent variable is within-provider, within-sector standardized commercial ESG rating ($z$-score) across MSCI ESG Research (44.8%), S&P Global Trucost (35.2%), and Refinitiv ESG (20.0%). The 95% confidence interval of the upgrade difference between refinancing and new-project issuers falls entirely within the $\pm 0.10\sigma$ practical equivalence bound, and TOST confirms statistical equivalence ($p_{\text{TOST}} = 0.0168$). Results demonstrate limited differentiation in commercial ESG rating adjustments across proceeds-allocation profiles despite marked divergences in physical decarbonization trajectories.

---

### Table 7. Descriptive Heterogeneity by External Verification and Leverage

| Heterogeneity Dimension | Log Scope 1+2 Emissions Coefficient | Standard Error | $p$-value |
|---|---|---|---|
| **Panel A: External Second-Party Verification** | | | |
| Externally Verified Issuances ($N = 36$ firms) | −0.0612*** | (0.0078) | <0.001 |
| Self-Certified / Unverified Issuances ($N = 6$ firms) | −0.0185 | (0.0142) | 0.193 |
| Difference Test ($p$-value: Verified vs. Self-Certified) | **0.009** | — | — |
| **Panel B: Financial Leverage** | | | |
| Higher Leverage ($\ge$ Median, $N = 22$ firms) | −0.0685*** | (0.0095) | <0.001 |
| Lower Leverage (< Median, $N = 20$ firms) | −0.0382*** | (0.0097) | <0.001 |
| Difference Test ($p$-value: High vs. Low Leverage) | **0.024** | — | — |

*Notes:* *** $p < 0.001$. Standard errors clustered at the firm level. Verification status audited from CBI certification databases and published Second-Party Opinions (SPOs). Leverage defined as long-term debt / total assets at $t = g-1$. Results represent informative descriptive heterogeneity; selection into external verification is observational.

---

### Table 8. Econometric Robustness and Sensitivity Specifications (Dependent Variable: Log Scope 1+2 Emissions)

| Specification Number & Description | Estimator | *N* Firms | *N* Obs. | $\hat{\beta}$ / ATT | SE | $p$-value |
|---|---|:---:|:---:|:---:|:---:|:---:|
| (1) Baseline TWFE Benchmark | TWFE | 84 | 1,008 | −0.0470 | 0.0068 | <0.001 |
| (2) Primary Staggered DiD (Callaway–Sant’Anna) | CS DiD | 84 | 1,008 | −0.0934 | 0.0110 | <0.001 |
| (3) Carbon Intensity [ln(Scope 1+2 / Revenue)] | TWFE | 84 | 1,008 | −0.0470 | 0.0068 | <0.001 |
| (4) Leave-Utilities-Out Sensitivity | TWFE | 56 | 672 | −0.0582 | 0.0078 | <0.001 |
| (5) Exclude COVID-19 Shock (2020–2021) | TWFE | 84 | 840 | −0.0550 | 0.0088 | <0.001 |
| (6) Sector $\times$ Year Fixed Effects | TWFE | 84 | 1,008 | −0.0473 | 0.0071 | <0.001 |
| (7) Pre-2020 Adoption Cohorts Only | TWFE | 66 | 792 | −0.0350 | 0.0112 | 0.002 |
| (8) Temporal Placebo Test ($t-3$) | TWFE | 84 | 1,008 | −0.0012 | 0.0026 | 0.636 |
| (9) Strict Within-Sector Matching (Exclude 4 Fallbacks) | CS DiD | 76 | 912 | −0.0928 | 0.0117 | <0.001 |
| (10) Strict Within-Sector Matching (TWFE Benchmark) | TWFE | 76 | 912 | −0.0459 | 0.0074 | <0.001 |

*Notes:* Standard errors clustered at the firm level. Specification (9) excludes the four adjacent-sector fallback pairs (76 firms, 38 exact within-sector pairs, 912 firm-years), yielding Callaway–Sant’Anna ATT = −0.0928 (SE = 0.0117, $p < 0.001$, implied −8.86%) and TWFE = −0.0459 (SE = 0.0074, $p < 0.001$, implied −4.48%). Leave-one-firm-out Jackknife across all 84 firms confirms parameter stability (mean −0.0470, range [−0.0495, −0.0444]). Winsorizing emissions at 1st/99th percentiles yields $\hat{\beta} = -0.0858$ ($p < 0.001$).

---

## Figure Legends

### Figure 1. Conceptual Framework of Sustainable-Finance Additionality and Proceeds Allocation
![Figure 1: Conceptual Framework](Figures/fig01_conceptual_framework.png)

**Figure 1.** Conceptual framework linking green-bond proceeds allocation to environmental additionality and sustainable development. The framework distinguishes financing additionality (whether green debt expands the total capital envelope), investment additionality (whether proceeds finance new physical capacity versus refinancing), and environmental additionality (measured Scope 1+2 emissions reductions). Solid lines indicate theoretically expected pathways; dashed lines indicate the investment additionality condition required for physical environmental outcomes to follow. SDG linkages (13, 7, 9, 12) are described as downstream implications of real-economy outcomes.

### Figure 2. Dynamic Event-Study Trajectories for Corporate Scope 1+2 Emissions
![Figure 2: Dynamic Event-Study Trajectories](Figures/fig06_event_study.png)

**Figure 2.** Dynamic event-study post-issuance trajectories for log Scope 1+2 emissions (event times $\tau = -5$ to $+5$). Estimated using the Callaway–Sant’Anna (2021) estimator with $\tau = -1$ as the reference period. Pre-treatment lead coefficients ($\tau \in [-5, -2]$) are jointly insignificant (Wald $F = 0.285$, $p = 0.887$). Post-issuance differentials grow progressively from −4.11% at $\tau = 0$ to −19.26% at $\tau = +5$. At event time $\tau = +5$, observations are contributed by 24 treated issuers from cohorts 2014–2019 and 42 comparison controls (see Table S3b for complete cohort composition).

### Figure 3. Environmental Outcomes of Green-Bond Proceeds Allocation
![Figure 3: Physical Outcomes by Proceeds Allocation Category](Figures/fig14_new_vs_refinancing.png)

**Figure 3.** Physical environmental trajectories by proceeds allocation category. Allocations to new capital projects ($\ge 70\%$ new CapEx, $N = 31$ issuers) are associated with an average post-issuance reduction of approximately −6.31% ($\hat{\beta} = -0.0651$, $p < 0.001$). Refinancing allocations (exploratory cohort, $N = 5$ issuers, 60 firm-years) exhibit a +3.88% relative post-issuance divergence from matched controls. Error bars show 95% confidence intervals based on the cluster-robust standard errors reported in Table 5 Panel B (±1.96 × SE). Commercial ESG ratings (right axis) show comparable upgrades across both cohorts (+0.90σ vs. +0.91σ), illustrating limited differentiation between reputational signals and physical outcomes.

### Figure 4. Cohort-Aligned Pre-Treatment Parallel-Trend Diagnostic
![Figure 4: Cohort-Aligned Pre-Treatment Parallel-Trend Diagnostic](Figures/fig05_pretreatment_trends.png)

**Figure 4.** Cohort-aligned pre-treatment parallel-trend diagnostic. Event-time estimates for $\tau < 0$ relative to first issuance are jointly insignificant (Wald $F = 0.285$, $p = 0.887$). Error bars denote 95% confidence intervals. Failure to reject the null does not establish the parallel-trends assumption, but indicates parallel pre-issuance trajectories between issuers and matched controls.

### Figure 5. Corporate Green Investment Response to Green-Bond Financing
![Figure 5: Green Capital Expenditure Response](Figures/fig07_green_capex.png)

**Figure 5.** Corporate green investment response to green-bond financing. Comparison of total green CapEx share (+7.32 pp CS ATT) and Non-Green-Bond green CapEx share (+6.60 pp CS ATT; deducting focal-bond proceeds) for treated issuers relative to matched controls. Total corporate capital expenditure expands by +4.15%, confirming that green CapEx share increases were not driven solely by a contraction in the denominator.
