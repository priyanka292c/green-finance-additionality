import os
import re

tex_path = r'09_JSFI_Submission\LaTeX_Source\02_JSFI_Anonymous_Manuscript.tex'
with open(tex_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Harmonize Title and Running Title
content = re.sub(
    r'\\textbf\{Running title:\}[^\n\\]+',
    r'\\textbf{Running title:} Green-Bond Allocation and Emissions Trajectories',
    content
)

# 2. Update Abstract with disciplined language and explicit exploratory caveats
new_abstract = r"""\begin{abstract}
\noindent
Green bonds are designed to intermediate financial capital toward environmentally beneficial corporate activities, but subsequent operational emissions trajectories may depend on whether proceeds finance new green capital projects or refinance pre-existing eligible assets. Most empirical green-bond studies treat issuance as a relatively homogeneous financial instrument and pay insufficient attention to contractual proceeds allocation. Using an audited panel of 84 multinational corporations---comprising 42 corporate environmental-use-of-proceeds bond issuers (38 qualifying ICMA Green Bonds and 4 corporate Sustainability Bonds with qualifying environmental allocations) and 42 propensity-score-matched comparison firms---observed annually over 2013--2024 (1,008 firm-years), we implement a Callaway--Sant'Anna staggered difference-in-differences design. Environmental-debt issuance is associated overall with an 8.91\% reduction in Scope 1+2 emissions (CS ATT = $-0.0934, p < 0.001$), a 9.67\% decline in carbon intensity (CS ATT = $-0.1017, p < 0.001$), and a 7.32 percentage-point expansion in green capital expenditure share (accounting-adjusted net green CapEx diagnostic: +6.60 pp, $p < 0.001$). However, post-issuance environmental trajectories vary systematically with contractual proceeds allocation: each 10 percentage-point allocation to new green capital projects is associated with an incremental $-1.59\%$ post-issuance emissions differential ($p < 0.001$). Issuers allocating predominantly to new physical projects ($N = 31$) achieve an average post-issuance emissions reduction of $-6.31\%$ relative to matched controls; the linear specification implies a model-extrapolated $-8.77\%$ differential at a hypothetical 100\% new-project allocation (observed maximum: 95.2\%). In contrast, an exploratory cohort of five refinancing-dominated issuers exhibits a relative post-issuance divergence of +3.88\% from matched controls, though inference is highly uncertain given the small subgroup size. Commercial ESG ratings increase similarly across allocation types (difference = $+0.0042\sigma, p = 0.927$; TOST equivalence $p = 0.0168$), indicating limited differentiation in rating adjustments despite divergent physical outcomes. Because treatment assignment is observational, these estimates reflect differential post-issuance trajectories across allocation profiles rather than causal additionality. The findings highlight the importance of proceeds allocation disclosures, look-back standards, and carbon-accounting verification in sustainable-finance markets.

\vspace{0.8em}
\noindent \textbf{Keywords:} Sustainable finance; Green bonds; Proceeds allocation; Corporate decarbonization; ESG disclosure; Climate finance; Carbon accounting; Environmental trajectories \\
\noindent \textbf{JEL Classifications:} G12, G14, G31, G32, Q54, Q56, Q58
\end{abstract}"""

content = re.sub(r'\\begin\{abstract\}.*?\\end\{abstract\}', lambda m: new_abstract, content, flags=re.DOTALL)

# 3. Fix Metcalf & Stock citation
content = content.replace("Metcalf & Stock (2020)", "Metcalf & Stock (2023)")
content = content.replace("Metcalf and Stock (2020)", "Metcalf and Stock (2023)")

# 4. Reconcile Table 7 numerical counts in text
# Text previously had 34 vs 36, and 20 vs 22
content = content.replace("Externally verified issuances (34 firms", "Externally verified issuances (36 firms")
content = content.replace("Externally verified issuances (34 treated", "Externally verified issuances (36 treated")
content = content.replace("higher-leverage issuers (leverage >= median, N = 20", "higher-leverage issuers (leverage >= median, N = 22")
content = content.replace("higher-leverage issuers (leverage $\\ge$ median, N = 20", "higher-leverage issuers (leverage $\\ge$ median, N = 22")
content = content.replace("higher leverage (N = 20)", "higher leverage (N = 22)")

# 5. Condense NLP section in main text
nlp_main_text = r"""\subsection{NLP Allocation Classification Validation Note}
\label{sec:nlp_note}
To evaluate whether contractual proceeds allocation can be identified systematically from unstructured corporate disclosures, an automated natural language processing (NLP) pipeline was applied to a corpus of 120 corporate allocation reports and prospectuses from 68 green-bond issuers. The classifier achieved an overall out-of-fold accuracy of 82.5\% ($\kappa = 0.730$, macro F1 = 0.813) against double-blind gold-standard human audits. Because this exercise serves strictly as a measurement-validation diagnostic rather than an econometric identification tool, the complete methodological architecture, prompt engineering, feature tokenization, and out-of-fold confusion matrix are reported in Supplementary Material Section S7 and Table S12."""

content = re.sub(r'\\subsection\{Robustness Analysis\}\s*As a measurement-validation exercise.*?\\subsection\{Robustness Tests\}',
                 lambda m: nlp_main_text + '\n\n' + r'\subsection{Robustness Analysis}',
                 content, flags=re.DOTALL)

# Save updated LaTeX
with open(tex_path, 'w', encoding='utf-8') as f:
    f.write(content)

print(f"Updated {tex_path} successfully.")
