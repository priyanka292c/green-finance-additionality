import os
import sys
import re
import shutil
import subprocess

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')
latex_dir = os.path.join(jsfi_dir, "LaTeX_Source")
sd_latex_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\08_Wiley_SD_Submission\LaTeX_Source')

pdflatex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'
bibtex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe'

# 1. Ensure assets
os.makedirs(latex_dir, exist_ok=True)
os.makedirs(os.path.join(latex_dir, "Figures"), exist_ok=True)

for f in os.listdir(os.path.join(jsfi_dir, "Figures")):
    src_f = os.path.join(jsfi_dir, "Figures", f)
    dst_f = os.path.join(latex_dir, "Figures", f)
    if not os.path.exists(dst_f):
        shutil.copy2(src_f, dst_f)

shutil.copy2(os.path.join(sd_latex_dir, "sd_references.bib"), os.path.join(latex_dir, "references.bib"))

# 2. Build 01_JSFI_Title_Page.tex
title_page_tex = r"""\documentclass[12pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage[margin=1in]{geometry}
\usepackage{setspace}
\doublespacing
\usepackage{xcolor}
\usepackage{enumitem}
\usepackage{hyperref}

\hypersetup{
    colorlinks=true,
    linkcolor=black,
    citecolor=black,
    urlcolor=blue!70!black
}

\begin{document}

\begin{center}
    {\Large \textbf{Title Page --- \textit{Journal of Sustainable Finance \& Investment}} \par}
    \vspace{0.8em}
    \hrule
    \vspace{1.2em}
    {\LARGE \textbf{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing} \par}
    \vspace{0.8em}
    {\large \textbf{Running title:} Green-Bond Allocation \& Environmental Additionality \par}
    \vspace{0.5em}
    {\small Submitted to \textit{Journal of Sustainable Finance \& Investment} (Taylor \& Francis) \par}
\end{center}

\vspace{1em}

\section*{Authors and Affiliations}

\textbf{Shahrukh Saleem}$^1$ \\
\textbf{Araby Madbouly}$^2$ \\
\textbf{Uvesh Husain}$^3$ \\
\textbf{Ram Soorat}$^{4*}$ \textit{(Corresponding Author)} \\
\textbf{Priyanka}$^5$ \\
\textbf{Afzalur Rahman}$^6$

\vspace{0.8em}

\noindent $^1$ VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India \\
$^2$ Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman \\
$^3$ Economics and Business Studies Department, Mazoon College, Muscat, Oman \\
$^4$ School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\
$^5$ Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India \\
$^6$ School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India

\vspace{1em}

\section*{Corresponding Author Contact Details}
\textbf{Ram Soorat} \\
Assistant Professor \\
School of Technology, Woxsen University \\
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\
Email: \url{ram.soorat@woxsen.edu.in} \\
Telephone: +91 8455 305555 \\
ORCID: \url{https://orcid.org/0000-0001-7875-9197}

\vspace{1em}

\section*{Co-Author Contact Information}
\begin{itemize}[leftmargin=1.5em,noitemsep]
    \item \textbf{Shahrukh Saleem:} Assistant Professor, VIT Business School, Vellore Institute of Technology, Vellore, India. Email: \url{shahrukh.saleem@vit.ac.in}; ORCID: \url{https://orcid.org/0000-0003-2949-6188}
    \item \textbf{Araby Madbouly:} Associate Professor, Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman. Email: \url{araby@muscatcollege.edu.om}; ORCID: \url{https://orcid.org/0000-0002-7981-4191}
    \item \textbf{Uvesh Husain:} Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Oman. Email: \url{owais.husain@mazcol.edu.om}; ORCID: \url{https://orcid.org/0000-0002-8502-8488}
    \item \textbf{Ram Soorat:} Assistant Professor, School of Technology, Woxsen University, Hyderabad, India. Email: \url{ram.soorat@woxsen.edu.in}; ORCID: \url{https://orcid.org/0000-0001-7875-9197}
    \item \textbf{Priyanka:} Department of Physics and Astrophysics, University of Delhi, New Delhi, India. Email: \url{priyanka1@physics.du.ac.in}; ORCID: \url{https://orcid.org/0009-0008-1520-0706}
    \item \textbf{Afzalur Rahman:} School of Business, Woxsen University, Hyderabad, India. Email: \url{afzalur.rahman@woxsen.edu.in}; ORCID: \url{https://orcid.org/0000-0002-1561-561X}
\end{itemize}

\vspace{1em}

\section*{Acknowledgements}
The authors are grateful to the seminar participants at the Sustainable Finance, Financial Econometrics, and Climate Economics Working Seminars for constructive discussions and feedback on earlier versions of this research. The authors also thank the data-verification team for assistance with archival regulatory filing cross-checks.

\vspace{1em}

\section*{Funding Statement}
This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

\vspace{1em}

\section*{Conflict of Interest Statement}
The authors declare that they have no known competing financial interests, affiliations, or personal relationships that could have appeared to influence the work reported in this paper.

\vspace{1em}

\section*{Ethics Statement}
This study analyzes publicly disclosed corporate financial, emissions, and contractual allocation disclosures and does not involve human participants, animal experimentation, or tissue samples. Institutional ethical review was not required.

\vspace{1em}

\section*{Data Availability Statement}
The complete replication package—including Python and Stata replication scripts, the master empirical workbook, JSON analytical files, Table S14b issuer-level provenance records, and data-curation logs—will be deposited and made publicly accessible upon publication via the journal repository and archived through \url{https://github.com/rsoorat/green-finance-refinancing}/Zenodo. Proprietary third-party data (CDP Scope 1+2 emissions and Bloomberg financial records) remain subject to their respective licensing terms.

\vspace{1em}

\section*{CRediT Author Contribution Statement}
\begin{itemize}[leftmargin=1.5em,noitemsep]
    \item \textbf{Shahrukh Saleem:} Conceptualization, Methodology, Formal analysis, Investigation, Writing -- Original Draft, Writing -- Review \& Editing, Supervision, Project administration.
    \item \textbf{Araby Madbouly:} Resources, Data curation, Writing -- Review \& Editing.
    \item \textbf{Uvesh Husain:} Data curation, Formal analysis, Software, Writing -- Review \& Editing.
    \item \textbf{Ram Soorat:} Conceptualization, Methodology, Writing -- Review \& Editing, Validation, Supervision, Project administration.
    \item \textbf{Priyanka:} Data curation, Software, Formal analysis, Visualization, Writing -- Review \& Editing.
    \item \textbf{Afzalur Rahman:} Investigation, Visualization, Validation, Writing -- Review \& Editing.
\end{itemize}

\vspace{1em}

\section*{Declaration of Generative AI}
Generative AI tools were used solely for code-formatting, bibliographic verification, and LaTeX/HTML typesetting assistance. No generative AI tool was used to perform statistical estimation, data curation, scientific interpretation, or formulate empirical conclusions. All AI-assisted outputs were reviewed and verified by the authors, who take full responsibility for the manuscript.

\vspace{1em}

\section*{Submission Declaration}
This manuscript represents original work that has not been published previously and is not under consideration for publication elsewhere. All co-authors have approved the submitted manuscript and consent to its publication in the \textit{Journal of Sustainable Finance \& Investment}.

\end{document}
"""

with open(os.path.join(latex_dir, "01_JSFI_Title_Page.tex"), "w", encoding="utf-8") as f:
    f.write(title_page_tex)
print("Wrote 01_JSFI_Title_Page.tex")

# 3. Build 04_JSFI_Cover_Letter.tex
cover_letter_tex = r"""\documentclass[12pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage[margin=1in]{geometry}
\usepackage{setspace}
\onehalfspacing
\usepackage{hyperref}
\usepackage{enumitem}

\hypersetup{
    colorlinks=true,
    linkcolor=black,
    citecolor=black,
    urlcolor=blue!70!black
}

\begin{document}

\noindent
\textbf{Ram Soorat} \\
School of Technology, Woxsen University \\
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\
Email: \url{ram.soorat@woxsen.edu.in} \\
Telephone: +91 8455 305555 \\
ORCID: \url{https://orcid.org/0000-0001-7875-9197}

\vspace{1em}
\noindent 29 September 2026

\vspace{1em}
\noindent
\textbf{Professor [Editor-in-Chief / Editorial Board]} \\
Editor-in-Chief \\
\textit{Journal of Sustainable Finance \& Investment} \\
Taylor \& Francis Group

\vspace{1.2em}
\noindent
\textbf{SUBJECT: Submission of Original Research Manuscript}

\vspace{0.5em}
\noindent
\textbf{Manuscript Title:} \textit{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing}

\vspace{1em}
\noindent Dear Editor-in-Chief and Editorial Board Members,

\vspace{0.5em}
We are pleased to submit our original empirical research manuscript, entitled \textbf{``Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing,''} for consideration for publication in the \textit{Journal of Sustainable Finance \& Investment} (JSF\&I).

\subsection*{Core Research Domain and Alignment with JSF\&I Scope}
Our study falls squarely within the stated core mission of JSF\&I: publishing high-quality empirical contributions in \textbf{sustainable finance and investment}, \textbf{green finance}, \textbf{ESG integration}, \textbf{climate finance}, \textbf{carbon accounting}, and \textbf{ESG disclosure}. 

While the global sustainable-debt market has surpassed USD 5 trillion, a foundational structural problem remains empirically unresolved: \textit{Does the contractual allocation of green-bond proceeds between new green capital projects and refinancing of existing eligible assets affect the environmental and investment outcomes associated with sustainable finance?}

Existing empirical literature in sustainable finance has concentrated disproportionately on secondary-market pricing dynamics (the ``greenium'') and aggregate ESG score responses, while almost universally treating green-bond issuance as a binary, homogeneous intervention ($D_{it} \in \{0, 1\}$). In doing so, prior research overlooks the central corporate-finance mechanism governing sustainable debt: whether proceeds fund genuinely incremental green capital formation or merely restructure liabilities on pre-existing operational assets.

\subsection*{Novel Contributions to Sustainable Finance}
Addressing this critical gap, our manuscript provides four distinct contributions directly aligned with JSF\&I's readership:
\begin{enumerate}[leftmargin=1.5em]
    \item \textbf{Sustainable-Finance Instrument Design:} Through manual audit of post-issuance allocation disclosures, regulatory filings, and second-party assurance reports across an audited panel of 84 multinational corporations (42 treated issuers and 42 propensity-score-matched peers, 1,008 firm-years over 2013--2024), we provide the first systematic empirical evidence that the contractual allocation of proceeds---specifically the ratio of new capital formation to debt refinancing---is the primary determinant of post-issuance environmental trajectories.
    \item \textbf{Corporate Green Capital Formation and Additionality:} Applying the Callaway and Sant'Anna (2021) staggered difference-in-differences estimator (robust to negative-weighting bias under heterogeneous adoption timing), we show that green-debt issuance is associated overall with an 8.91\% reduction in operational Scope 1+2 emissions, a 9.67\% decline in carbon intensity, and a 7.32 percentage-point expansion in green capital expenditure share. Crucially, pro-environmental capital deployment expands by +6.60 percentage points even after deducting focal-bond proceeds, confirming that the observed investment response is not an accounting artifact of bond proceeds. Furthermore, we show that this physical capital formation is concentrated among issuers funding new projects, whereas an exploratory cohort of refinancing-dominated issuers exhibits an exploratory relative divergence of +3.88\% from matched controls.
    \item \textbf{ESG Measurement and Carbon-Accounting Disconnect:} We document that commercial ESG ratings award indistinguishable score upgrades ($+0.90\sigma$ vs. $+0.91\sigma$; difference = $+0.0042\sigma, p = 0.927$; formal TOST equivalence $p = 0.0168$) across new-project and refinancing issuers despite statistically and economically significant divergences in physical emissions reductions. This provides striking evidence that commercial ESG ratings treat labeled issuance as a uniform governance signal, obscuring material divergences in real-economy environmental outcomes.
    \item \textbf{Policy Relevance for Sustainable-Debt Standards:} We translate these empirical findings into actionable recommendations for standard-setters (ICMA, ESMA, SEC) and institutional investors, supporting recent international calls (e.g., OECD, 2026) for standardized allocation disclosure, strict look-back rules, and the integration of verified carbon accounting into sustainable-finance verification architectures.
\end{enumerate}

\subsection*{Methodological Rigor and Research Integrity}
We emphasize that green-bond issuance is an observational corporate decision. Accordingly, our econometric framework combines propensity-score matching, cohort-aligned parallel-trend diagnostics ($F = 0.285, p = 0.887$), non-parametric staggered difference-in-differences, continuous interaction specifications, cluster-level randomization inference, and extensive robustness perturbations (including leave-utilities-out, pandemic-exclusion, and strict instrument-label definitions). We maintain disciplined scientific language throughout, framing all empirical results as differential post-issuance trajectories rather than unwarranted causal claims, and explicitly highlighting small-sample caveats for the five-issuer refinancing subgroup.

The manuscript has not been published elsewhere and is not under consideration by any other journal. All co-authors have approved the submission. The complete replication package---containing curated data, econometric code, provenance metadata, and NLP audit scripts---is prepared for immediate open-access archiving upon acceptance.

We thank you and the editorial board for your time and consideration of our work, and we look forward to the reviewers' constructive feedback.

\vspace{1.5em}
\noindent Sincerely,

\vspace{1em}
\noindent
\textbf{Ram Soorat} \\
(On behalf of all co-authors) \\
Assistant Professor, School of Technology, Woxsen University \\
Email: \url{ram.soorat@woxsen.edu.in}

\end{document}
"""

with open(os.path.join(latex_dir, "04_JSFI_Cover_Letter.tex"), "w", encoding="utf-8") as f:
    f.write(cover_letter_tex)
print("Wrote 04_JSFI_Cover_Letter.tex")
