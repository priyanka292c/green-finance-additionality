import os
import re

latex_dir = os.path.abspath(r'09_JSFI_Submission\LaTeX_Source')

# 1. Update 04_JSFI_Cover_Letter.tex
cl_path = os.path.join(latex_dir, "04_JSFI_Cover_Letter.tex")
cover_letter_tex = r"""\documentclass[12pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage[margin=1in]{geometry}
\usepackage{setspace}
\onehalfspacing
\usepackage{hyperref}
\usepackage{enumitem}

\hypersetup{
    colorlinks=true,
    linkcolor=black,
    citecolor=black,
    urlcolor=blue!70!black
}

\begin{document}

\noindent
\textbf{Ram Soorat} \\
School of Technology, Woxsen University \\
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\
Email: \url{ram.soorat@woxsen.edu.in} \\
Telephone: +91 8455 305555 \\
ORCID: \url{https://orcid.org/0000-0001-7875-9197}

\vspace{1em}
\noindent 29 September 2026

\vspace{1em}
\noindent
\textbf{Professor [Editor-in-Chief / Editorial Board]} \\
Editor-in-Chief \\
\textit{Journal of Sustainable Finance \& Investment} \\
Taylor \& Francis Group

\vspace{1.2em}
\noindent
\textbf{SUBJECT: Submission of Original Research Manuscript}

\vspace{0.5em}
\noindent
\textbf{Manuscript Title:} \textit{Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing} \\
\textbf{Running Title:} \textit{Green-Bond Allocation and Emissions Trajectories}

\vspace{1em}
\noindent Dear Editor-in-Chief and Editorial Board Members,

\vspace{0.5em}
We submit our empirical manuscript, entitled \textbf{``Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing,''} for consideration for publication in the \textit{Journal of Sustainable Finance \& Investment} (JSF\&I).

\subsection*{Research Question and Alignment with JSF\&I Scope}
The paper investigates a central question in sustainable finance: \textit{Does the contractual allocation of green-bond proceeds between new green capital projects and refinancing of existing eligible assets affect the subsequent environmental and investment trajectories of issuing corporations?}

Existing empirical literature in sustainable finance has focused primarily on secondary-market pricing (the greenium) and aggregate ESG score responses, typically treating green-bond issuance as a binary intervention. In doing so, prior research pays limited attention to internal contractual proceeds deployment: whether proceeds fund new physical green capital expenditures or restructure liabilities on pre-existing operational assets.

\subsection*{Key Contributions}
Using a manually audited panel of 84 corporations (42 corporate environmental-use-of-proceeds bond issuers and 42 propensity-score-matched peers, 1,008 firm-years over 2013--2024), we examine this question using a Callaway and Sant'Anna (2021) staggered difference-in-differences design:
\begin{enumerate}[leftmargin=1.5em]
    \item \textbf{Instrument Design and Proceeds Allocation:} We show that post-issuance emissions trajectories vary with contractual proceeds allocation. In our continuous specification, each 10 percentage-point allocation to new capital projects is associated with an incremental $-1.59\%$ post-issuance emissions differential ($p < 0.001$).
    \item \textbf{New Projects vs. Refinancing:} Issuers allocating predominantly to new physical projects ($N = 31$) achieve an average post-issuance emissions reduction of $-6.31\%$ relative to matched controls (linear model extrapolation at 100\% allocation: $-8.77\%$). In contrast, an exploratory cohort of five refinancing-dominated issuers exhibits a relative post-issuance divergence of +3.88\% from matched controls, though inference for this subgroup is uncertain ($p = 0.7015$ under cluster randomization inference).
    \item \textbf{Capital Formation:} Green-debt issuance is associated with a 7.32 percentage-point expansion in green capital expenditure share, which remains positive at +6.60 percentage points under an accounting-adjusted diagnostic deducting focal-bond proceeds.
    \item \textbf{Commercial ESG Ratings:} Commercial ESG ratings increase similarly ($+0.90\sigma$ vs. $+0.91\sigma$; difference = $+0.0042\sigma, p = 0.927$; TOST equivalence $p = 0.0168$) across allocation types despite differences in physical emissions trajectories, documenting limited differentiation in rating adjustments.
\end{enumerate}

\subsection*{Methodological Framing}
Because treatment adoption is observational, our estimates are interpreted as differential post-issuance trajectories across allocation profiles rather than exogenous causal effects. We acknowledge that matching balances observed financial metrics but cannot eliminate unobserved characteristics such as managerial climate ambition or internal project pipelines.

The manuscript is original, has not been published elsewhere, and is not under consideration by any other journal. All co-authors have approved the submission.

Thank you for your consideration.

\vspace{1.5em}
\noindent Sincerely,

\vspace{1em}
\noindent
\textbf{Ram Soorat} \\
(On behalf of all co-authors) \\
Assistant Professor, School of Technology, Woxsen University \\
Email: \url{ram.soorat@woxsen.edu.in}

\end{document}
"""

with open(cl_path, "w", encoding="utf-8") as f:
    f.write(cover_letter_tex)
print(f"Updated {cl_path}")

# 2. Update 01_JSFI_Title_Page.tex Running title
tp_path = os.path.join(latex_dir, "01_JSFI_Title_Page.tex")
with open(tp_path, "r", encoding="utf-8") as f:
    tp_content = f.read()

tp_content = re.sub(
    r'\\textbf\{Running title:\}[^\n\\]+',
    r'\\textbf{Running title:} Green-Bond Allocation and Emissions Trajectories',
    tp_content
)
with open(tp_path, "w", encoding="utf-8") as f:
    f.write(tp_content)
print(f"Updated {tp_path}")

# 3. Update 02_JSFI_Anonymous_Manuscript.tex with Sample Selection Table and Cautious Language
m_path = os.path.join(latex_dir, "02_JSFI_Anonymous_Manuscript.tex")
with open(m_path, "r", encoding="utf-8") as f:
    m_content = f.read()

# Add Sample Selection Table in Section 4.1
sample_selection_table = r"""
\subsubsection{Sample Selection and Attrition Protocol}
\label{sec:sample_selection}
To ensure transparency regarding sample selection, Table~\ref{tab:sample_funnel} details the sequential audit protocol used to construct the analytical panel from the global universe of corporate sustainable debt.

\begin{table}[H]
\centering
\small
\begin{threeparttable}
\caption{\textbf{Corporate Sample Selection Funnel and Inclusion Protocol}}
\label{tab:sample_funnel}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lcc}
\toprule
\textbf{Sampling Step / Filter Description} & \textbf{Excluded} & \textbf{Retained} \\
\midrule
1. Global corporate labeled sustainable debt records (2013--2024; CBI / Bloomberg / Refinitiv) & --- & 1,482 \\
2. Restrict to non-financial corporate operating groups (exclude financial intermediaries and sovereigns) & 864 & 618 \\
3. Minimum institutional transaction tranche size $\ge$ USD 200 million equivalent & 241 & 377 \\
4. Availability of audited post-issuance use-of-proceeds / allocation report within 24 months & 186 & 191 \\
5. Continuous CDP operational Scope 1 and Scope 2 emissions reporting ($\ge$ 3 years pre-issuance) & 112 & 79 \\
6. Complete financial statement and balance-sheet covariates (Compustat / Bloomberg) & 23 & 56 \\
7. Staggered adoption cohort eligibility (first issuance year between 2014 and 2022) & 14 & 42 \\
\midrule
\textbf{Final Treated Corporate Issuers Panel} & --- & \textbf{42} \\
\textbf{1:1 Propensity-Score Matched Comparison Peers (Zero labeled debt 2013--2024)} & --- & \textbf{42} \\
\textbf{Total Balanced Analytical Panel (12 annual observations, 2013--2024)} & --- & \textbf{84 firms (1,008 obs)} \\
\bottomrule
\end{tabular*}
\begin{tablenotes}\footnotesize
\item \textit{Notes:} Step 4 requires public disclosure of project-level or category-level allocation between new green capital expenditure and debt refinancing. Step 5 enforces continuous CDP emissions reporting under the GHG Protocol to avoid survivorship bias and imputation artifacts. All 42 matched comparison firms were systematically audited to confirm zero identified labeled sustainable debt during 2013--2024.
\end{tablenotes}
\end{threeparttable}
\end{table}
"""

if r"\subsubsection{Sample Selection and Attrition Protocol}" not in m_content:
    m_content = m_content.replace(r"\subsection{Sample Construction}", r"\subsection{Sample Construction}" + '\n' + sample_selection_table)

# Rename Non-GB Green CapEx to Accounting-Adjusted Green CapEx Diagnostic in Section 4.3 and Table 4
m_content = m_content.replace("net non-bond green CapEx diagnostic", "accounting-adjusted net green CapEx diagnostic")
m_content = m_content.replace("Non-Green-Bond green CapEx", "accounting-adjusted net green CapEx")
m_content = m_content.replace("Non-GB CapEx", "Accounting-Adjusted Net CapEx")

with open(m_path, "w", encoding="utf-8") as f:
    f.write(m_content)
print(f"Updated {m_path}")
