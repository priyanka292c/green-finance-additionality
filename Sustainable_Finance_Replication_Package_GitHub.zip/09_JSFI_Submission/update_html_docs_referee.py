import os
import re

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')

# 1. Update 01_JSFI_Title_Page.html
with open(os.path.join(jsfi_dir, '01_JSFI_Title_Page.html'), 'r', encoding='utf-8') as f:
    tp_html = f.read()

tp_html = re.sub(r'<strong>Running title.*?</strong>[^\n<]+',
                 '<strong>Running title:</strong> Green-Bond Allocation and Emissions Trajectories',
                 tp_html)

with open(os.path.join(jsfi_dir, '01_JSFI_Title_Page.html'), 'w', encoding='utf-8') as f:
    f.write(tp_html)
print("Updated 01_JSFI_Title_Page.html")

# 2. Update 04_JSFI_Cover_Letter.html
cl_html = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Cover Letter — Journal of Sustainable Finance & Investment</title>
<style>
    @page { size: letter; margin: 1in; }
    body { font-family: 'Times New Roman', Times, serif; font-size: 12pt; line-height: 1.5; color: #111111; margin: 0; padding: 0; }
    h1 { font-size: 15pt; font-weight: bold; margin-top: 14pt; margin-bottom: 6pt; }
    h2 { font-size: 13pt; font-weight: bold; margin-top: 12pt; margin-bottom: 4pt; }
    p { margin-top: 0; margin-bottom: 6pt; text-align: justify; }
    ul, ol { margin-top: 0; margin-bottom: 8pt; padding-left: 20pt; }
    li { margin-bottom: 3pt; }
</style>
</head>
<body>

<p><strong>Ram Soorat</strong><br>
School of Technology, Woxsen University<br>
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India<br>
Email: ram.soorat@woxsen.edu.in | Telephone: +91 8455 305555 | ORCID: 0000-0001-7875-9197</p>

<p style="margin-top: 14pt;">29 September 2026</p>

<p><strong>Professor [Editor-in-Chief / Editorial Board]</strong><br>
Editor-in-Chief<br>
<em>Journal of Sustainable Finance & Investment</em><br>
Taylor & Francis Group</p>

<p style="margin-top: 14pt;"><strong>SUBJECT: Submission of Original Research Manuscript</strong></p>
<p><strong>Manuscript Title:</strong> <em>Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing</em><br>
<strong>Running Title:</strong> <em>Green-Bond Allocation and Emissions Trajectories</em></p>

<p>Dear Editor-in-Chief and Editorial Board Members,</p>

<p>We submit our empirical manuscript, entitled <strong>&ldquo;Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing,&rdquo;</strong> for consideration for publication in the <em>Journal of Sustainable Finance & Investment</em> (JSF&I).</p>

<h2>Research Question and Alignment with JSF&I Scope</h2>
<p>The paper investigates a central question in sustainable finance: <em>Does the contractual allocation of green-bond proceeds between new green capital projects and refinancing of existing eligible assets affect the subsequent environmental and investment trajectories of issuing corporations?</em></p>
<p>Existing empirical literature in sustainable finance has focused primarily on secondary-market pricing (the greenium) and aggregate ESG score responses, typically treating green-bond issuance as a binary intervention. In doing so, prior research pays limited attention to internal contractual proceeds deployment: whether proceeds fund new physical green capital expenditures or restructure liabilities on pre-existing operational assets.</p>

<h2>Key Contributions</h2>
<p>Using a manually audited panel of 84 corporations (42 corporate environmental-use-of-proceeds bond issuers and 42 propensity-score-matched peers, 1,008 firm-years over 2013&ndash;2024), we examine this question using a Callaway and Sant&rsquo;Anna (2021) staggered difference-in-differences design:</p>
<ol>
    <li><strong>Instrument Design and Proceeds Allocation:</strong> We show that post-issuance emissions trajectories vary with contractual proceeds allocation. In our continuous specification, each 10 percentage-point allocation to new capital projects is associated with an incremental &minus;1.59% post-issuance emissions differential (<em>p</em> &lt; 0.001).</li>
    <li><strong>New Projects vs. Refinancing:</strong> Issuers allocating predominantly to new physical projects (<em>N</em> = 31) achieve an average post-issuance emissions reduction of &minus;6.31% relative to matched controls (linear model extrapolation at 100% allocation: &minus;8.77%). In contrast, an exploratory cohort of five refinancing-dominated issuers exhibits a relative post-issuance divergence of +3.88% from matched controls, though inference for this subgroup is uncertain (<em>p</em> = 0.7015 under cluster randomization inference).</li>
    <li><strong>Capital Formation:</strong> Green-debt issuance is associated with a 7.32 percentage-point expansion in green capital expenditure share, which remains positive at +6.60 percentage points under an accounting-adjusted diagnostic deducting focal-bond proceeds.</li>
    <li><strong>Commercial ESG Ratings:</strong> Commercial ESG ratings increase similarly (+0.90&sigma; vs. +0.91&sigma;; difference = +0.0042&sigma;, <em>p</em> = 0.927; TOST equivalence <em>p</em> = 0.0168) across allocation types despite differences in physical emissions trajectories, documenting limited differentiation in rating adjustments.</li>
</ol>

<h2>Methodological Framing</h2>
<p>Because treatment adoption is observational, our estimates are interpreted as differential post-issuance trajectories across allocation profiles rather than exogenous causal effects. We acknowledge that matching balances observed financial metrics but cannot eliminate unobserved characteristics such as managerial climate ambition or internal project pipelines.</p>

<p>The manuscript is original, has not been published elsewhere, and is not under consideration by any other journal. All co-authors have approved the submission.</p>

<p>Thank you for your consideration.</p>

<p style="margin-top: 18pt;">Sincerely,</p>
<p><strong>Ram Soorat</strong><br>
(On behalf of all co-authors)<br>
Assistant Professor, School of Technology, Woxsen University<br>
Email: ram.soorat@woxsen.edu.in</p>

</body>
</html>
"""

with open(os.path.join(jsfi_dir, '04_JSFI_Cover_Letter.html'), 'w', encoding='utf-8') as f:
    f.write(cl_html)
print("Updated 04_JSFI_Cover_Letter.html")

# 3. Update 02_JSFI_Anonymous_Manuscript.html
with open(os.path.join(jsfi_dir, '02_JSFI_Anonymous_Manuscript.html'), 'r', encoding='utf-8') as f:
    m_html = f.read()

m_html = re.sub(r'<strong>Running title:</strong>[^\n<]+',
                '<strong>Running title:</strong> Green-Bond Allocation and Emissions Trajectories',
                m_html)

# Add Sample Selection Table
sample_funnel_html = """
<div style="margin: 18pt 0 14pt 0; page-break-inside: avoid;">
  <p class="table-caption"><strong>Table 2b: Corporate Sample Selection Funnel and Inclusion Protocol</strong></p>
  <table class="data-table" style="width: 100%; border-collapse: collapse; margin: 10pt 0 6pt 0; font-size: 9.5pt;">
    <thead>
      <tr style="border-top: 1.5pt solid #111111; border-bottom: 1pt solid #111111; background-color: #fcfcfc;">
        <th style="padding: 5pt 6pt; text-align: left; font-weight: bold;">Sampling Step / Filter Description</th>
        <th style="padding: 5pt 6pt; text-align: center; font-weight: bold;">Excluded</th>
        <th style="padding: 5pt 6pt; text-align: center; font-weight: bold;">Retained</th>
      </tr>
    </thead>
    <tbody>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">1. Global corporate labeled sustainable debt records (2013–2024; CBI / Bloomberg / Refinitiv)</td>
        <td style="padding: 5pt 6pt; text-align: center;">—</td>
        <td style="padding: 5pt 6pt; text-align: center;">1,482</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">2. Restrict to non-financial corporate operating groups (exclude financial intermediaries and sovereigns)</td>
        <td style="padding: 5pt 6pt; text-align: center;">864</td>
        <td style="padding: 5pt 6pt; text-align: center;">618</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">3. Minimum institutional transaction tranche size ≥ USD 200 million equivalent</td>
        <td style="padding: 5pt 6pt; text-align: center;">241</td>
        <td style="padding: 5pt 6pt; text-align: center;">377</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">4. Availability of audited post-issuance use-of-proceeds / allocation report within 24 months</td>
        <td style="padding: 5pt 6pt; text-align: center;">186</td>
        <td style="padding: 5pt 6pt; text-align: center;">191</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">5. Continuous CDP operational Scope 1 and Scope 2 emissions reporting (≥ 3 years pre-issuance)</td>
        <td style="padding: 5pt 6pt; text-align: center;">112</td>
        <td style="padding: 5pt 6pt; text-align: center;">79</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">6. Complete financial statement and balance-sheet covariates (Compustat / Bloomberg)</td>
        <td style="padding: 5pt 6pt; text-align: center;">23</td>
        <td style="padding: 5pt 6pt; text-align: center;">56</td>
      </tr>
      <tr style="border-bottom: 0.5pt solid #e0e0e0;">
        <td style="padding: 5pt 6pt;">7. Staggered adoption cohort eligibility (first issuance year between 2014 and 2022)</td>
        <td style="padding: 5pt 6pt; text-align: center;">14</td>
        <td style="padding: 5pt 6pt; text-align: center;">42</td>
      </tr>
      <tr style="border-top: 1pt solid #111111; border-bottom: 1.5pt solid #111111; font-weight: bold; background-color: #fafafa;">
        <td style="padding: 5pt 6pt;">Final Balanced Analytical Panel (42 treated + 42 matched controls; 12 years)</td>
        <td style="padding: 5pt 6pt; text-align: center;">—</td>
        <td style="padding: 5pt 6pt; text-align: center;">84 firms (1,008 obs)</td>
      </tr>
    </tbody>
  </table>
  <p class="table-notes"><em>Notes:</em> Step 4 requires public disclosure of project-level or category-level allocation between new green capital expenditure and debt refinancing. Step 5 enforces continuous CDP emissions reporting under the GHG Protocol to avoid survivorship bias and imputation artifacts. All 42 matched comparison firms were systematically audited to confirm zero identified labeled sustainable debt during 2013–2024.</p>
</div>
"""

if 'Table 2b: Corporate Sample Selection Funnel' not in m_html:
    m_html = m_html.replace('Table 2 presents the sample construction summary.', 'Table 2 presents the sample construction summary.\n' + sample_funnel_html)

# Synchronize Table 7 and text numbers
m_html = m_html.replace('Externally verified issuances (34 firms', 'Externally verified issuances (36 firms')
m_html = m_html.replace('higher-leverage issuers (leverage ≥ median, <em>N</em> = 20', 'higher-leverage issuers (leverage ≥ median, <em>N</em> = 22')
m_html = m_html.replace('net non-bond green CapEx diagnostic', 'accounting-adjusted net green CapEx diagnostic')

with open(os.path.join(jsfi_dir, '02_JSFI_Anonymous_Manuscript.html'), 'w', encoding='utf-8') as f:
    f.write(m_html)
print("Updated 02_JSFI_Anonymous_Manuscript.html")
