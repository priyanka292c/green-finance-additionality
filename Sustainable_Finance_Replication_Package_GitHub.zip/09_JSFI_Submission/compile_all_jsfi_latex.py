import os
import subprocess
import shutil

latex_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission\LaTeX_Source')
jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')
pdflatex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'
bibtex_bin = r'C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe'

docs = [
    ("01_JSFI_Title_Page", False),
    ("04_JSFI_Cover_Letter", False),
    ("02_JSFI_Anonymous_Manuscript", True),
    ("03_JSFI_Supplementary_Material", True)
]

for doc, needs_bib in docs:
    print(f"\n================ Compiling {doc} ================")
    subprocess.run([pdflatex_bin, "-interaction=nonstopmode", f"{doc}.tex"], cwd=latex_dir, capture_output=True)
    if needs_bib:
        subprocess.run([bibtex_bin, doc], cwd=latex_dir, capture_output=True)
        subprocess.run([pdflatex_bin, "-interaction=nonstopmode", f"{doc}.tex"], cwd=latex_dir, capture_output=True)
    subprocess.run([pdflatex_bin, "-interaction=nonstopmode", f"{doc}.tex"], cwd=latex_dir, capture_output=True)
    
    pdf_in_latex = os.path.join(latex_dir, f"{doc}.pdf")
    pdf_in_root = os.path.join(jsfi_dir, f"{doc}_LaTeX.pdf")
    if os.path.exists(pdf_in_latex) and os.path.getsize(pdf_in_latex) > 0:
        shutil.copy2(pdf_in_latex, pdf_in_root)
        print(f"[SUCCESS] {doc}.pdf generated ({os.path.getsize(pdf_in_latex):,} bytes)")
    else:
        print(f"[FAIL] {doc}.pdf was not generated or empty!")

print("\nAll LaTeX documents compiled successfully!")
