# 09_JSFI_Submission Directory Marker
This directory contains the complete submission package tailored specifically for the Journal of Sustainable Finance & Investment (JSF&I).
