# Supporting Information

## Green-Bond Proceeds Allocation and Environmental Outcomes: Evidence on New-Project Financing versus Refinancing

*Supporting Information for the Journal of Sustainable Finance & Investment*

*This document is intended for online publication as Supporting Information and should not be included in the main manuscript word count.*

---

## Table of Contents

- S1. Detailed Sample Construction and Matching Balance
- S2. Extended Variable Definitions and Data Sources
- S3. Full Econometric Specifications and Identification Assumptions
- S4. Event-Study Details, Event-Time Cohort Breakdown, and ATT Matrix
- S5. Additional Regression Tables and Annualization Sensitivity
- S6. Robustness Analyses, Threshold Sensitivity, and Equivalence Testing
- S7. NLP Allocation Classification Methodology and Confusion Matrix
- S8. Corporate Allocation Classification Protocol and Audited Examples
- S9. Extended ESG Provider Robustness
- S10. Additional Supporting Figures Description

---

## S1. Detailed Sample Construction and Matching Balance

### S1.1 Issuer Identification

Green-bond issuers were identified from the following primary sources: (i) Climate Bonds Initiative (CBI) Green Bond Database (2013–2024); (ii) Bloomberg Environmental, Social, and Governance (ESG) databases; (iii) Refinitiv Datastream labeled sustainable-debt fields; and (iv) manual review of SEC Form 8-K prospectus filings and European Regulated Market prospectus filings. Inclusion criteria required: (a) public corporate green bond issuance by a non-financial corporate operating group, including wholly owned captive vehicle-financing subsidiaries whose green-bond proceeds exclusively finance pro-environmental capital deployment within the consolidated operating group (with treatment evaluated at the consolidated parent operating group level), with major institutional bond issuance in North America (16 USA in baseline; 18 screened), Western Europe (21 issuers), Japan (2 issuers), or Brazil (1 issuer: Suzano S.A.; see Table S14b); (b) minimum issuance size of USD 200 million equivalent; (c) availability of a publicly filed post-issuance allocation or impact report within 24 months of issuance; and (d) continuous CDP emissions reporting for at least three years prior to first issuance.

**Instrument Qualification and Construct Validity:** What qualifies an instrument for inclusion in our treatment universe is the contractual commitment of debt proceeds to environmentally eligible physical capital under standard market frameworks (ICMA Green Bond Principles [GBP] or ICMA Sustainability Bond Guidelines [SBG]). Of the 42 treated corporate issuers, 38 issued securities officially designated as Green Bonds under ICMA GBP. Four issuers—Alphabet Inc. (2020), Amazon.com Inc. (2021), Salesforce Inc. (2021), and General Motors (2022)—issued instruments under Sustainability Bond or Sustainable Financing Frameworks whose eligible-use allocations contractually fund pro-environmental capital deployment (clean transportation, renewable energy PPAs, and certified green buildings). All 42 issuers are evaluated in the baseline panel (84 analytical corporate entities, 1,008 firm-years). To assess construct sensitivity against a strict instrument-label threshold, Sensitivity 3 (Table S11) re-estimates the econometric baseline after excluding Sustainability Bond issuers (*N* = 40 treated pairs, 80 firms, 960 firm-years), demonstrating that our empirical conclusions are robust to a strict GBP-only inclusion criterion (CS ATT = −0.0898, *p* = 0.003).

Forty-two issuers meeting all criteria were initially identified across eight GICS economic sectors with first issuance years spanning 2014–2022 (40 retained in the baseline pure Green Bond sample after excluding two Sustainability Bond issuers; see Table S14b). Observations from 2023–2024 serve as post-treatment observation years; no first issuances from 2023–2024 are included as treatment cohorts, preserving sufficient post-issuance observation windows.

### S1.2 Control Group Screening

For each treated issuer, the candidate control universe was defined as non-financial corporate operating groups within the same two-digit GICS sector that: (i) had no identified publicly disclosed labeled sustainable debt (green bonds, green loans, or sustainability-linked bonds) during 2013–2024, confirmed through Bloomberg, Refinitiv, SEC 10-K filings, and CBI records; (ii) reported CDP Scope 1+2 emissions continuously over 2013–2024; and (iii) were domiciled in the same geographic region (North America, Western Europe, or matched institutional markets; Table S14b).

Screening confirmed no identified labeled sustainable debt for all 40 matched controls (and 42 screened candidate pairs). Private bilateral green credit facilities may not be fully observable from public sources, which is acknowledged as an empirical boundary condition. Full documentation is in Table S5 of this Supporting Information and the replication archive.

### S1.3 Propensity-Score Matching Details

Propensity scores were estimated using a logistic regression of treatment status on three pre-issuance covariates: ln(Assets), leverage ratio, and baseline Scope 1+2 emissions intensity (ln[tCO₂e/$M]), measured at the pre-issuance fiscal year ($t = g-1$). Nearest-neighbor 1:1 matching without replacement was implemented with a 0.05 caliper on the propensity score, within two-digit GICS sectors (satisfied for 36/40 pairs, 90.0%). Four pairs required adjacent-sector fallback to prevent caliper violations. Table S8b presents an explicit robustness test excluding all four cross-sector pairs ($N = 36$ pairs, 72 firms, 864 firm-years), demonstrating identical empirical conclusions.

---

## S2. Extended Variable Definitions and Data Sources

### Table S1. Extended Variable Definitions

| Variable | Detailed Definition | Units | Source |
|---|---|---|---|
| Scope 1 Emissions | Direct GHG emissions from owned/controlled combustion sources | tCO₂e | CDP; verified sustainability reports |
| Scope 2 Emissions | Indirect GHG emissions from purchased electricity, steam, heat | tCO₂e | CDP; verified sustainability reports |
| Log_Emissions | ln(Scope 1 + Scope 2) | ln(tCO₂e) | Constructed |
| Carbon_Intensity | ln[(Scope 1+2) / Revenue] | ln(tCO₂e/$M) | Constructed |
| Green_CapEx (%) | ∑ Green project expenditures / Total CapEx × 100 | Percentage | Manual audit of allocation reports |
| Non-GB_CapEx (%) | max(0, Green_CapEx − [GB_Proceeds × New_Share / 4] / Total_CapEx × 100) | Percentage | Constructed accounting attribution metric |
| Annual_GB_CapEx | (GB Proceeds × AllocationNew) / 4 years (baseline schedule) | $M | Constructed |
| ESG_norm | (ESG_raw − μ_{provider,sector}) / σ_{provider,sector} | Std. deviations | MSCI; S&P Global Trucost; Refinitiv |
| GreenBond | 1 in all post-issuance firm-years ($D_{it}$) | Binary | CBI; SEC filings |
| AllocationNew | % of total proceeds earmarked for new capital projects | [0,1] | Manual audit of allocation reports |
| AllocationRefin | 1 − AllocationNew | [0,1] | Constructed |
| SPO_Verified | 1 = independent SPO from Sustainalytics, CICERO, DNV, ISS ESG, or CBI | Binary | CBI; SPO report archive |
| Leverage | Long-term debt / total book assets | Ratio | Audited balance sheets |
| ln(Assets) | ln(total book assets, $M) | ln($M) | Audited balance sheets |
| ROA | Net income / total book assets | Ratio | Audited income statements |
| Tobin's Q | (Market cap + book liabilities) / book assets | Ratio | Bloomberg; Refinitiv |
| Sector × Year | Two-digit GICS sector fixed effect × calendar year | FE | GICS classification |

> **Green CapEx construction note:** Where issuer disclosures did not separately identify accounting CapEx by environmental category, eligible-project expenditures were mapped to the corresponding capital-investment categories using the disclosed allocation documentation. The resulting measure should therefore be interpreted as a disclosure-based green-capital-expenditure measure rather than a universally audited accounting line item.


### Table S2. Comprehensive Pre-Treatment Covariate Balance

| Covariate | Unmatched: Treated | Unmatched: Control | Matched: Treated | Matched: Control | Unmatched SMD (%) | Matched SMD (%) |
|---|---|---|---|---|---|---|
| ln(Assets, $M) | 8.42 | 7.15 | 8.38 | 8.35 | 58.2% | 1.4% |
| ROA | 0.068 | 0.062 | 0.068 | 0.067 | 9.8% | 1.6% |
| Leverage Ratio | 0.342 | 0.315 | 0.341 | 0.339 | 14.5% | 1.1% |
| Tobin's Q | 1.84 | 1.76 | 1.83 | 1.82 | 10.2% | 1.3% |
| Baseline Emissions Intensity [ln(tCO₂e/$M)] | 4.85 | 4.22 | 4.77 | 4.75 | 38.4% | 1.2% |
| Baseline Green CapEx (%) | 5.12% | 4.95% | 5.10% | 5.08% | 4.2% | 0.5% |
| Pre-Issuance ESG Score | 54.2 | 52.8 | 54.1 | 53.9 | 8.9% | 1.3% |

*Notes:* Matching covariates measured at $t = g-1$ for each treated issuer and the identical calendar year for the matched control. Standardized Mean Difference (SMD) < 10% indicates excellent balance (Austin, 2011). Sector-constrained 1:1 nearest-neighbor matching, 0.05 caliper. 38/42 pairs within identical two-digit GICS sectors; 4 pairs in adjacent sectors.

---

## S3. Full Econometric Specifications and Identification Assumptions

### S3.1 Callaway–Sant’Anna Estimator: Mathematical Derivation

Under the conditional parallel trends assumption with respect to never-treated units:

$$\begin{aligned}
\mathbb{E}[Y_t(\infty) - Y_{t-1}(\infty) \mid \mathbf{X}, G_g = 1] &= \mathbb{E}[Y_t(\infty) - Y_{t-1}(\infty) \mid \mathbf{X}, G_\infty = 1]
\end{aligned}$$

and the no-anticipation assumption ($Y_{it}(0) = Y_{it}$ for all $t < g$), the group-time ATT is non-parametrically identified via doubly robust scoring:

$$\begin{aligned}
\text{ATT}(g, t) &= \mathbb{E}\left[\left(\frac{G_g}{\mathbb{E}[G_g]} - \frac{\frac{p_g(\mathbf{X})}{1-p_g(\mathbf{X})}G_\infty}{\mathbb{E}\left[\frac{p_g(\mathbf{X})}{1-p_g(\mathbf{X})}G_\infty\right]}\right) \times (Y_t - Y_{g-1} - m_{g,t}(\mathbf{X}))\right]
\end{aligned}$$

where $p_g(\mathbf{X}) = P(G_g = 1 \mid \mathbf{X}, G_g + G_\infty = 1)$ is the generalized propensity score for cohort $g$, and $m_{g,t}(\mathbf{X}) = \mathbb{E}[Y_t - Y_{g-1} \mid \mathbf{X}, G_\infty = 1]$ is the counterfactual outcome regression.

Event-time aggregation across cohorts:

$$\begin{aligned}
\text{ATT}(e) &= \sum_g w_g(e) \cdot \text{ATT}(g, g+e), \\
\text{where } w_g(e) &= \frac{P(G = g \mid G + e \leq T)}{\sum_{g'} P(G = g' \mid G' + e \leq T)}
\end{aligned}$$

Overall ATT: $\widehat{\text{ATT}} = \sum_{e \geq 0} w(e) \cdot \text{ATT}(e)$.

### S3.2 Parallel Trends Formal Pre-Testing

Pre-treatment lead coefficients ($\tau \in [-5, -2]$) are individually and jointly statistically indistinguishable from zero:

| Event Time τ | β̂ | SE | *t* | *p* |
|---|---|---|---|---|
| −5 | −0.0080 | 0.0220 | −0.36 | 0.716 |
| −4 | +0.0050 | 0.0210 | +0.24 | 0.812 |
| −3 | −0.0030 | 0.0190 | −0.16 | 0.875 |
| −2 | +0.0020 | 0.0180 | +0.11 | 0.912 |
| **Joint Wald** | | | ***F* = 0.285** | ***p* = 0.887** |

Failure to reject differential pre-trends provides empirical support consistent with parallel trends, though it does not guarantee the assumption holds in the post-treatment period (Roth, 2022; Rambachan & Roth, 2023).

### S3.3 TWFE Negative-Weighting Decomposition

Under the Goodman-Bacon (2021) decomposition:

$$\begin{aligned}
\hat{\beta}^{\text{TWFE}} &= \sum_{k \neq U} s_{kU}\hat{\beta}_{kU} \\
&\quad + \sum_k \sum_{l > k} [s_{kl}^{\text{early}}\hat{\beta}_{kl}^{\text{early}} + s_{kl}^{\text{late}}\hat{\beta}_{kl}^{\text{late}}]
\end{aligned}$$

Because treatment effects grow dynamically ($\partial|\text{ATT}|/\partial e > 0$), comparisons where early-treated units serve as controls for late-treated units assign negative weights to expanding treatment trajectories, biasing $\hat{\beta}^{\text{TWFE}}$ toward zero. Observed attenuation in this setting: CS ATT = −0.0934 vs. TWFE = −0.0470 (approximate 50% attenuation). Note: Both log Scope 1+2 emissions ($\beta = -0.047008, \text{SE} = 0.006846$) and carbon intensity ($\beta = -0.047047, \text{SE} = 0.006848$) round to −0.0470 at four decimal places despite being estimated from distinct regressions.

---

## S4. Event-Study Details, Event-Time Cohort Breakdown, and ATT Matrix

### Table S3. Full Event-Study Parameter Estimates (Log Scope 1+2 Emissions)

| Event Time τ | β̂ | SE | *t* | *p* | Implied %Δ |
|---|---|---|---|---|---|
| −5 | −0.0080 | 0.0220 | −0.36 | 0.716 | −0.80% |
| −4 | +0.0050 | 0.0210 | +0.24 | 0.812 | +0.50% |
| −3 | −0.0030 | 0.0190 | −0.16 | 0.875 | −0.30% |
| −2 | +0.0020 | 0.0180 | +0.11 | 0.912 | +0.20% |
| −1 | 0 (reference) | — | — | — | — |
| 0 | −0.0420 | 0.0241 | −1.74 | 0.082 | −4.11% |
| +1 | −0.0980 | 0.0275 | −3.56 | <0.001 | −9.33% |
| +2 | −0.1550 | 0.0298 | −5.20 | <0.001 | −14.36% |
| +3 | −0.1880 | 0.0315 | −5.97 | <0.001 | −17.14% |
| +4 | −0.2050 | 0.0332 | −6.17 | <0.001 | −18.53% |
| +5 | −0.2140 | 0.0351 | −6.10 | <0.001 | −19.26% |

*Notes:* Estimated using Callaway–Sant’Anna (2021) with $\tau = -1$ as reference period. %Δ computed as $100 \times [\exp(\hat{\beta}) - 1]$. Standard errors clustered at firm level ($N = 84$).

### Table S3b. Event-Time Sample Composition and Cohort Attrition ($\tau \in [-5, +5]$)

| Event Time $\tau$ | Included Issuance Cohorts ($g$) | Treated Issuers ($N_{\text{tr}}$) | Matched Controls ($N_{\text{co}}$) | Total Firms ($N$) | Cohorts Dropped / Not Reached |
|---|---|---|---|---|---|
| −5 | 2018, 2019, 2020, 2021, 2022 | 33 | 42 | 75 | 2014, 2015, 2016, 2017 (pre-2013 truncated) |
| −4 | 2017, 2018, 2019, 2020, 2021, 2022 | 36 | 42 | 78 | 2014, 2015, 2016 |
| −3 | 2016, 2017, 2018, 2019, 2020, 2021, 2022 | 38 | 42 | 80 | 2014, 2015 |
| −2 | 2016, 2017, 2018, 2019, 2020, 2021, 2022 | 38 | 42 | 80 | 2014, 2015 |
| −1 (ref) | All cohorts (2014–2022) | 42 | 42 | 84 | None (Full Panel) |
| 0 | All cohorts (2014–2022) | 42 | 42 | 84 | None (Full Panel) |
| +1 | All cohorts (2014–2022) | 42 | 42 | 84 | None (Full Panel) |
| +2 | All cohorts (2014–2022) | 42 | 42 | 84 | None (Full Panel) |
| +3 | 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021 | 40 | 42 | 82 | 2022 cohort (reached only $\tau = +2$ by 2024) |
| +4 | 2014, 2015, 2016, 2017, 2018, 2019, 2020 | 33 | 42 | 75 | 2021, 2022 cohorts |
| +5 | 2014, 2015, 2016, 2017, 2018, 2019 | 24 | 42 | 66 | 2020, 2021, 2022 cohorts |

*Notes:* Panel spans 2013–2024 (12 calendar years). Because cohort adoption occurs staggered over 2014–2022, later cohorts have not reached higher event times by the end of the panel: the 2020 cohort ($N=9$) reaches $\tau=+4$ in 2024, the 2021 cohort ($N=7$) reaches $\tau=+3$, and the 2022 cohort ($N=2$) reaches $\tau=+2$. Consequently, $\tau=+5$ reflects the 24 treated corporations issued between 2014 and 2019. Controls remain in the comparison set across all event times.

### Table S4. Callaway–Sant’Anna Group-Time ATT Matrix (Selected Entries)

| Cohort *g* | Calendar Year *t* | ATT(*g*,*t*) | SE | *p* | Pre/Post |
|---|---|---|---|---|---|
| 2014 | 2013 | −0.0060 | 0.0180 | 0.740 | Pre |
| 2014 | 2014 | −0.0380 | 0.0210 | 0.070 | Post |
| 2014 | 2016 | −0.0940 | 0.0260 | <0.001 | Post |
| 2014 | 2019 | −0.1750 | 0.0310 | <0.001 | Post |
| 2018 | 2017 | +0.0040 | 0.0220 | 0.857 | Pre |
| 2018 | 2018 | −0.0410 | 0.0250 | 0.101 | Post |
| 2018 | 2021 | −0.1620 | 0.0330 | <0.001 | Post |
| 2020 | 2019 | −0.0020 | 0.0200 | 0.920 | Pre |
| 2020 | 2020 | −0.0390 | 0.0240 | 0.104 | Post |
| 2020 | 2023 | −0.1470 | 0.0340 | <0.001 | Post |

*Notes:* Pre-treatment estimates cluster near zero across all cohorts. The estimates display an increasingly negative trajectory over the observed post-treatment horizons, motivating the use of the Callaway–Sant’Anna estimator, which accommodates treatment-effect heterogeneity more appropriately than static TWFE.

---

## S5. Additional Regression Tables and Annualization Sensitivity

### Table S5. Green CapEx Annualization Sensitivity (Non-GB Green CapEx)

| Annualization Window | CS ATT (pp) | SE | *t* | *p* | TWFE (pp) | SE | *p* |
|---|---|---|---|---|---|---|---|
| 1-year window | +6.24 | 0.6130 | 10.17 | <0.001 | +1.88 | 0.4513 | <0.001 |
| 2-year window | +6.38 | 0.6125 | 10.42 | <0.001 | +2.28 | 0.4301 | <0.001 |
| 3-year window | +6.50 | 0.6122 | 10.62 | <0.001 | +2.61 | 0.4198 | <0.001 |
| 4-year window (baseline) | +6.60 | 0.6120 | 10.78 | <0.001 | +2.96 | 0.5011 | <0.001 |
| 5-year window | +6.70 | 0.6135 | 10.92 | <0.001 | +3.28 | 0.3967 | <0.001 |

*Notes:* All specifications $p < 0.001$. Non-GB CapEx = Green_CapEx − (GB_Proceeds × AllocationNew / Years) / Total_CapEx × 100. Shorter windows deduct proceeds more aggressively in early post-issuance years; results are robust across all horizons.

### Table S6. Control Group Screening — Confirmed Never-Treated Status

All 42 matched comparison firms were systematically screened across Bloomberg, Refinitiv, SEC Form 10-K filings, and CBI records to confirm no publicly identified labeled sustainable debt during 2013–2024. Results: 42/42 firms confirmed as never-treated (0 green bonds, 0 sustainability-linked bonds, 0 publicly identified green loans). Full firm-level documentation available in `empirical_panel_provenance.csv`.

---

## S6. Robustness Analyses, Threshold Sensitivity, and Equivalence Testing

### Table S7. Allocation Threshold Sensitivity (Categorical Results)

| Threshold | New-Project β̂ | SE | *p* | Refinancing β̂ | SE | *p* | Refinancing *N* |
|---|---|---|---|---|---|---|---|
| ≥50% new | −0.0588 | 0.0071 | <0.001 | +0.0341 | 0.0091 | <0.001 | 8 firms |
| ≥60% new | −0.0620 | 0.0073 | <0.001 | +0.0362 | 0.0089 | <0.001 | 6 firms |
| **≥70% new (baseline)** | **−0.0651** | **0.0076** | **<0.001** | **+0.0380** | **0.0088** | **<0.001** | **5 firms** |
| ≥80% new | −0.0671 | 0.0081 | <0.001 | +0.0401 | 0.0094 | <0.001 | 5 firms |
| ≥90% new | −0.0688 | 0.0085 | <0.001 | No firms | — | — | 0 firms |

*Notes:* Baseline uses the 70% threshold. At the 90% threshold, no refinancing issuers meet the classification criterion. New-project coefficients remain negative and statistically significant across all thresholds.

### Table S8. Additional Robustness: Winsorization and Outlier Sensitivity

| Specification | β̂ | SE | *p* | Notes |
|---|---|---|---|---|
| Baseline (no winsor) | −0.0470 | 0.0068 | <0.001 | Main TWFE |
| Winsorized (1st–99th) | −0.0858 | 0.0073 | <0.001 | Sensitivity to extreme emissions values |
| Winsorized (5th–95th) | −0.0712 | 0.0076 | <0.001 | More aggressive winsorization |
| Leave-one-out: mean | −0.0470 | 0.0007 | <0.001 | SD of 84 Jackknife iterations |
| Leave-one-out: min | −0.0444 | — | — | Lowest estimate (84 iterations) |
| Leave-one-out: max | −0.0495 | — | — | Highest estimate (84 iterations) |

### Table S10. Exact Robustness: Exclusion of Cross-Sector Matched Pairs

| Estimator / Specification | Full Sample ($N=42$ pairs, 84 firms, 1,008 obs) | Strictly Within-Sector Pairs ($N=38$ pairs, 76 firms, 912 obs) | Difference | Notes |
|---|---|---|---|---|
| **Callaway–Sant’Anna ATT** | **−0.0898** (SE: 0.0105, $p < 0.001$) | **−0.0928** (SE: 0.0117, $p < 0.001$) | +0.0006 | Implied: −8.86% (vs. −8.59% full sample) |
| **Two-Way Fixed Effects $\hat{\beta}$** | **−0.0470** (SE: 0.0068, $p < 0.001$) | **−0.0459** (SE: 0.0074, $p < 0.001$) | +0.0011 | Implied: −4.48% (vs. −4.59% full sample) |

*Notes:* Re-estimation excludes the four matched pairs where caliper constraints required nearest-neighbor matching in an adjacent GICS sector. Both the Callaway–Sant’Anna ATT and the static TWFE coefficient remain virtually identical, confirming that the main empirical findings are not sensitive to cross-sector matches.

### Table S11. Refinancing Cohort Stability: Leave-One-Out Jackknife Analysis ($N=5$)

| Iteration: Omitted Refinancing Issuer | Post-Issuance Emissions $\hat{\beta}$ | Implied %Δ | SE | *t*-stat | *p*-value |
|---|---|---|---|---|---|
| Full Refinancing Cohort ($N=5$) | +0.0380 | +3.88% | 0.0088 | +4.312 | <0.001 |
| Omit Duke Energy Carolinas LLC | +0.0371 | +3.78% | 0.0091 | +4.077 | <0.001 |
| Omit The Southern Company | +0.0366 | +3.73% | 0.0093 | +3.935 | <0.001 |
| Omit Boston Properties LP | +0.0447 | +4.57% | 0.0089 | +5.022 | <0.001 |
| Omit Unibail-Rodamco-Westfield SE | +0.0402 | +4.10% | 0.0090 | +4.467 | <0.001 |
| Omit Toyota Motor Credit Corp. | +0.0399 | +4.07% | 0.0092 | +4.337 | <0.001 |
| **Summary Statistics across 5 iterations** | **Range: +0.0366 to +0.0447 (Implied: +3.73% to +4.57%)** | | **Median: +0.0399** | **All $p < 0.001$** | |

*Notes:* Jackknife re-estimation iteratively drops each of the 5 refinancing-dominated issuers from the categorical specification (Table 5, Panel B). All leave-one-out Jackknife estimates remain positive (+3.73% to +4.57%), providing sensitivity evidence that the observed subgroup pattern is not attributable to a single issuer. Given the five-issuer sample, this is interpreted as exploratory heterogeneity evidence rather than a standalone causal estimate.

### Table S11b. Re-Matched Multi-Jurisdiction and Captive-Finance Sensitivity Analyses

| Specification | Treated (*N*) | Comparison Pool | Firms (*N*) | Obs (*N*) | CS-DiD ATT (SE) | CS Implied Effect | TWFE β (SE) | TWFE Implied Effect |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Baseline Multi-Jurisdiction Model** | 42 | Matched Never-Treated (1:1) | 84 | 1,008 | −0.0934*** (0.0110) | **−8.91%** | −0.0470*** (0.0068) | **−4.59%** |
| **Sensitivity 1A: Geographic Scope Exclusion (Matched Pairs)** | 39 | Matched Controls (1:1) | 78 | 936 | -0.0982*** (0.0108) | **-9.36%** | -0.0436*** (0.0068) | **-4.27%** |
| **Sensitivity 1B: Geographic Scope Exclusion (Full Controls)** | 39 | All Never-Treated Controls | 81 | 972 | -0.0984*** (0.0109) | **-9.37%** | -0.0439*** (0.0069) | **-4.3%** |
| **Sensitivity 2A: Captive Auto-Finance Exclusion (Matched Pairs)** | 40 | Matched Controls (1:1) | 80 | 960 | -0.0988*** (0.0109) | **-9.4%** | -0.0456*** (0.0065) | **-4.45%** |
| **Sensitivity 2B: Captive Auto-Finance Exclusion (Full Controls)** | 40 | All Never-Treated Controls | 82 | 984 | -0.0986*** (0.0109) | **-9.39%** | -0.0457*** (0.0065) | **-4.47%** |
| **Sensitivity 3A: Dual-Framework SBG Exclusion (Amazon & Salesforce)** | 40 | Matched Controls (1:1) | 80 | 960 | −0.0942*** (0.0113) | **−8.99%** | −0.0465*** (0.0068) | **−4.54%** |
| **Sensitivity 3B: Strict GBP Designation (Excl. 4 Sustainability Frameworks)** | 38 | Matched Controls (1:1) | 76 | 912 | −0.0937*** (0.0116) | **−8.94%** | −0.0461*** (0.0070) | **−4.51%** |

*Notes:* *** *p* < 0.001. Clustered standard errors at the firm level in parentheses. Implied %Δ = 100 × [exp(ATT) − 1]. Sensitivity 1 excludes non-North American and non-Western European issuers (Toyota Motor Credit Corporation, Honda Motor Co., and Suzano S.A.; *N* = 39 treated). Sensitivity 2 excludes captive vehicle-financing entities (Toyota Motor Credit Corporation and Ford Motor Credit Company LLC; *N* = 40 treated). Sensitivity 3 evaluates construct sensitivity: Spec 3A excludes the two dual-framework Sustainability Bond issuers with mixed social/green categories (Amazon.com Inc. and Salesforce Inc.; *N* = 40 pairs, 80 firms, 960 firm-years); Spec 3B adopts a strict title-page ICMA Green Bond definition by further excluding Alphabet Inc. and General Motors whose frameworks permit social expenditures even though 100% of allocated proceeds were dedicated to pro-environmental capital (*N* = 38 pairs, 76 firms, 912 firm-years). In each sensitivity, the complete 1:1 propensity-score matching and estimation pipeline is fully re-estimated with dynamic re-matching from the candidate control universe. Specifications 1B and 2B compare treated firms to the entire unconstrained never-treated control pool. Results demonstrate that empirical decarbonization is driven by contractual environmental capital allocation rather than instrument labeling.

### S6.2 ESG Equivalence Interval Diagnostic

To assess whether the empirical difference in commercial ESG rating upgrades between new-project and refinancing issuers reflects practically limited differentiation, we evaluate the difference against an equivalence interval benchmark. The estimated post-issuance ESG upgrade is $+0.9011\sigma$ for new-project issuers and $+0.9053\sigma$ for refinancing issuers. The empirical difference is $\Delta = +0.0042\sigma$ (SE = $0.0451\sigma$, $p = 0.9265$). The exact 95% confidence interval for the difference is:

$$\text{95\% CI} = [+0.0042 - 1.96 \times 0.0451, \, +0.0042 + 1.96 \times 0.0451] = [-0.0842\sigma, \, +0.0926\sigma]$$

Using $\pm0.10\sigma$ as an explicitly stated practical equivalence benchmark, this confidence interval falls entirely within that range (and well within $\pm 0.15\sigma$). Furthermore, a formal two one-sided test (TOST) procedure confirms equivalence within the $\pm0.10\sigma$ bound ($t_1 = 2.31, t_2 = 2.12, p_{\text{TOST}} = 0.0168 < 0.05$), rejecting the null hypothesis of non-equivalence at the 5% level.

**Substantive Justification of the Equivalence Margin:** The choice of $\pm0.10\sigma$ as our practical equivalence margin is grounded in psychometric and empirical conventions. Under Cohen's (1988) standard effect size taxonomy, standardized mean differences $|d| < 0.20$ are classified as negligible ('trivial'). Our $\pm0.10\sigma$ threshold establishes an even more conservative boundary (half of the small-effect benchmark). In corporate sustainability research, Berg et al. (2022) document that commercial ESG rating disagreement across major providers spans $0.30\sigma$ to $0.60\sigma$ on average; thus, a difference of $0.0042\sigma$ (or any effect within $\pm0.10\sigma$) represents negligible economic or operational differentiation that is dwarfed by baseline measurement noise.
 This provides evidence consistent with practically limited differentiation by commercial ESG rating agencies across green-bond proceeds allocation types, in contrast to their divergent physical environmental trajectories.

---

## S7. NLP Allocation Classification Methodology and Confusion Matrix

### S7.1 Human Inter-Rater Reliability vs. Machine Learning Cross-Validation

To ensure methodological clarity, we distinguish two analytically distinct evaluation steps:
1. **Human Inter-Rater Reliability (Gold-Standard Annotation):** Two independent sustainability specialists reviewed a randomly sampled subset of 30 corporate disclosure documents under double-blind conditions. The observed agreement was $P_o = 93.33\%$ (28/30 documents), with chance agreement $P_e = 44.44\%$, yielding a Cohen's inter-rater reliability of $\kappa = 0.880$. Discrepancies were adjudicated by reference to audited allocation tables.
2. **Automated Machine Learning Classifier (5-Fold Cross-Validation):** The calibrated TF-IDF regularized logistic regression model was evaluated across the full 120-document corpus (68 issuers) using stratified 5-fold cross-validation at the issuer level (ensuring zero document leakage across folds). Across the five folds, mean out-of-fold accuracy was **82.5%** ($(44 + 32 + 23) / 120$), with a classifier Cohen's $\kappa = \mathbf{0.730}$, a Macro F1 of **0.813**, and a Weighted F1 of **0.824** (the pooled out-of-fold confusion matrix in Table S12 yields macro-F1 = 0.814 and weighted-F1 = 0.827).

### Table S12. Pooled Out-of-Fold Classification Performance ($3 \times 3$ Confusion Matrix)

#### Panel A: Confusion Matrix ($N = 120$ Documents across 5 Folds)

| True Category \ Predicted Category | Predicted: New Projects | Predicted: Refinancing | Predicted: Mixed Allocation | Total Actual Documents |
|---|---|---|---|---|
| **True: New Projects** | **44** | 2 | 4 | 50 |
| **True: Refinancing** | 3 | **32** | 7 | 42 |
| **True: Mixed Allocation** | 2 | 3 | **23** | 28 |
| **Total Predicted Documents** | 49 | 37 | 34 | 120 |

#### Panel B: Classification Performance by Category

| Category | Precision | Recall | F1-Score | Document Support |
|---|---|---|---|---|
| New Capital Projects | 0.898 (44/49) | 0.880 (44/50) | 0.889 | 50 |
| Debt Refinancing | 0.865 (32/37) | 0.762 (32/42) | 0.810 | 42 |
| Mixed Allocation | 0.676 (23/34) | 0.821 (23/28) | 0.742 | 28 |
| **Macro Average** | **0.813** | **0.821** | **0.814** | **120** |
| **Weighted Average** | **0.835** | **0.825** | **0.827** | **120** |
| **Overall Accuracy** | **82.5% (99/120)** | | | |
| **Classifier Cohen's κ** | **0.730** | | | |
| **Human Inter-Rater κ (30 docs)** | **0.880** | | | |

*Notes:* Issuer-level stratified 5-fold cross-validation. Regularized logistic regression (L2, C = 1.0) with TF-IDF features (unigrams + bigrams, max 5,000 features).

---

## S8. Corporate Allocation Classification Protocol and Audited Examples

### S8.1 Four-Step Green CapEx Coding Protocol

1. **Source Hierarchy:** Primary: post-issuance Green Bond Allocation Reports with independent auditor assurance. Secondary: SEC Form 10-K/8-K footnote disclosures of environmental capital projects. Tertiary: CDP Climate Change Questionnaire C7/C8 disclosures.
2. **Eligibility Classification:** Projects classified as eligible green CapEx if meeting ICMA Green Bond Principles eligibility criteria: renewable energy generation/transmission, energy-efficiency retrofits, clean transportation, green buildings (LEED Platinum / BREEAM Excellent), and industrial electrification.
3. **Vintage Determination:** Projects coded as New Eligible Capital (AllocationNew) only if committed to greenfield construction or equipment acquisition within 12 months preceding bond pricing. Projects commissioned more than 12 months before pricing are coded as Refinancing (AllocationRefin).
4. **Inter-Coder Validation:** Independent double-coding by research associates yielded 94.2% raw agreement, with discrepancies resolved through transaction contracts and auditor verification letters.

### Table S14. Complete 42-Issuer Proceeds Allocation Dataset, Rules, and Treatment Assignments

| Issuer Name | Ticker | Country | First Issuance | New Projects % | Refinancing % | Classification Criteria | Assigned Category | External SPO Review |
|---|---|---|---|---|---|---|---|---|
| E.ON SE | EOAN.DE | Germany | 2019 | 35.0% | 65.0% | 30% < New < 70% | **Mixed** | Yes |
| PepsiCo Inc. | PEP | USA | 2019 | 65.0% | 35.0% | 30% < New < 70% | **Mixed** | Yes |
| Telefonica S.A. | TEF.MC | Spain | 2019 | 65.0% | 35.0% | 30% < New < 70% | **Mixed** | Yes |
| Vodafone Group | VOD.L | UK | 2019 | 68.0% | 32.0% | 30% < New < 70% | **Mixed** | Yes |
| AvalonBay Communities | AVB | USA | 2021 | 65.0% | 35.0% | 30% < New < 70% | **Mixed** | Yes |
| Vonovia SE | VNA.DE | Germany | 2021 | 40.0% | 60.0% | 30% < New < 70% | **Mixed** | Yes |
| Engie S.A. | ENGI.PA | France | 2014 | 85.0% | 15.0% | ≥ 70% New | **New Projects** | Yes |
| Iberdrola S.A. | IBE.MC | Spain | 2014 | 95.0% | 5.0% | ≥ 70% New | **New Projects** | Yes |
| Apple Inc. | AAPL | USA | 2016 | 82.0% | 18.0% | ≥ 70% New | **New Projects** | Yes |
| Enel S.p.A. | ENEL.MI | Italy | 2017 | 90.0% | 10.0% | ≥ 70% New | **New Projects** | Yes |
| Orsted A/S | ORSTED.CO | Denmark | 2017 | 98.0% | 2.0% | ≥ 70% New | **New Projects** | Yes |
| SSE plc | SSE.L | UK | 2017 | 90.0% | 10.0% | ≥ 70% New | **New Projects** | Yes |
| EDP - Energias de Portugal | EDP.LS | Portugal | 2018 | 88.0% | 12.0% | ≥ 70% New | **New Projects** | Yes |
| Prologis Inc. | PLD | USA | 2018 | 75.0% | 25.0% | ≥ 70% New | **New Projects** | Yes |
| Schneider Electric | SU.PA | France | 2018 | 80.0% | 20.0% | ≥ 70% New | **New Projects** | Yes |
| Terna S.p.A. | TRN.MI | Italy | 2018 | 80.0% | 20.0% | ≥ 70% New | **New Projects** | Yes |
| Digital Realty Trust | DLR | USA | 2019 | 70.0% | 30.0% | ≥ 70% New | **New Projects** | Yes |
| NextEra Energy Capital | NEE | USA | 2019 | 90.0% | 10.0% | ≥ 70% New | **New Projects** | Yes |
| Red Electrica Corp. | RED.MC | Spain | 2019 | 85.0% | 15.0% | ≥ 70% New | **New Projects** | Yes |
| Stora Enso Oyj | STERV.HE | Finland | 2019 | 85.0% | 15.0% | ≥ 70% New | **New Projects** | Yes |
| Verizon Communications | VZ | USA | 2019 | 85.0% | 15.0% | ≥ 70% New | **New Projects** | Yes |
| Alphabet Inc. | GOOGL | USA | 2020 | 78.0% | 22.0% | ≥ 70% New | **New Projects** | Yes |
| Coca-Cola Europacific | CCEP | UK | 2020 | 70.0% | 30.0% | ≥ 70% New | **New Projects** | Yes |
| Daimler AG / Mercedes-Benz | MBG.DE | Germany | 2020 | 80.0% | 20.0% | ≥ 70% New | **New Projects** | Yes |
| Equinix Inc. | EQIX | USA | 2020 | 84.0% | 16.0% | ≥ 70% New | **New Projects** | Yes |
| National Grid plc | NG.L | UK | 2020 | 75.0% | 25.0% | ≥ 70% New | **New Projects** | Yes |
| Orange S.A. | ORA.PA | France | 2020 | 70.0% | 30.0% | ≥ 70% New | **New Projects** | Yes |
| Siemens AG | SIE.DE | Germany | 2020 | 75.0% | 25.0% | ≥ 70% New | **New Projects** | Yes |
| Suzano S.A. | SUZB3.SA | Brazil | 2020 | 75.0% | 25.0% | ≥ 70% New | **New Projects** | Yes |
| Volkswagen AG | VOW3.DE | Germany | 2020 | 85.0% | 15.0% | ≥ 70% New | **New Projects** | Yes |
| Amazon.com Inc. | AMZN | USA | 2021 | 72.0% | 28.0% | ≥ 70% New | **New Projects** | Yes |
| Dominion Energy | D | USA | 2021 | 80.0% | 20.0% | ≥ 70% New | **New Projects** | Yes |
| Ford Motor Credit | F | USA | 2021 | 82.0% | 18.0% | ≥ 70% New | **New Projects** | Yes |
| Microsoft Corp. | MSFT | USA | 2021 | 80.0% | 20.0% | ≥ 70% New | **New Projects** | Yes |
| Salesforce Inc. | CRM | USA | 2021 | 75.0% | 25.0% | ≥ 70% New | **New Projects** | Yes |
| General Motors | GM | USA | 2022 | 88.0% | 12.0% | ≥ 70% New | **New Projects** | Yes |
| Honda Motor Co. | HMC | Japan | 2022 | 75.0% | 25.0% | ≥ 70% New | **New Projects** | Yes |
| Toyota Motor Credit | TM | Japan | 2014 | 15.0% | 85.0% | ≥ 70% Refin. | **Refinancing** | No |
| Unibail-Rodamco-Westfield | URW.PA | France | 2014 | 30.0% | 70.0% | ≥ 70% Refin. | **Refinancing** | Yes |
| Southern Company | SO | USA | 2016 | 20.0% | 80.0% | ≥ 70% Refin. | **Refinancing** | No |
| Boston Properties | BXP | USA | 2018 | 20.0% | 80.0% | ≥ 70% Refin. | **Refinancing** | Yes |
| Duke Energy Carolinas | DUK | USA | 2018 | 30.0% | 70.0% | ≥ 70% Refin. | **Refinancing** | No |

*Notes:* Deterministic classification rule: New Projects (≥ 70% New), Refinancing (≥ 70% Refinancing), Mixed Allocation (30% < New < 70%). All 42 issuers are categorized deterministically without exception. SPO indicates third-party external review / Second-Party Opinion.


### Table S15. Audited Corporate Case Studies for Refinancing and Key New-Project Issuers

| Issuer | Issuance | New % | Refin. % | Audited Allocation Evidence | Assurance Source |
|---|---|---|---|---|---|
| **Panel A: Refinancing Cohort (N = 5; All ≥ 70% Refinancing)** | | | | | |
| Duke Energy Carolinas | Nov 2018, $1,000M | 30.0% | 70.0% | $700M allocated to refinancing operational solar assets placed in service in 2015–2016; $300M to new grid battery storage. | Form 8-K Prospectus, pp. S-14–S-16 |
| Southern Company | Dec 2016, $1,200M | 20.0% | 80.0% | $960M allocated to retiring term credit facilities funding solar/biomass facilities commissioned prior to 2015; $240M new. | Use of Proceeds Report 2017, pp. 3–5 |
| Toyota Motor Credit | Mar 2014, $1,750M | 15.0% | 85.0% | 85% of proceeds allocated to refinancing pre-existing retail lease receivables for hybrid vehicles; 15% to new EV inventory. | DNV GL Review, pp. 3–7 |
| Boston Properties | Nov 2018, $1,000M | 20.0% | 80.0% | $800M allocated to refinancing pre-existing term mortgage debt on operational LEED properties; $200M to active development. | Impact Report 2019, pp. 4–8 |
| Unibail-Rodamco-Westfield | Feb 2014, EUR 750M | 30.0% | 70.0% | EUR 525M allocated to refinancing operational retail assets with BREEAM certification; EUR 225M to new construction. | Assurance Report 2015, pp. 6–10 |
| **Panel B: Illustrative New-Project Cohort Issuers (N = 31; All ≥ 70% New Projects)** | | | | | |
| Apple Inc. | Feb 2016, $1,500M | 82.0% | 18.0% | $1,230M allocated to direct 1.2 GW renewable PPAs and recycled alloy pilot; $270M bridge loan refinancing. | Ernst & Young, pp. 4–6 |
| Iberdrola S.A. | Apr 2014, EUR 1,020M | 95.0% | 5.0% | EUR 969M dedicated to new Wikinger offshore wind turbine construction; EUR 51M pre-issuance grid hookup. | PwC Assurance, pp. 8–12 |
| NextEra Energy Capital | May 2019, $1,500M | 90.0% | 10.0% | $1,350M allocated to 2,400 MW new wind capacity in OK and TX; $150M short-term pre-construction debt. | Deloitte Review, pp. 2–5 |
| Digital Realty Trust | Oct 2019, EUR 650M | 70.0% | 30.0% | EUR 455M allocated to new hyperscale data center construction (PUE < 1.2); EUR 195M operational retrofits. | Sustainalytics, pp. 2–6 |
| Prologis Inc. | Mar 2018, $850M | 75.0% | 25.0% | $637.5M allocated to new logistics facilities with rooftop solar; $212.5M to pre-existing warehouse retrofits. | Sustainalytics, pp. 3–7 |

*Notes:* Case examples illustrate audited allocation reports, prospectus covenants, and independent verifier assurance letters. All five refinancing cohort firms strictly satisfy the ≥ 70% refinancing rule.


---

## S9. Extended ESG Provider Robustness

### Table S16. ESG Provider Upgrade Decomposition by Allocation Category

| Provider | New-Project ESG Upgrade | Refinancing ESG Upgrade | Difference | *p* (Difference) |
|---|---|---|---|---|
| MSCI ESG Research (44.8% of firm-years) | +0.89σ | +0.91σ | −0.02σ | 0.481 |
| S&P Global Trucost (35.2% of firm-years) | +0.91σ | +0.90σ | +0.01σ | 0.612 |
| Refinitiv ESG (20.0% of firm-years) | +0.88σ | +0.92σ | −0.04σ | 0.398 |
| **Combined Sample (Provider FEs)** | **+0.9011σ** | **+0.9053σ** | **+0.0042σ** | **0.9265** |

*Notes:* Standardized within-provider scores ($z$-scores). Difference $p$-values from Wald tests on the combined-sample formal equivalence diagnostic (S6.2). No provider demonstrates a statistically detectable rating upgrade premium for new-project over refinancing issuers. The combined-sample formal equivalence diagnostic yields $\Delta = +0.0042\sigma, p = 0.9265$ (95% CI: [−0.0842σ, +0.0926σ]), falling entirely within the $\pm0.10\sigma$ equivalence benchmark; a two one-sided test (TOST) confirms formal statistical equivalence within this margin ($t_1 = 2.31, t_2 = 2.12, p_{\text{TOST}} = 0.0168 < 0.05$).

---

## S10. Supporting Figures

### Figure S1. Physical Decarbonization vs. Commercial ESG Upgrade Decoupling Diagnostic
![Figure S1: Empirical Greenwashing Diagnostic](Figures/fig15_greenwashing_diagnostic.png)

**Figure S1.** Decoupling Diagnostic Across Issuer Archetypes. Comparison of commercial ESG rating upgrades (amber bars, left axis, normalized x10) against physical Scope 1+2 carbon abatement (navy bars, right axis) across corporate green-bond issuer archetypes. Archetype I (New Projects, N = 31) exhibits substantial ESG upgrades (+0.90σ) and deep physical emissions reductions (−6.31%). Archetype II (Refinancing Dominated, N = 5) secures identical commercial ESG rating gains (+0.91σ) despite relative emissions divergence (+3.88%), demonstrating a divergence between disclosure-driven ESG scores and physical emissions trajectories.

---

### Figure S2. Empirical Research Architecture and Econometric Identification Pipeline
![Figure S2: Empirical Research Architecture](Figures/fig02_research_design.png)

**Figure S2.** Empirical Research Design and Econometric Pipeline. Multi-stage methodological framework: Step 1 constructs the balanced corporate panel (84 firms, 42 treated, 42 matched controls; 1,008 firm-years, 2013–2024) with 1:1 propensity-score matching. Step 2 implements the Callaway–Sant’Anna (2021) staggered difference-in-differences estimator across event times τ ∈ [−5, +5] with pre-trend parallelism testing (Wald F = 0.285, p = 0.887). Step 3 decomposes proceeds allocation continuously and categorically (N = 31 new, N = 5 refinancing, N = 6 mixed). Step 4 conducts governance and sensitivity audits (36 verified vs. 6 unverified; leave-one-out Jackknife; non-COVID; no-utilities; NLP audit).

---

### Figure S3. Econometric Robustness and Specification Sensitivity Summary
![Figure S3: Econometric Robustness and Falsification](Figures/fig17_robustness_comparison.png)

**Figure S3.** Econometric Robustness and Specification Sensitivity Summary. Estimated treatment effect on log Scope 1+2 emissions across alternative model specifications with 95% confidence intervals. All substantive specifications (baseline Callaway–Sant’Anna: β̂ = −0.0934; baseline TWFE: β̂ = −0.0470; COVID exclusion: β̂ = −0.0550; excluding utilities: β̂ = −0.0582; exact within-sector matches: β̂ = −0.0928; 1% winsorization: β̂ = −0.0858) remain robust and statistically significant at p < 0.001. The random placebo timing falsification test (β̂ = −0.0012, p = 0.636) confirms no spurious treatment attribution.

---

### Figure S4. Heterogeneity in Post-Issuance Emissions Associations Across Subgroups
![Figure S4: Heterogeneous Treatment Effects](Figures/fig11_heterogeneous_effects.png)

**Figure S4.** Heterogeneous Treatment Associations Across Corporate Subgroups. Subgroup estimates on log Scope 1+2 emissions across pre-issuance leverage (High Leverage: β̂ = −0.0685, SE = 0.0088 vs. Low Leverage: β̂ = −0.0382, SE = 0.0095; difference p = 0.024), baseline carbon intensity (High Emitters: β̂ = −0.0520 vs. Low Emitters: β̂ = −0.0410), and external verification (Verified: β̂ = −0.0612, SE = 0.0078 vs. Unverified: β̂ = −0.0185, SE = 0.0142; difference p = 0.009). Estimates correspond to the multivariate heterogeneity models reported in Table 7 of the main manuscript. Subgroup sorting is observational; estimates reflect empirical heterogeneity in trajectories rather than exogenous treatment interactions.

---

### Figure S5. Governance Role: External Third-Party Verification vs. Self-Certification
![Figure S5: The Governance Role](Figures/fig13_verified_vs_unverified.png)

**Figure S5.** Governance Role: External Verification vs. Self-Certification (N = 42). Comparison of post-issuance emissions trajectory differentials for green bonds backed by external third-party review (Second-Party Opinion / CBI Certification, N = 36 firms, 432 firm-years, β̂ = −0.0612, SE = 0.0078, p < 0.001) versus unverified / self-certified debt (N = 6 firms, 72 firm-years, β̂ = −0.0185, SE = 0.0142, p = 0.193, n.s.; difference p = 0.009). Estimates match Table 7 of the main manuscript. External verification is associated with a significantly stronger decarbonization trajectory, though reflecting observational sorting among larger, better-governed issuers.

---

### Figure S6. Continuous Proceeds Allocation Share and Post-Issuance Emissions Delta Curve
![Figure S6: Global Green Debt Market Expansion](Figures/fig03_issuance_trends.png)

**Figure S6.** Continuous Allocation Share and Post-Issuance Emissions Differential. Model-implied emissions delta curve (100 × [exp(β̂₁ + β̂₂ × AllocationNew) − 1]) across contractual new-project allocation shares from 0% to 100%, based on the structural interaction model in Table 5 (β̂₁ = +0.0673, β̂₂ = −0.1590). Shaded area indicates 95% confidence interval computed via the delta method. The vertical dotted line marks the pre-specified 70% threshold distinguishing new-project from refinancing regimes.

---

### Figure S7. Empirical Sample Composition Across Staggered Treatment Adoption Cohorts
![Figure S7: Sample Composition Across Cohorts](Figures/fig04_firm_distribution.png)

**Figure S7.** Empirical Sample Composition Across Staggered Treatment Adoption Cohorts (N = 84). Distribution of the 84 sample corporations across never-treated comparison peers (N = 42 firms, 50%) and staggered adoption cohorts (2014–2022, 42 treated firms: 2 in 2014, 2 in 2016, 3 in 2017, 7 in 2018, 7 in 2019, 9 in 2020, 8 in 2021, and 4 in 2022), providing the observational basis for the Callaway–Sant’Anna staggered difference-in-differences identification.

---

### Figure S8. Decarbonization Trajectory: Scope 1+2 Carbon Intensity Reduction
![Figure S8: Decarbonization Trajectory](Figures/fig08_carbon_intensity.png)

**Figure S8.** Decarbonization Trajectory: Scope 1+2 Carbon Intensity Reduction. Post-issuance carbon intensity trajectories (tCO₂e per million USD revenue) for green-bond issuers relative to matched comparison peers over event horizons t−3 to t+4. Demonstrates sustained physical decarbonization normalized by firm scale.

---

*[End of Supporting Information]*
