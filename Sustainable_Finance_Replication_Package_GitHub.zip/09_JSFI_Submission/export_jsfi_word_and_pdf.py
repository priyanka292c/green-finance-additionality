import os
import sys
import win32com.client
import docx

jsfi_dir = os.path.abspath(r'd:\Quantum finance\Sustainable-finance resear (2)\Sustainable-finance resear\09_JSFI_Submission')

documents = [
    "01_JSFI_Title_Page",
    "02_JSFI_Anonymous_Manuscript",
    "03_JSFI_Supplementary_Material",
    "04_JSFI_Cover_Letter"
]

print("Starting Microsoft Word COM Application...")
word = win32com.client.Dispatch('Word.Application')
word.Visible = False
word.DisplayAlerts = 0

MAX_WIDTH_INCHES = 5.8
MAX_WIDTH_EMU = int(MAX_WIDTH_INCHES * 914400)

for base in documents:
    html_file = os.path.join(jsfi_dir, f"{base}.html")
    docx_file = os.path.join(jsfi_dir, f"{base}.docx")
    pdf_file  = os.path.join(jsfi_dir, f"{base}.pdf")

    if not os.path.exists(html_file):
        print(f"Warning: HTML not found: {html_file}")
        continue

    print(f"\nProcessing {base}...")
    try:
        # 1. Open HTML in Word and save initial DOCX
        doc = word.Documents.Open(html_file, False, True, False)
        doc.PageSetup.TopMargin = 72    # 1 inch (72 pt)
        doc.PageSetup.BottomMargin = 72 # 1 inch
        doc.PageSetup.LeftMargin = 72   # 1 inch
        doc.PageSetup.RightMargin = 72  # 1 inch
        
        # Ensure Times New Roman and Double Spacing where applicable
        if base == "03_JSFI_Supplementary_Material":
            # Prevent awkward mid-table splits for small tables (like S12, S13, S15, S16)
            for idx in range(1, doc.Tables.Count + 1):
                t = doc.Tables(idx)
                if t.Rows.Count < 20:
                    t.Rows.AllowBreakAcrossPages = False

            s14b_table = None
            for idx in range(1, doc.Tables.Count + 1):
                t = doc.Tables(idx)
                if t.Columns.Count == 12:
                    s14b_table = t
                    break
            
            if s14b_table:
                print("  Formatting Table S14b in landscape orientation...")
                # Insert section break before Table S14b (before the caption)
                rng_before = s14b_table.Range
                rng_before.Collapse(1) # wdCollapseStart = 1
                rng_before.MoveStart(4, -2) # wdParagraph = 4
                rng_before.Collapse(1)
                rng_before.InsertBreak(2) # wdSectionBreakNextPage = 2

                # Insert section break after Table S14b (after table notes)
                rng_after = s14b_table.Range
                rng_after.Collapse(0) # wdCollapseEnd = 0
                rng_after.MoveEnd(4, 2)
                rng_after.Collapse(0)
                rng_after.InsertBreak(2) # wdSectionBreakNextPage = 2

                # Configure the section containing Table S14b to Landscape
                sec_landscape = s14b_table.Range.Sections(1)
                sec_landscape.PageSetup.Orientation = 1 # wdOrientLandscape = 1
                sec_landscape.PageSetup.PageWidth = 792 # 11.0 in
                sec_landscape.PageSetup.PageHeight = 612 # 8.5 in
                sec_landscape.PageSetup.TopMargin = 36 # 0.5 in
                sec_landscape.PageSetup.BottomMargin = 36
                sec_landscape.PageSetup.LeftMargin = 36
                sec_landscape.PageSetup.RightMargin = 36

                # Repeat header row across all landscape pages
                s14b_table.Rows(1).HeadingFormat = True
                s14b_table.Rows.AllowBreakAcrossPages = True

                # Typography: 7.5 pt Times New Roman, single spacing
                s14b_table.Range.Font.Name = "Times New Roman"
                s14b_table.Range.Font.Size = 7.5
                s14b_table.Range.ParagraphFormat.LineSpacingRule = 0 # wdLineSpaceSingle
                s14b_table.Range.ParagraphFormat.SpaceBefore = 0
                s14b_table.Range.ParagraphFormat.SpaceAfter = 1

                # Set explicit balanced column widths across 720 pt printable width
                col_widths = [18, 62, 62, 62, 62, 54, 46, 25, 40, 135, 110, 44]
                for c_idx, width in enumerate(col_widths):
                    try:
                        s14b_table.Columns(c_idx + 1).Width = width
                    except Exception:
                        pass
                print("  Table S14b landscape formatting complete.")

        doc.SaveAs2(docx_file, 16) # wdFormatXMLDocument
        doc.Close(0)

        # 2. Inspect and clamp inline shapes with python-docx
        doc_obj = docx.Document(docx_file)
        modified_shapes = 0
        for s in doc_obj.inline_shapes:
            if s.width > MAX_WIDTH_EMU:
                ratio = MAX_WIDTH_EMU / s.width
                s.height = int(s.height * ratio)
                s.width = MAX_WIDTH_EMU
                modified_shapes += 1
        if modified_shapes > 0:
            doc_obj.save(docx_file)
            print(f"  Clamped {modified_shapes} images to {MAX_WIDTH_INCHES} inches in {base}.docx")

        # 3. Open perfected DOCX in Word and export to PDF
        doc_docx = word.Documents.Open(docx_file, False, True, False)
        doc_docx.ExportAsFixedFormat(pdf_file, 17, False, 0) # wdExportFormatPDF
        doc_docx.Close(0)

        docx_size = os.path.getsize(docx_file)
        pdf_size  = os.path.getsize(pdf_file)
        print(f"  [SUCCESS] {base}: DOCX ({docx_size:,} B), PDF ({pdf_size:,} B)")
    except Exception as e:
        print(f"  [ERROR] {base}: {e}")

word.Quit()
print("\nAll DOCX and PDF documents exported successfully!")
