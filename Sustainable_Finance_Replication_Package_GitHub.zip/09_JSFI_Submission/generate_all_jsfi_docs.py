"""
Script to generate all JSFI submission documents in MD, TEX, HTML, DOCX, and PDF.
Documents:
1. 01_JSFI_Title_Page (Full author info, affiliations, contact, statements)
2. 02_JSFI_Anonymous_Manuscript (Double-anonymized main manuscript with 8 numbered sections, tables, figures)
3. 03_JSFI_Supplementary_Material (Double-anonymized supporting tables, proofs, diagnostics)
4. 04_JSFI_Cover_Letter (Cover letter tailored for Journal of Sustainable Finance & Investment)
"""

import os
import sys
import subprocess
import shutil

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
FIG_DIR = os.path.join(BASE_DIR, "Figures")

print(f"Working in: {BASE_DIR}")
