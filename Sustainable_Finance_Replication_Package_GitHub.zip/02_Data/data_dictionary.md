# Data Dictionary & Empirical Sample Documentation

## 1. Overview and Scientific Integrity Protocol
In strict compliance with the **Non-Negotiable Scientific Integrity Rule**:
- Real macro, sectoral, and verified corporate disclosures are drawn directly from the **Climate Bonds Initiative (CBI)**, **Bank for International Settlements (BIS)**, **EDGAR / Global Carbon Atlas**, and **SEC EDGAR corporate filings**.
- Micro-econometric method validation uses an explicitly labelled **Monte Carlo Simulation Panel** (`monte_carlo_validation_panel.csv`) to test the finite-sample performance of the Callaway & Sant'Anna (2021) Staggered Difference-in-Differences and Double Machine Learning estimators under known ground-truth additionality.
- **Zero simulated data are presented as real corporate evidence.**

---

## 2. Empirical Datasets

### A. Real Global Green Debt Trends (`real_global_green_debt_trends.csv`)
- **Coverage**: Annual time-series (2014–2025).
- **Sources**: Climate Bonds Initiative (CBI) Global State of the Market, BIS Sustainable Debt Database.
- **Variables**:
  - `Year`: Calendar year (2014–2025).
  - `Green_Bond_Issuance_USD_Bn`: Annual global green bond issuance (USD Billions).
  - `Green_Loan_Issuance_USD_Bn`: Annual global syndicated green & sustainability-linked loans (USD Billions).
  - `Total_Green_Debt_USD_Bn`: Total annual green debt issuance ($GB + GL$).
  - `New_Project_Share`: Proportion of proceeds allocated to new green capital expenditures.
  - `Refinancing_Share`: Proportion of proceeds allocated to refinancing pre-existing green assets.
  - `External_Review_Share`: Proportion of debt verified by Second-Party Opinions (SPOs) or CBI certification.

### B. Real Sectoral Allocation (`real_sector_allocation.csv`)
- **Coverage**: 8 CBI standard sectors.
- **Variables**:
  - `Sector`: Standard sector classification (Renewable Energy, Green Buildings, Clean Transport, Water Infrastructure, Waste, Land Use, Industry, ICT).
  - `CBI_Share`: Historical market share.
  - `Volume_USD_Bn_2024`: 2024 allocated volume.

### C. Real Corporate Green Issuers Panel (`real_corporate_green_issuers.csv`)
- **Coverage**: 20 prominent global corporate green bond and loan issuances across 6 sectors (Utilities, Tech, Telecom, Real Estate, Automotive, Consumer).
- **Sources**: SEC Form 10-K, 8-K prospectus supplements, corporate green bond allocation reports, and CBI certified databases.
- **Variables**:
  - `Firm`: Issuing corporation name.
  - `Ticker`: Stock exchange ticker.
  - `Sector`: Industry sector.
  - `Country`: Country of domicile.
  - `Issuance_Year`: Issuance year (2014–2021).
  - `Debt_Type`: Instrument class (Green Bond vs Green Loan).
  - `Amount_USD_M`: Principal amount (USD Millions).
  - `Use_Of_Proceeds`: Contractual classification (New Projects vs Refinancing vs Mixed).
  - `Pct_New_Projects`: Documented percentage of proceeds allocated to new CapEx.
  - `Pct_Refinancing`: Documented percentage of proceeds allocated to refinancing.
  - `External_Verifier`: Independent verifier (Sustainalytics, ISS-ESG, DNV-GL, Vigeo Eiris).
  - `Pre_Scope1_2_Mt`: Scope 1 + Scope 2 emissions (Million metric tons CO2e) prior to issuance.
  - `Post_Scope1_2_Mt`: Scope 1 + Scope 2 emissions 2-3 years post-issuance.
  - `Emissions_Pct_Change`: Percentage abatement in physical emissions.
  - `Green_Capex_Delta_Pct`: Change in green capital expenditures as a percentage of total CapEx.

### D. Monte Carlo Validation Panel (`monte_carlo_validation_panel.csv`)
- **Purpose**: Strictly for Method Validation (Phase 8, 9, 10, 11).
- **Structure**: Balanced panel of 600 firms over 13 years (2012–2024) = 7,800 observations.
- **Cohorts**: Staggered adoption in 2016, 2018, 2020, 2022, and 300 never-treated control firms.
- **Known Data Generating Process**:
  - True New Project Additionality: $\Delta 	ext{Emissions} = -15.0\%$, $\Delta 	ext{Green CapEx} = +3.6\%$.
  - True Refinancing Additionality: $\Delta 	ext{Emissions} = -1.5\%$ (near-zero additionality), $\Delta 	ext{Green CapEx} = +0.3\%$.
  - True Greenwashing / Signaling: ESG scores jump by $+8.5$ points across all treated units regardless of physical abatement.
