%% 07_event_study.m
% Estimates dynamic treatment effects across event windows t-5 to t+5.

fprintf('Executing 07_event_study.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_sim');

event_vars = {'Ev_neg_5', 'Ev_neg_4', 'Ev_neg_3', 'Ev_neg_2', ...
              'Ev_pos_0', 'Ev_pos_1', 'Ev_pos_2', 'Ev_pos_3', 'Ev_pos_4', 'Ev_pos_5'};

formula_ev = ['Log_Emissions ~ ' strjoin(event_vars, ' + ') ' + Log_Assets + ROA + Leverage + Tobins_Q + Year_Cat'];
mdl_event = fitlm(T_sim, formula_ev);

ev_times = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5];
betas = zeros(length(ev_times), 1);
ci_low = zeros(length(ev_times), 1);
ci_high = zeros(length(ev_times), 1);

for i = 1:length(ev_times)
    k = ev_times(i);
    if k == -1
        betas(i) = 0.0;
        ci_low(i) = 0.0;
        ci_high(i) = 0.0;
    else
        if k < 0
            v_name = sprintf('Ev_neg_%d', abs(k));
        else
            v_name = sprintf('Ev_pos_%d', k);
        end
        b = mdl_event.Coefficients{v_name, 'Estimate'};
        se = mdl_event.Coefficients{v_name, 'SE'};
        betas(i) = b;
        ci_low(i) = b - 1.96 * se;
        ci_high(i) = b + 1.96 * se;
    end
end

T_event_matlab = table(ev_times', betas, ci_low, ci_high, ...
    'VariableNames', {'Event_Time', 'Beta', 'CI_95_Low', 'CI_95_High'});

writetable(T_event_matlab, fullfile('.', 'matlab_event_study.csv'));
save(fullfile('.', 'matlab_event_model.mat'), 'mdl_event', 'T_event_matlab');
fprintf('07_event_study.m completed successfully.\n\n');
