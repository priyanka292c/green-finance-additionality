%% 05_baseline_DID.m
% Implements baseline Difference-in-Differences panel regression.

fprintf('Executing 05_baseline_DID.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_sim');

% Baseline OLS regression with controls and year fixed effects (Year_Cat)
formula_m1 = 'Log_Emissions ~ Treat_Post + Log_Assets + ROA + Leverage + Tobins_Q + Year_Cat';
mdl_did_emiss = fitlm(T_sim, formula_m1);

formula_m2 = 'Green_Capex_Pct ~ Treat_Post + Log_Assets + ROA + Leverage + Tobins_Q + Year_Cat';
mdl_did_capex = fitlm(T_sim, formula_m2);

formula_m3 = 'ESG_Score ~ Treat_Post + Log_Assets + ROA + Leverage + Tobins_Q + Year_Cat';
mdl_did_esg = fitlm(T_sim, formula_m3);

fprintf('  [Log Emissions] Treat_Post Coef: %.4f (SE: %.4f, p: %.4e)\n', ...
    mdl_did_emiss.Coefficients{'Treat_Post', 'Estimate'}, ...
    mdl_did_emiss.Coefficients{'Treat_Post', 'SE'}, ...
    mdl_did_emiss.Coefficients{'Treat_Post', 'pValue'});

fprintf('  [Green CapEx]   Treat_Post Coef: +%.4f%% (SE: %.4f, p: %.4e)\n', ...
    mdl_did_capex.Coefficients{'Treat_Post', 'Estimate'}, ...
    mdl_did_capex.Coefficients{'Treat_Post', 'SE'}, ...
    mdl_did_capex.Coefficients{'Treat_Post', 'pValue'});

fprintf('  [ESG Score]     Treat_Post Coef: +%.2f pts (SE: %.4f, p: %.4e)\n', ...
    mdl_did_esg.Coefficients{'Treat_Post', 'Estimate'}, ...
    mdl_did_esg.Coefficients{'Treat_Post', 'SE'}, ...
    mdl_did_esg.Coefficients{'Treat_Post', 'pValue'});

save(fullfile('.', 'matlab_did_models.mat'), 'mdl_did_emiss', 'mdl_did_capex', 'mdl_did_esg');
fprintf('05_baseline_DID.m completed successfully.\n\n');
