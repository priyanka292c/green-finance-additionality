%% 08_parallel_trends.m
% Joint Wald test of pre-treatment coefficients (H0: beta_-5 = beta_-4 = beta_-3 = beta_-2 = 0).

fprintf('Executing 08_parallel_trends.m...\n');
load(fullfile('.', 'matlab_event_model.mat'), 'mdl_event');

pre_vars = {'Ev_neg_5', 'Ev_neg_4', 'Ev_neg_3', 'Ev_neg_2'};
H = zeros(length(pre_vars), mdl_event.NumCoefficients);

for i = 1:length(pre_vars)
    col_idx = find(strcmp(mdl_event.CoefficientNames, pre_vars{i}));
    if ~isempty(col_idx)
        H(i, col_idx) = 1;
    end
end

[p_val, F_stat] = coefTest(mdl_event, H);

fprintf('  Joint F-test of pre-treatment coefficients:\n');
fprintf('  F-statistic: %.3f, p-value: %.4f\n', F_stat, p_val);

if p_val > 0.05
    fprintf('  [VALIDATED] Parallel trends assumption holds (p > 0.05).\n');
else
    warning('Pre-treatment coefficients statistically significant.');
end

T_parallel = table({'Joint Wald Pre-Trend Test (t-5 to t-2)'}, F_stat, p_val, ...
    'VariableNames', {'Test', 'F_Stat', 'pValue'});
writetable(T_parallel, fullfile('.', 'matlab_parallel_trends_test.csv'));
fprintf('08_parallel_trends.m completed successfully.\n\n');
