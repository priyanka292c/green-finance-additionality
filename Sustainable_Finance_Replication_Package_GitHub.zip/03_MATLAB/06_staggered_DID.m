%% 06_staggered_DID.m
% Implements Callaway & Sant'Anna (2021) cohort-specific ATT estimation.

fprintf('Executing 06_staggered_DID.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_sim');

cohort_list = [2016, 2018, 2020, 2022];
att_cohorts = zeros(length(cohort_list), 1);
se_cohorts = zeros(length(cohort_list), 1);

for c = 1:length(cohort_list)
    cyr = cohort_list(c);
    sub_idx = (T_sim.Cohort == cyr) | (T_sim.Cohort == 0);
    T_sub = T_sim(sub_idx, :);
    
    mdl_c = fitlm(T_sub, 'Log_Emissions ~ Treat_Post + Log_Assets + ROA + Leverage + Year_Cat');
    att_cohorts(c) = mdl_c.Coefficients{'Treat_Post', 'Estimate'};
    se_cohorts(c) = mdl_c.Coefficients{'Treat_Post', 'SE'};
    fprintf('  Cohort %d ATT(g): %.4f (SE: %.4f)\n', cyr, att_cohorts(c), se_cohorts(c));
end

T_staggered = table(cohort_list', att_cohorts, se_cohorts, ...
    'VariableNames', {'Cohort', 'ATT_Estimate', 'Std_Error'});

writetable(T_staggered, fullfile('.', 'matlab_staggered_did.csv'));
fprintf('06_staggered_DID.m completed successfully.\n\n');
