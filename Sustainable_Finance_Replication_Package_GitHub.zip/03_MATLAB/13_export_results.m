%% 13_export_results.m
% Exports MATLAB generated figures and consolidated summary log.

fprintf('Executing 13_export_results.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_macro', 'T_sim');
load(fullfile('.', 'matlab_event_model.mat'), 'T_event_matlab');

fig_out_dir = fullfile('..', '05_Figures');

% 1. MATLAB Event Study Figure
f1 = figure('Visible', 'off', 'Position', [100, 100, 750, 450]);
ev_t = T_event_matlab.Event_Time;
b = T_event_matlab.Beta;
ci_l = T_event_matlab.CI_95_Low;
ci_h = T_event_matlab.CI_95_High;

fill([ev_t; flipud(ev_t)], [ci_l; flipud(ci_h)], [0.85, 0.90, 0.98], 'EdgeColor', 'none');
hold on;
plot(ev_t, b, '-o', 'Color', [0.1, 0.2, 0.45], 'LineWidth', 2, 'MarkerFaceColor', [0.1, 0.2, 0.45]);
yline(0, '--r', 'LineWidth', 1.2);
xline(-1, ':k', 'LineWidth', 1.2);
grid on;
xlabel('Event Time Relative to Green Debt Issuance (Years)');
ylabel('Dynamic Treatment Effect on Log Emissions (ATT)');
title('MATLAB Figure: Dynamic Event-Study Treatment Effect Estimates');
saveas(f1, fullfile(fig_out_dir, 'matlab_fig06_event_study.png'));
close(f1);
fprintf('  [OK] Exported matlab_fig06_event_study.png\n');

% 2. MATLAB Issuance Trends Figure
f2 = figure('Visible', 'off', 'Position', [100, 100, 750, 450]);
bar(T_macro.Year, [T_macro.Green_Bond_Issuance_USD_Bn, T_macro.Green_Loan_Issuance_USD_Bn], 'stacked');
xlabel('Calendar Year');
ylabel('Global Issuance Volume (USD Billions)');
title('MATLAB Figure: Global Green Bond and Loan Issuance (2014-2025)');
legend({'Green Bonds', 'Green Loans'}, 'Location', 'northwest');
grid on;
saveas(f2, fullfile(fig_out_dir, 'matlab_fig03_issuance_trends.png'));
close(f2);
fprintf('  [OK] Exported matlab_fig03_issuance_trends.png\n');

fprintf('13_export_results.m completed successfully.\n\n');
