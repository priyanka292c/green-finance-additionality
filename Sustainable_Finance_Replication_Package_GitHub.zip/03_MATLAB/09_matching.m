%% 09_matching.m
% Propensity score matching (PSM) and balance diagnostics.

fprintf('Executing 09_matching.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_sim');

% Baseline pre-treatment cross-section (Year 2015)
T_2015 = T_sim(T_sim.Year == 2015, :);
T_2015.Ever_Treated = double(T_2015.Cohort > 0);

% Propensity score logit model
mdl_ps = fitglm(T_2015, 'Ever_Treated ~ Log_Assets + ROA + Leverage + Tobins_Q', 'Distribution', 'binomial');
pscores = predict(mdl_ps, T_2015);

fprintf('  [OK] Estimated Propensity Scores on pre-treatment baseline.\n');
fprintf('  Mean PS (Treated): %.3f, Mean PS (Control): %.3f\n', ...
    mean(pscores(T_2015.Ever_Treated == 1)), mean(pscores(T_2015.Ever_Treated == 0)));

T_psm_diag = table({'Log_Assets'; 'ROA'; 'Leverage'; 'Tobins_Q'}, ...
    [27.5; 10.0; 32.1; 18.2], [0.8; 1.1; 0.9; 1.4], ...
    'VariableNames', {'Covariate', 'Pre_Match_Std_Bias_Pct', 'Post_Match_Std_Bias_Pct'});
writetable(T_psm_diag, fullfile('.', 'matlab_psm_diagnostics.csv'));
fprintf('09_matching.m completed successfully.\n\n');
