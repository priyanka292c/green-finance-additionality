%% 03_variable_construction.m
% Constructs econometric indicators: cohort indicators, post-treatment dummies,
% event-time indicators, and carbon intensity metrics.

fprintf('Executing 03_variable_construction.m...\n');
load(fullfile('.', 'matlab_cleaned_data.mat'), 'T_macro', 'T_corp', 'T_sim');

% 1. Create Categorical variables for Year and Firm
T_sim.Year_Cat = categorical(T_sim.Year);
T_sim.Firm_Cat = categorical(T_sim.Firm_ID);

% 2. Create Post-treatment Indicator: Treat_Post = Treated * (Year >= Cohort)
T_sim.Treat_Post = zeros(height(T_sim), 1);
treated_idx = (T_sim.Cohort > 0) & (T_sim.Year >= T_sim.Cohort);
T_sim.Treat_Post(treated_idx) = 1;

% 3. Create Event-Time indicators (t-5 to t+5)
event_windows = -5:5;
for k = event_windows
    if k < 0
        v_name = sprintf('Ev_neg_%d', abs(k));
    else
        v_name = sprintf('Ev_pos_%d', k);
    end
    T_sim.(v_name) = double((T_sim.Cohort > 0) & (T_sim.Event_Time == k));
end

% 4. Carbon Intensity Proxy (Log Emissions relative to Assets)
T_sim.Carbon_Intensity_Asset = T_sim.Log_Emissions - T_sim.Log_Assets;

fprintf('  [OK] Constructed Year_Cat, Firm_Cat, Treat_Post, 11 event-time dummies, and Carbon_Intensity.\n');

save(fullfile('.', 'matlab_variables_data.mat'), 'T_macro', 'T_corp', 'T_sim');
fprintf('03_variable_construction.m completed successfully.\n\n');
