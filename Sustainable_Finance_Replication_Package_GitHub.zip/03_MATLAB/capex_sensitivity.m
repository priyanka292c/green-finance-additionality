%% capex_sensitivity.m
% Computes exact Non-GB CapEx ATT under 1, 2, 3, 4, and 5-year disbursement schedules
% Using both Callaway-Sant'Anna (2021) and TWFE

fprintf('Starting CapEx sensitivity analysis...\n');
csv_path = fullfile('..', '02_Data', 'clean', 'corporate_green_bond_empirical_panel.csv');
opts = detectImportOptions(csv_path);
T = readtable(csv_path, opts);

firms = unique(T.Firm);
years = unique(T.Year);
cohorts = unique(T.First_Issue_Year(T.Treated_Firm == 1));
cohorts = sort(cohorts);

windows = [1, 2, 3, 4, 5];
results = table('Size', [length(windows), 7], ...
    'VariableTypes', {'double', 'double', 'double', 'double', 'double', 'double', 'double'}, ...
    'VariableNames', {'Window_Years', 'CS_ATT', 'CS_SE', 'CS_t', 'TWFE_Beta', 'TWFE_SE', 'TWFE_t'});

for w_idx = 1:length(windows)
    W = windows(w_idx);
    
    % Compute Non-GB CapEx share
    ann_gb = zeros(height(T), 1);
    for i = 1:height(T)
        if T.Post_Treatment(i) == 1
            ann_gb(i) = (T.Green_Bond_Proceeds_USD_M(i) * (T.Pct_New_Projects(i) / 100.0)) / W;
        end
    end
    nongb_usd = max(0.0, T.Green_Capex_USD_M - ann_gb);
    nongb_pct = (nongb_usd ./ max(1.0, T.Total_Capex_USD_M)) * 100.0;
    T.temp_nongb = nongb_pct;
    
    % -------------------------------------------------------------
    % 1. Callaway-Sant'Anna (2021)
    % -------------------------------------------------------------
    % Pivot treated and control
    tr_firms = unique(T.Firm(T.Treated_Firm == 1));
    co_firms = unique(T.Firm(T.Treated_Firm == 0));
    n_tr = length(tr_firms);
    n_co = length(co_firms);
    
    firm_first_yr = containers.Map();
    for f = 1:n_tr
        fn = tr_firms{f};
        firm_first_yr(fn) = T.First_Issue_Year(strcmp(T.Firm, fn) & T.Year == 2013);
    end
    
    % Build pivot tables (Firm x Year)
    piv_tr = zeros(n_tr, length(years));
    for f = 1:n_tr
        fn = tr_firms{f};
        for y = 1:length(years)
            yr = years(y);
            val = T.temp_nongb(strcmp(T.Firm, fn) & T.Year == yr);
            piv_tr(f, y) = val(1);
        end
    end
    
    piv_co = zeros(n_co, length(years));
    for f = 1:n_co
        fn = co_firms{f};
        for y = 1:length(years)
            yr = years(y);
            val = T.temp_nongb(strcmp(T.Firm, fn) & T.Year == yr);
            piv_co(f, y) = val(1);
        end
    end
    
    post_g = [];
    post_t = [];
    post_ng = [];
    post_dt = [];
    post_dc = [];
    att_gt_map = containers.Map();
    
    for c_idx = 1:length(cohorts)
        g = cohorts(c_idx);
        base_yr = g - 1;
        base_y_idx = find(years == base_yr);
        
        g_firm_indices = [];
        for f = 1:n_tr
            if firm_first_yr(tr_firms{f}) == g
                g_firm_indices = [g_firm_indices; f];
            end
        end
        n_g = length(g_firm_indices);
        
        diff_tr = piv_tr(g_firm_indices, :) - piv_tr(g_firm_indices, base_y_idx);
        diff_co = piv_co - piv_co(:, base_y_idx);
        
        for y = 1:length(years)
            yr = years(y);
            dt_mean = mean(diff_tr(:, y));
            dc_mean = mean(diff_co(:, y));
            att = dt_mean - dc_mean;
            key = sprintf('%d_%d', g, yr);
            att_gt_map(key) = att;
            if yr >= g
                post_g = [post_g; g];
                post_t = [post_t; yr];
                post_ng = [post_ng; n_g];
                post_dt = [post_dt; dt_mean];
                post_dc = [post_dc; dc_mean];
            end
        end
    end
    
    tot_weight = sum(post_ng);
    overall_att = 0;
    for p = 1:length(post_g)
        key = sprintf('%d_%d', post_g(p), post_t(p));
        overall_att = overall_att + att_gt_map(key) * post_ng(p);
    end
    overall_att = overall_att / tot_weight;
    
    % Influence functions
    psi_tr = zeros(n_tr, 1);
    psi_co = zeros(n_co, 1);
    
    for p = 1:length(post_g)
        w = post_ng(p) / tot_weight;
        g = post_g(p);
        yr = post_t(p);
        base_yr = g - 1;
        y_idx = find(years == yr);
        base_y_idx = find(years == base_yr);
        
        g_firm_indices = [];
        for f = 1:n_tr
            if firm_first_yr(tr_firms{f}) == g
                g_firm_indices = [g_firm_indices; f];
            end
        end
        
        dt_mean = post_dt(p);
        dc_mean = post_dc(p);
        
        diffs_tr = piv_tr(g_firm_indices, y_idx) - piv_tr(g_firm_indices, base_y_idx);
        psi_tr(g_firm_indices) = psi_tr(g_firm_indices) + w * (diffs_tr - dt_mean);
        
        diffs_co = piv_co(:, y_idx) - piv_co(:, base_y_idx);
        psi_co = psi_co + w * (diffs_co - dc_mean);
    end
    
    var_tr = sum(psi_tr.^2) / (n_tr^2) * n_tr;
    var_co = sum(psi_co.^2) / (n_co^2) * n_co;
    se_att = sqrt(var_tr + var_co);
    t_stat = overall_att / se_att;
    
    % -------------------------------------------------------------
    % 2. TWFE Regression with Firm & Year FE + Controls
    % -------------------------------------------------------------
    % Formula matching Python:
    % Green_Capex_NonGB_Pct ~ Post_Treatment + Log_Assets + ROA + Leverage + Tobins_Q + C(Firm) + C(Year)
    % We use fitlm with categorical Firm and Year
    T.Firm_Cat = categorical(T.Firm);
    T.Year_Cat = categorical(T.Year);
    
    lm = fitlm(T, 'temp_nongb ~ Post_Treatment + Log_Assets + ROA + Leverage + Tobins_Q + Firm_Cat + Year_Cat');
    beta_twfe = lm.Coefficients{'Post_Treatment', 'Estimate'};
    se_twfe = lm.Coefficients{'Post_Treatment', 'SE'};
    t_twfe = lm.Coefficients{'Post_Treatment', 'tStat'};
    
    results.Window_Years(w_idx) = W;
    results.CS_ATT(w_idx) = overall_att;
    results.CS_SE(w_idx) = se_att;
    results.CS_t(w_idx) = t_stat;
    results.TWFE_Beta(w_idx) = beta_twfe;
    results.TWFE_SE(w_idx) = se_twfe;
    results.TWFE_t(w_idx) = t_twfe;
    
    fprintf('Window %d yr: CS ATT = %+6.4f pp (SE=%6.4f, t=%6.2f) | TWFE = %+6.4f pp (SE=%6.4f, t=%6.2f)\n', ...
        W, overall_att, se_att, t_stat, beta_twfe, se_twfe, t_twfe);
end

writetable(results, fullfile('.', 'capex_disbursement_sensitivity.csv'));
fprintf('Finished CapEx sensitivity analysis. Saved to capex_disbursement_sensitivity.csv\n');
