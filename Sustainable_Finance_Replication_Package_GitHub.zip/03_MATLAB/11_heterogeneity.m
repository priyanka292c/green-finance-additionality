%% 11_heterogeneity.m
% Analyzes heterogeneous treatment effects across financial constraints and verification.

fprintf('Executing 11_heterogeneity.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_sim');

% 1. High vs Low Leverage (Financial Constraints)
med_lev = median(T_sim.Leverage);
T_high_lev = T_sim(T_sim.Leverage >= med_lev, :);
T_low_lev = T_sim(T_sim.Leverage < med_lev, :);

mdl_hl = fitlm(T_high_lev, 'Log_Emissions ~ Treat_Post + Log_Assets + ROA + Year_Cat');
mdl_ll = fitlm(T_low_lev, 'Log_Emissions ~ Treat_Post + Log_Assets + ROA + Year_Cat');

fprintf('  [High Leverage / Constrained] Treat_Post Coef: %.4f (SE: %.4f)\n', ...
    mdl_hl.Coefficients{'Treat_Post', 'Estimate'}, mdl_hl.Coefficients{'Treat_Post', 'SE'});
fprintf('  [Low Leverage / Unconstrained] Treat_Post Coef: %.4f (SE: %.4f)\n', ...
    mdl_ll.Coefficients{'Treat_Post', 'Estimate'}, mdl_ll.Coefficients{'Treat_Post', 'SE'});

% 2. Verified vs Non-Verified
T_ver = T_sim(T_sim.Verified == 1 | T_sim.Cohort == 0, :);
T_unver = T_sim(T_sim.Verified == 0 | T_sim.Cohort == 0, :);

mdl_ver = fitlm(T_ver, 'Log_Emissions ~ Treat_Post + Log_Assets + ROA + Leverage + Year_Cat');
mdl_unver = fitlm(T_unver, 'Log_Emissions ~ Treat_Post + Log_Assets + ROA + Leverage + Year_Cat');

fprintf('  [Externally Verified] Treat_Post Coef: %.4f (SE: %.4f)\n', ...
    mdl_ver.Coefficients{'Treat_Post', 'Estimate'}, mdl_ver.Coefficients{'Treat_Post', 'SE'});
fprintf('  [Non-Verified / Self] Treat_Post Coef: %.4f (SE: %.4f)\n', ...
    mdl_unver.Coefficients{'Treat_Post', 'Estimate'}, mdl_unver.Coefficients{'Treat_Post', 'SE'});

T_hetero = table({'High Leverage'; 'Low Leverage'; 'Verified'; 'Non-Verified'}, ...
    [mdl_hl.Coefficients{'Treat_Post', 'Estimate'}; mdl_ll.Coefficients{'Treat_Post', 'Estimate'}; ...
     mdl_ver.Coefficients{'Treat_Post', 'Estimate'}; mdl_unver.Coefficients{'Treat_Post', 'Estimate'}], ...
    [mdl_hl.Coefficients{'Treat_Post', 'SE'}; mdl_ll.Coefficients{'Treat_Post', 'SE'}; ...
     mdl_ver.Coefficients{'Treat_Post', 'SE'}; mdl_unver.Coefficients{'Treat_Post', 'SE'}], ...
    'VariableNames', {'Subsample', 'Coefficient', 'Std_Error'});
writetable(T_hetero, fullfile('.', 'matlab_heterogeneity.csv'));
fprintf('11_heterogeneity.m completed successfully.\n\n');
