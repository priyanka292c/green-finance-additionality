%% 01_data_import.m
% Sustainable Finance Additionality Research
% Imports real empirical macro/sector trends, verified corporate disclosures,
% and the Method Validation panel.

fprintf('Executing 01_data_import.m...\n');

data_dir = fullfile('..', '02_Data', 'clean');

% 1. Import Global Sustainable Debt Trends
macro_file = fullfile(data_dir, 'real_global_green_debt_trends.csv');
if exist(macro_file, 'file')
    opts = detectImportOptions(macro_file);
    T_macro = readtable(macro_file, opts);
    fprintf('  [OK] Imported Real Macro Trends: %d annual records.\n', height(T_macro));
else
    error('Macro data file not found: %s', macro_file);
end

% 2. Import Real Corporate Disclosures
corp_file = fullfile(data_dir, 'real_corporate_green_issuers.csv');
if exist(corp_file, 'file')
    opts = detectImportOptions(corp_file);
    T_corp = readtable(corp_file, opts);
    fprintf('  [OK] Imported Real Corporate Disclosures: %d issuer observations.\n', height(T_corp));
else
    error('Corporate disclosure file not found: %s', corp_file);
end

% 3. Import Method Validation Panel
sim_file = fullfile(data_dir, 'monte_carlo_validation_panel.csv');
if exist(sim_file, 'file')
    opts = detectImportOptions(sim_file);
    T_sim = readtable(sim_file, opts);
    fprintf('  [OK] Imported Method Validation Panel: %d firm-year observations.\n', height(T_sim));
else
    error('Simulation panel file not found: %s', sim_file);
end

save(fullfile('.', 'matlab_imported_data.mat'), 'T_macro', 'T_corp', 'T_sim');
fprintf('01_data_import.m completed successfully.\n\n');
