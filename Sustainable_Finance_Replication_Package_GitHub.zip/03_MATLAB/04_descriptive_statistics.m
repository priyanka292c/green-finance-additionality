%% 04_descriptive_statistics.m
% Calculates summary statistics, correlation matrices, and distributions.

fprintf('Executing 04_descriptive_statistics.m...\n');
load(fullfile('.', 'matlab_variables_data.mat'), 'T_sim');

vars = {'Log_Emissions', 'Green_Capex_Pct', 'ESG_Score', 'Log_Assets', 'ROA', 'Leverage', 'Tobins_Q'};
N = length(vars);

Mean_val = zeros(N, 1);
Std_val = zeros(N, 1);
Min_val = zeros(N, 1);
P25_val = zeros(N, 1);
Med_val = zeros(N, 1);
P75_val = zeros(N, 1);
Max_val = zeros(N, 1);

for i = 1:N
    x = T_sim.(vars{i});
    Mean_val(i) = mean(x);
    Std_val(i) = std(x);
    Min_val(i) = min(x);
    P25_val(i) = prctile(x, 25);
    Med_val(i) = median(x);
    P75_val(i) = prctile(x, 75);
    Max_val(i) = max(x);
end

T_desc = table(vars', Mean_val, Std_val, Min_val, P25_val, Med_val, P75_val, Max_val, ...
    'VariableNames', {'Variable', 'Mean', 'Std', 'Min', 'P25', 'Median', 'P75', 'Max'});

disp('Summary Statistics:');
disp(T_desc);

writetable(T_desc, fullfile('.', 'matlab_descriptive_statistics.csv'));
fprintf('04_descriptive_statistics.m completed successfully.\n\n');
