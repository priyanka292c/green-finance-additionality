import os
import shutil
import zipfile

print("Packaging project deliverables...")

# 1. Create Overleaf ZIP package: Green_Finance_Additionality_Research.zip
zip_filename = "Green_Finance_Additionality_Research.zip"
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add manuscript files
    zipf.write("01_Manuscript/main.tex", arcname="main.tex")
    zipf.write("01_Manuscript/references.bib", arcname="references.bib")
    zipf.write("01_Manuscript/supplementary.tex", arcname="supplementary.tex")
    
    # Add all figures
    for root, dirs, files in os.walk("05_Figures"):
        for file in files:
            file_path = os.path.join(root, file)
            arc_name = os.path.join("05_Figures", file)
            zipf.write(file_path, arcname=arc_name)
            
    # Add all tables
    for root, dirs, files in os.walk("06_Tables"):
        for file in files:
            file_path = os.path.join(root, file)
            arc_name = os.path.join("06_Tables", file)
            zipf.write(file_path, arcname=arc_name)

print(f"Created {zip_filename} ({os.path.getsize(zip_filename)} bytes)")

# 2. Copy root level deliverables for top-level access
deliverables = [
    ("01_Manuscript/main.pdf", "main.pdf"),
    ("01_Manuscript/supplementary.pdf", "supplementary.pdf"),
    ("07_Reports/Research_Integrity_Report.pdf", "Research_Integrity_Report.pdf"),
    ("07_Reports/literature_database.csv", "literature_database.csv"),
    ("07_Reports/doi_verification_report.csv", "doi_verification_report.csv"),
]

for src, dst in deliverables:
    if os.path.exists(src):
        shutil.copyfile(src, dst)
        print(f"Copied {src} -> {dst} ({os.path.getsize(dst)} bytes)")
    else:
        print(f"WARNING: {src} not found!")

print("All deliverables packaged successfully.")
