================================================================================
  JOURNAL SUBMISSION RECORD & AUTHOR CONSORTIUM
  Manuscript Title: Green Finance or Green Refinancing? Evidence on the
                    Environmental Additionality of Corporate Green Bonds
  Target Journal:   Journal of Corporate Finance (Elsevier)
  Status:           Submission Ready
================================================================================

AUTHORS:
  1. Dr. Shahrukh Saleem (Corresponding Author)
     VIT Business School
     Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India
     Email: shahrukh.saleem@vit.ac.in (Institutional VIT)

  2. Araby Madbouly
     Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman
     Email: araby@muscatcollege.edu.om (Institutional Muscat College); ORCID: 0000-0002-7981-4191

  3. Uvesh Husain
     Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman
     Email: u78.husain@gmail.com (Gmail); ORCID: 0000-0002-8502-8488

  4. Ram Soorat
     1. School of Technology, Woxsen University, Hyderabad 502345, Telangana, India
     2. School of Business, Woxsen University, Hyderabad 502345, Telangana, India
     Email: rsoorat@gmail.com (Gmail)

  5. Priyanka
     Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India
     Email: priyanka292c@gmail.com (Gmail)

  6. Afzalur Rahman
     1. School of Technology, Woxsen University, Hyderabad 502345, Telangana, India
     2. School of Business, Woxsen University, Hyderabad 502345, Telangana, India
     Email: afzalur.rahman@woxsen.edu.in (Institutional Woxsen)

================================================================================
AUTHOR SUMMARY TABLE:
#   Author Name                             Affiliation(s)                                                                                                           Email / Gmail ID              Email Type
1   Dr. Shahrukh Saleem (Corresponding)     VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India             shahrukh.saleem@vit.ac.in     Institutional (VIT)
2   Araby Madbouly                          Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman                                            araby@muscatcollege.edu.om    Institutional (Muscat College)
3   Uvesh Husain                            Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman                                     u78.husain@gmail.com          Gmail / Mazoon
4   Ram Soorat                              1. School of Technology, Woxsen University, Hyderabad, Telangana, India                                                 rsoorat@gmail.com             Gmail
                                            2. School of Business, Woxsen University, Hyderabad, Telangana, India
5   Priyanka                                Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India                                         priyanka292c@gmail.com        Gmail
6   Afzalur Rahman                          1. School of Technology, Woxsen University, Hyderabad, Telangana, India                                                 afzalur.rahman@woxsen.edu.in  Institutional (Woxsen)
                                            2. School of Business, Woxsen University, Hyderabad, Telangana, India
================================================================================
